'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import 사이드패널 from './기능부품/사이드패널';
import 전자결재 from './기능부품/전자결재';
import 게시판 from './기능부품/게시판';
import 메신저 from './기능부품/메신저';
import 재고관리 from './기능부품/재고관리';
import 할일 from './기능부품/할일';
import 인사관리 from './기능부품/인사관리';
import 마이페이지 from './기능부품/마이페이지';
import 관리자전용 from './기능부품/관리자전용';

export default function 메인페이지() {
  const [activeTab, setActiveTab] = useState('메인');
  const [user, setUser] = useState<any>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const 오늘날짜 = new Date().toLocaleDateString('ko-KR', {
    year: 'numeric', month: 'long', day: 'numeric', weekday: 'long'
  });

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (authUser) {
        const { data: staff } = await supabase.from('staffs').select('*').eq('email', authUser.email).single();
        setUser(staff || { name: '데모직원', position: '일반직원', department: '외래팀', role: 'staff' });
      } else {
        // 데모용 가상 유저 (행정팀 테스트를 위해 role 설정 가능)
        setUser({ id: 'demo-1', name: '김행정', position: '팀장', department: '행정팀', role: 'admin', company: '박철홍정형외과' });
      }
    };
    fetchUser();
  }, []);

  // [권한 로직] 행정팀/관리자만 접근 가능한 메뉴 필터링
  const isAdmin = user?.role === 'admin' || user?.department === '행정팀';

  const menuItems = [
    { id: '메인', label: '🏠 메인', adminOnly: false },
    { id: '마이페이지', label: '👤 내 정보/급여', adminOnly: false },
    { id: '전자결재', label: '✍️ 전자결재', adminOnly: false },
    { id: '재고관리', label: '📦 재고관리', adminOnly: false },
    { id: '인사관리', label: '👥 인사관리(행정)', adminOnly: true },
    { id: '관리자센터', label: '⚙️ 시스템설정', adminOnly: true },
  ];

  if (!user) return <div className="h-screen flex items-center justify-center font-black">로딩 중...</div>;

  return (
    <div className="flex flex-col md:flex-row h-screen bg-[#F8F9FA] overflow-hidden">
      {/* 사이드 내비게이션 (반응형) */}
      <nav className={`
        fixed inset-0 z-40 bg-white transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:w-64 md:shrink-0 md:h-full md:border-r md:border-gray-200
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-8 border-b border-gray-50 flex items-center gap-3">
          <div className="w-10 h-10 bg-black rounded-2xl flex items-center justify-center text-white font-black shadow-xl">P</div>
          <div>
            <p className="text-sm font-black tracking-tighter italic">ERP SYSTEM</p>
            <p className="text-[9px] text-gray-400 font-bold uppercase">{user.company}</p>
          </div>
        </div>

        <div className="p-6 space-y-2">
          {menuItems.filter(item => !item.adminOnly || isAdmin).map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setIsMobileMenuOpen(false); }}
              className={`w-full text-left px-6 py-4 rounded-2xl text-xs font-black transition-all ${activeTab === item.id ? 'bg-blue-600 text-white shadow-xl scale-[1.02]' : 'text-gray-400 hover:bg-gray-50'}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="mt-auto p-8 border-t border-gray-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xs font-black text-gray-400">{user.name[0]}</div>
            <div>
              <p className="text-xs font-black text-gray-800">{user.name}</p>
              <p className="text-[10px] font-bold text-blue-600">{user.position}</p>
            </div>
          </div>
        </div>
      </nav>

      {/* 메인 업무 영역 */}
      <main className="flex-1 h-full overflow-hidden flex flex-col relative">
        {/* 모바일 헤더 */}
        <header className="md:hidden flex justify-between items-center p-4 bg-white border-b z-30">
          <span className="font-black text-sm italic">ERP MOBILE</span>
          <button onClick={() => setIsMobileMenuOpen(true)} className="text-xl">☰</button>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {activeTab === '메인' && (
            <div className="p-8 space-y-8">
               <header className="flex justify-between items-end border-b-4 border-black pb-4">
                <div>
                  <h1 className="text-3xl font-black text-[#1A1A1A] tracking-tighter italic">Dashboard</h1>
                  <p className="text-xs font-bold text-gray-400 mt-1">오늘의 병원 현황 및 주요 지표</p>
                </div>
                <div className="text-right">
                   <p className="text-sm font-black text-gray-800">{오늘날짜}</p>
                </div>
              </header>
              <div className="grid grid-cols-12 gap-6">
                <div className="col-span-12 lg:col-span-8 h-[500px] bg-white border border-gray-100 shadow-sm"><전자결재 user={user} /></div>
                <div className="col-span-12 lg:col-span-4 space-y-6">
                  <div className="h-[240px] bg-white border border-gray-100 shadow-sm"><할일 user={user} /></div>
                  <div className="h-[240px] bg-white border border-gray-100 shadow-sm"><게시판 /></div>
                </div>
                <div className="col-span-12 lg:col-span-6 h-[300px] bg-white border border-gray-100 shadow-sm"><메신저 user={user} /></div>
                <div className="col-span-12 lg:col-span-6 h-[300px] bg-white border border-gray-100 shadow-sm"><재고관리 user={user} /></div>
              </div>
            </div>
          )}
          {activeTab === '마이페이지' && <마이페이지 user={user} />}
          {activeTab === '전자결재' && <div className="p-8 h-full"><전자결재 user={user} /></div>}
          {activeTab === '재고관리' && <div className="p-8 h-full"><재고관리 user={user} /></div>}
          {activeTab === '인사관리' && <인사관리 user={user} />}
          {activeTab === '관리자센터' && <관리자전용 user={user} />}
        </div>
      </main>

      {/* 우측 상태 패널 (데스크톱 전용) */}
      <aside className="hidden xl:block w-80 bg-white border-l border-gray-100">
        <사이드패널 user={user} />
      </aside>
    </div>
  );
}
