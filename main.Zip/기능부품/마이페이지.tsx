'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import SalaryDetail from './인사관리서브/급여명세/급여상세';

export default function MyPageView({ user }: any) {
  const [myAttendance, setMyAttendance] = useState([]);
  const [mySalary, setMySalary] = useState<any>(null);

  useEffect(() => {
    const fetchMyData = async () => {
      // 내 근태 기록 가져오기
      const { data: att } = await supabase.from('attendance').select('*').eq('staff_id', user.id).order('date', { ascending: false }).limit(5);
      if (att) setMyAttendance(att as any);
      
      // 내 급여 데이터 시뮬레이션 (실제로는 급여 테이블에서 현재 월 데이터 호출)
      setMySalary({
        ...user,
        base_salary: user.base_salary || 3000000,
        overtime_hours: 4.5, // 실시간 연동된 연장근로 시간
        bonus: 200000
      });
    };
    fetchMyData();
  }, [user]);

  return (
    <div className="flex flex-col h-full bg-gray-50/30 overflow-y-auto custom-scrollbar p-8 space-y-8">
      <header>
        <h2 className="text-2xl font-black text-gray-800 tracking-tighter italic">My Workspace</h2>
        <p className="text-xs text-gray-400 font-bold uppercase mt-1">개인 인사 정보 및 급여 조회</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 프로필 요약 */}
        <div className="bg-white p-8 border border-gray-100 shadow-sm flex flex-col items-center text-center">
          <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center text-white text-3xl font-black mb-4 shadow-xl">
            {user.name[0]}
          </div>
          <h3 className="text-xl font-black text-gray-800">{user.name} {user.position}</h3>
          <p className="text-sm font-bold text-blue-600 mt-1">{user.company} / {user.department}</p>
          <div className="w-full border-t my-6 pt-6 grid grid-cols-2 gap-4">
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase">잔여 연차</p>
              <p className="text-xl font-black text-gray-800">{user.annual_leave || 12}일</p>
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase">근속 연수</p>
              <p className="text-xl font-black text-gray-800">3.2년</p>
            </div>
          </div>
        </div>

        {/* 최근 근태 요약 */}
        <div className="lg:col-span-2 bg-white p-8 border border-gray-100 shadow-sm">
          <h3 className="text-xs font-black text-gray-400 uppercase mb-6 tracking-widest">최근 출퇴근 기록</h3>
          <div className="space-y-4">
            {myAttendance.length > 0 ? myAttendance.map((a: any, i) => (
              <div key={i} className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                <span className="text-sm font-black text-gray-700">{a.date}</span>
                <div className="flex gap-4">
                  <span className="text-xs font-bold text-blue-600">출근: {a.check_in?.slice(11,16)}</span>
                  <span className="text-xs font-bold text-orange-500">퇴근: {a.check_out?.slice(11,16) || '--:--'}</span>
                </div>
              </div>
            )) : (
              <p className="text-center py-10 text-gray-300 font-bold text-sm italic">기록된 근태 데이터가 없습니다.</p>
            )}
          </div>
        </div>
      </div>

      {/* 실시간 급여 명세서 조회 */}
      <div className="bg-white border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-gray-50 flex justify-between items-center">
          <h3 className="text-xs font-black text-gray-800 uppercase tracking-tighter">실시간 급여 명세서 (2026년 2월)</h3>
          <button className="px-4 py-2 bg-gray-800 text-white text-[10px] font-black rounded-xl shadow-lg">PDF 다운로드</button>
        </div>
        <div className="p-8">
          {mySalary && <SalaryDetail staff={mySalary} isSelfView={true} />}
        </div>
      </div>
    </div>
  );
}
