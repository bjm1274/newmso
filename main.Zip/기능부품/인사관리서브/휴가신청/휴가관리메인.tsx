'use client';
import { useState } from 'react';

export default function VacationMain({ staffs }: any) {
  // [표준] 사업자 선택 상태 관리 (박철홍정형외과, SY(법인), 수연의원)
  const [selectedCo, setSelectedCo] = useState('전체');
  const companies = ["전체", "박철홍정형외과", "SY(법인)", "수연의원"];

  // 선택된 사업자별 직원 필터링
  const filteredStaffs = selectedCo === '전체' 
    ? staffs 
    : staffs.filter((s: any) => s.company === selectedCo);

  return (
    <div className="flex h-full bg-white border border-gray-100 animate-in fade-in duration-500">
      
      {/* 1. [좌측] 표준 사이드바: 사업자 필터 */}
      <aside className="w-72 border-r border-gray-100 bg-gray-50/30 flex flex-col shrink-0">
        <div className="p-8 border-b border-gray-100">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">사업자 필터</p>
          <div className="flex flex-col gap-1">
            {companies.map(c => (
              <button 
                key={c} 
                onClick={() => setSelectedCo(c)}
                className={`w-full text-left px-4 py-3 text-xs font-black transition-all border-l-4 ${
                  selectedCo === c 
                    ? 'bg-white border-blue-600 text-blue-600 shadow-sm' 
                    : 'border-transparent text-gray-400 hover:bg-gray-100'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="p-8 mt-auto">
          <div className="p-4 bg-blue-50 border border-blue-100">
            <p className="text-[10px] font-black text-blue-400 uppercase mb-1">알림</p>
            <p className="text-[10px] text-blue-900 font-bold leading-relaxed">
              이번 달 권장 연차 사용 대상자가 5명 있습니다.
            </p>
          </div>
        </div>
      </aside>

      {/* 2. [우측] 표준 메인 컨텐츠 영역 */}
      <main className="flex-1 flex flex-col overflow-hidden">
        
        {/* 상단 헤더: 메뉴명 및 액션 버튼 */}
        <header className="p-8 border-b border-gray-50 flex justify-between items-center bg-white shrink-0">
          <div>
            <h2 className="text-xl font-black text-gray-800 tracking-tighter">
              임직원 휴가 관리 <span className="text-sm text-gray-300 ml-2">[{selectedCo}]</span>
            </h2>
            <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase tracking-widest">Employee Vacation & Leave Status</p>
          </div>
          <div className="flex gap-2">
            <button className="px-5 py-2.5 bg-[#232933] text-white text-[11px] font-black shadow-lg hover:bg-black transition-all">연차 일괄 부여</button>
            <button className="px-5 py-2.5 bg-[#2563EB] text-white text-[11px] font-black shadow-xl hover:bg-blue-700 transition-all">+ 휴가 신청 등록</button>
          </div>
        </header>

        {/* 메인 스크롤 영역 */}
        <div className="flex-1 p-8 overflow-y-auto bg-gray-50/20 custom-scrollbar space-y-8">
          
          {/* 요약 카드 (KPI) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white border border-gray-100 shadow-sm">
              <p className="text-[10px] font-black text-gray-300 uppercase mb-2">오늘 휴가자</p>
              <p className="text-2xl font-black text-gray-800">3명 <span className="text-xs text-blue-500 ml-2">재직인원 대비 8%</span></p>
            </div>
            <div className="p-6 bg-white border border-gray-100 shadow-sm">
              <p className="text-[10px] font-black text-gray-400 uppercase mb-2">승인 대기 중</p>
              <p className="text-2xl font-black text-orange-500">1건</p>
            </div>
            <div className="p-6 bg-white border border-gray-100 shadow-sm">
              <p className="text-[10px] font-black text-gray-300 uppercase mb-2">이번 달 총 사용 일수</p>
              <p className="text-2xl font-black text-blue-600">14.5일</p>
            </div>
          </div>

          {/* 상세 휴가 대장 테이블 */}
          <div className="bg-white border border-gray-100 rounded-none overflow-hidden shadow-sm">
            <table className="w-full text-left border-collapse">
              <thead className="bg-gray-50 text-[10px] font-black text-gray-400 border-b border-gray-100 uppercase">
                <tr>
                  <th className="p-4">소속</th>
                  <th className="p-4">성명</th>
                  <th className="p-4">부서</th>
                  <th className="p-4 text-right">총 발생</th>
                  <th className="p-4 text-right">사용 일수</th>
                  <th className="p-4 text-right text-blue-600">잔여 연차</th>
                  <th className="p-4 text-center">상태</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredStaffs.map((s: any) => (
                  <tr key={s.id} className="hover:bg-gray-25 transition-colors">
                    <td className="p-4 text-[9px] font-black text-gray-400">{s.company}</td>
                    <td className="p-4 text-xs font-black text-gray-800">{s.name}</td>
                    <td className="p-4 text-[10px] font-bold text-gray-500">{s.dept}</td>
                    <td className="p-4 text-right text-xs font-bold text-gray-400">15.0</td>
                    <td className="p-4 text-right text-xs font-bold text-red-400">3.5</td>
                    <td className="p-4 text-right text-xs font-black text-blue-600 bg-blue-50/20">11.5</td>
                    <td className="p-4 text-center">
                      <button className="px-3 py-1 bg-white border border-gray-200 text-[9px] font-black text-gray-400 hover:text-blue-500 hover:border-blue-500 transition-all">내역보기</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}