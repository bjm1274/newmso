'use client';
import { useState } from 'react';

export default function AttendanceMain({ staffs, selectedCo }: any) {
  // 1. 상태 관리: 보기 모드, 선택된 달(Month), 선택된 주차, 선택된 셀들
  const [viewMode, setViewMode] = useState<'daily' | 'weekly'>('weekly');
  const [selectedMonth, setSelectedMonth] = useState('2026-02'); // 특정 월 선택 달력용
  const [selectedDate, setSelectedDate] = useState('2026-02-06');
  const [activeWeek, setActiveWeek] = useState(1);
  const [selectedCells, setSelectedCells] = useState<string[]>([]);

  const filtered = selectedCo === '전체' ? staffs : staffs.filter((s: any) => s.company === selectedCo);

  // 2. 선택된 주차의 날짜 배열 생성 (1~5주차)
  const getWeekDays = (week: number) => {
    const startDay = (week - 1) * 7 + 1;
    return Array.from({ length: 7 }, (_, i) => {
      const d = startDay + i;
      return d <= 31 ? d : null; // 월별 일수는 실제 연동 시 달력 라이브러리 활용 권장
    }).filter(d => d !== null);
  };

  const currentWeekDays = getWeekDays(activeWeek);

  // 3. [신규] 이름 클릭 시 해당 행(주차) 전체 선택/해제 로직
  const toggleRowSelection = (staffId: number) => {
    const rowCellKeys = currentWeekDays.map(d => `${staffId}-${d}`);
    const isAllSelected = rowCellKeys.every(key => selectedCells.includes(key));

    if (isAllSelected) {
      // 이미 다 선택되어 있으면 해당 행 해제
      setSelectedCells(prev => prev.filter(key => !rowCellKeys.includes(key)));
    } else {
      // 아니면 해당 행 전체 추가 (중복 제거)
      setSelectedCells(prev => Array.from(new Set([...prev, ...rowCellKeys])));
    }
  };

  const runBatchAction = (actionType: string) => {
    if (selectedCells.length === 0) return;
    alert(`[${actionType}] 선택된 ${selectedCells.length}건을 일괄 정상 처리하였습니다.`);
    setSelectedCells([]);
  };

  return (
    <div className="flex flex-col h-full bg-[#FDFDFD] relative overflow-hidden animate-in fade-in duration-500">
      
      {/* A. 상단 제어 영역: 달력 선택 및 주차 탭 */}
      <header className="p-8 border-b border-gray-100 bg-white shrink-0">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-xl font-black text-gray-800 tracking-tighter">
              근태 현황 대장 <span className="text-sm text-blue-600 ml-2">[{selectedCo}]</span>
            </h2>
            <div className="flex gap-1 mt-4">
              <button onClick={() => setViewMode('daily')} className={`px-6 py-2.5 text-[10px] font-black border transition-all ${viewMode === 'daily' ? 'bg-[#232933] text-white border-[#232933]' : 'bg-white text-gray-400 border-gray-200'}`}>일일 현황</button>
              <button onClick={() => setViewMode('weekly')} className={`px-6 py-2.5 text-[10px] font-black border transition-all ${viewMode === 'weekly' ? 'bg-[#232933] text-white border-[#232933]' : 'bg-white text-gray-400 border-gray-200'}`}>월별/주간 현황</button>
            </div>
          </div>

          {/* [수정] 특정 월 선택 달력 및 주차 탭 */}
          <div className="flex items-center gap-4 bg-gray-50 p-2 border border-gray-100">
            <div className="flex items-center gap-2 border-r pr-4 mr-2">
                <span className="text-[10px] font-black text-gray-400 uppercase">Month</span>
                <input 
                  type="month" 
                  value={selectedMonth} 
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="bg-white border border-gray-200 px-3 py-1.5 text-xs font-black outline-none focus:border-blue-600"
                />
            </div>
            {viewMode === 'weekly' && (
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map(w => (
                  <button 
                    key={w} 
                    onClick={() => setActiveWeek(w)}
                    className={`w-10 h-10 text-[11px] font-black transition-all ${activeWeek === w ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-400 border border-gray-100 hover:bg-gray-100'}`}
                  >
                    {w}주
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* B. 메인 데이터 테이블 */}
      <main className="flex-1 p-8 overflow-y-auto custom-scrollbar bg-gray-50/20">
        <div className="bg-white border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse table-fixed">
            <thead className="bg-gray-50 text-[10px] font-black text-gray-400 border-b border-gray-100 uppercase">
              <tr>
                <th className="p-4 w-48 border-r">성명 / 소속 (클릭 시 행 선택)</th>
                {viewMode === 'daily' ? (
                  <th className="p-4 text-center">근태 기록 ({selectedDate})</th>
                ) : (
                  currentWeekDays.map(d => (
                    <th key={d} className="p-4 text-center border-r font-black">{d}일</th>
                  ))
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((s: any) => (
                <tr key={s.id} className="hover:bg-gray-25 transition-colors group">
                  {/* [수정] 성명 클릭 시 해당 주차 전체 일괄 선택 */}
                  <td 
                    onClick={() => toggleRowSelection(s.id)}
                    className="p-4 border-r cursor-pointer hover:bg-blue-50 transition-colors"
                  >
                    <p className="text-xs font-black text-gray-800 group-hover:text-blue-600">{s.name}</p>
                    <p className="text-[9px] text-gray-400 font-bold uppercase">{s.company}</p>
                  </td>
                  {viewMode === 'weekly' && currentWeekDays.map(d => {
                    const cellKey = `${s.id}-${d}`;
                    const isSelected = selectedCells.includes(cellKey);
                    return (
                      <td 
                        key={d}
                        onClick={() => setSelectedCells(prev => isSelected ? prev.filter(c => c !== cellKey) : [...prev, cellKey])}
                        className={`p-3 border-r border-gray-50 text-center cursor-cell transition-all ${isSelected ? 'bg-blue-600/10 ring-2 ring-inset ring-blue-600' : ''}`}
                      >
                        <div className="flex flex-col gap-0.5 group-hover:scale-110 transition-transform">
                          <span className="text-[9px] font-mono font-bold text-gray-400">08:55</span>
                          <span className="text-[9px] font-mono font-bold text-blue-500">18:02</span>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* C. 하단 플로팅 커맨드 바 (선택 시 등장) */}
      <div className={`fixed bottom-12 left-1/2 -translate-x-1/2 z-50 transition-all duration-500 transform 
        ${selectedCells.length > 0 ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'}`}>
        <div className="bg-[#232933] text-white px-8 py-4 shadow-2xl flex items-center gap-8 border border-white/10 rounded-none">
          <div className="flex flex-col border-r border-white/10 pr-8">
            <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest leading-none mb-1">Target Records</span>
            <span className="text-xl font-black">{selectedCells.length}건</span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => runBatchAction('정상 출근')} className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-[11px] font-black transition-all">일괄 정상 출근</button>
            <button onClick={() => runBatchAction('정상 퇴근')} className="px-6 py-3 bg-red-600 hover:bg-red-700 text-[11px] font-black transition-all">일괄 정상 퇴근</button>
            <button onClick={() => setSelectedCells([])} className="px-6 py-3 bg-white/10 hover:bg-white/20 text-[11px] font-black transition-all">선택 취소</button>
          </div>
        </div>
      </div>

    </div>
  );
}