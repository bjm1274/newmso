'use client';
import { useState } from 'react';
import SalaryDetail from './급여명세/급여상세';
import PayrollTable from './급여명세/급여대장표';
import CompliancePanel from './급여명세/노무준수패널';

export default function PayrollMain({ staffs = [], selectedCo }: any) {
  const [selectedStaffId, setSelectedStaffId] = useState(1);
  const [checkedIds, setCheckedIds] = useState<number[]>([]);
  
  // 1. 사업자 필터링
  const filtered = selectedCo === '전체' ? staffs : staffs.filter((s:any) => s.company === selectedCo);
  
  // 2. [핵심] 근태 모듈에서 계산된 '실제 연장근로시간'을 직원 데이터에 매칭합니다.
  const current = filtered.find((s:any) => s.id === selectedStaffId) || filtered[0];

  const handleAction = (type: string) => {
    if (checkedIds.length === 0) return alert("대상을 선택해 주세요.");
    alert(`${type === 'bank' ? '은행 이체 파일' : '알림톡 명세서'}를 생성합니다.`);
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500">
      <header className="p-8 border-b border-gray-50 bg-white flex justify-between items-center shrink-0">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tighter">급여 정산 대장 <span className="text-sm text-blue-600 ml-2">[{selectedCo}]</span></h2>
          <p className="text-[10px] text-green-600 font-bold mt-1 uppercase tracking-widest">● 근태 시스템 데이터 실시간 연동 중</p>
        </div>
        <div className="flex gap-2">
            <button onClick={() => handleAction('bank')} className="px-5 py-2.5 bg-[#232933] text-white text-[11px] font-black shadow-lg">일괄 이체 SAM 생성</button>
            <button onClick={() => handleAction('send')} className="px-5 py-2.5 bg-[#2563EB] text-white text-[11px] font-black shadow-xl">일괄 명세서 발송</button>
        </div>
      </header>

      <div className="flex-1 p-8 overflow-y-auto bg-gray-50/20">
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <div className="xl:col-span-2 space-y-8">
                {/* [연동] current 객체에 포함된 근태 시간이 SalaryDetail로 전달됩니다. */}
                {current && <SalaryDetail staff={current} />}
                <PayrollTable staffs={filtered} checkedIds={checkedIds} setCheckedIds={setCheckedIds} onSelect={setSelectedStaffId} />
            </div>
            <aside className="space-y-8">
                <CompliancePanel staffs={filtered.filter((s:any) => checkedIds.includes(s.id))} companyName={selectedCo} />
            </aside>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center bg-white border border-dashed border-gray-200 p-20">
            <p className="text-sm font-black text-gray-400">"{selectedCo}" 소속 인원이 없습니다.</p>
          </div>
        )}
      </div>
    </div>
  );
}