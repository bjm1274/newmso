'use client';
export default function ContractList({ selectedCo, staffs, onSelect, checkedIds, setCheckedIds }: any) {
  const filtered = selectedCo === '전체' ? staffs : staffs.filter((s: any) => s.company === selectedCo);

  const toggleAll = () => {
    if (checkedIds.length === filtered.length) setCheckedIds([]);
    else setCheckedIds(filtered.map((s: any) => s.id));
  };

  const toggleOne = (id: number) => {
    if (checkedIds.includes(id)) setCheckedIds(checkedIds.filter((i: number) => i !== id));
    else setCheckedIds([...checkedIds, id]);
  };

  return (
    <div className="bg-white border border-gray-100 shadow-sm overflow-hidden flex flex-col h-[800px]">
      <div className="p-6 border-b border-gray-50 bg-gray-50/50 flex justify-between items-center">
        <h3 className="text-[11px] font-black text-gray-400 uppercase tracking-widest">계약 대상자 명단</h3>
        <span className="text-[10px] font-bold text-blue-600">필터 결과: {filtered.length}명</span>
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead className="bg-white text-[9px] font-black text-gray-300 border-b border-gray-100 sticky top-0 z-10 uppercase">
            <tr>
              <th className="p-4 w-10 text-center"><input type="checkbox" checked={checkedIds.length === filtered.length && filtered.length > 0} onChange={toggleAll} className="w-4 h-4 accent-blue-600" /></th>
              <th className="p-4">성명 / 소속</th>
              <th className="p-4">상태</th>
              <th className="p-4 text-center">작업</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {filtered.map((s: any) => (
              <tr key={s.id} onClick={() => onSelect(s.id)} className={`hover:bg-blue-50/20 cursor-pointer transition-colors ${checkedIds.includes(s.id) ? 'bg-blue-50/30' : ''}`}>
                <td className="p-4 text-center" onClick={(e) => e.stopPropagation()}>
                  <input type="checkbox" checked={checkedIds.includes(s.id)} onChange={() => toggleOne(s.id)} className="w-4 h-4 accent-blue-600" />
                </td>
                <td className="p-4">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-gray-800">{s.name}</span>
                    <span className="text-[9px] text-gray-400 font-bold uppercase">{s.company}</span>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`px-2 py-0.5 text-[9px] font-black border ${s.id === 3 ? 'bg-orange-50 text-orange-600 border-orange-100' : 'bg-green-50 text-green-600 border-green-100'}`}>
                    {s.id === 3 ? '서명대기' : '서명완료'}
                  </span>
                </td>
                <td className="p-4 text-center" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => alert(`${s.name}님에게 서명 링크를 재전송했습니다.`)} className="px-3 py-1 bg-white border border-gray-200 text-[9px] font-black text-gray-400 hover:text-blue-600 hover:border-blue-600 transition-all">
                    링크 전송
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}