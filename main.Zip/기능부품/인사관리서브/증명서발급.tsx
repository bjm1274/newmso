'use client';
import { useState } from 'react';

export default function CertificateGenerator({ staffs }: any) {
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  const [certType, setCertType] = useState('재직증명서');

  const handleIssue = () => {
    if (!selectedStaff) return alert("발급 대상을 선택해주세요.");
    alert(`${selectedStaff.name}님의 ${certType}가 발급되었습니다. (PDF 다운로드 시작)`);
  };

  return (
    <div className="bg-white border border-gray-100 shadow-sm p-8 space-y-8 animate-in fade-in duration-500">
      <header className="border-b pb-4">
        <h3 className="text-lg font-black text-gray-800 tracking-tighter italic">Certificate Issuance Engine</h3>
        <p className="text-[10px] text-blue-600 font-bold uppercase tracking-widest mt-1">행정팀 전용 제증명 자동 발급 시스템</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase">1. 발급 대상 직원 선택</label>
            <select 
              onChange={(e) => setSelectedStaff(staffs.find((s:any) => s.id === e.target.value))}
              className="w-full p-4 bg-gray-50 rounded-2xl text-sm font-black border-none outline-none focus:ring-2 focus:ring-blue-100"
            >
              <option value="">직원 선택...</option>
              {staffs.map((s:any) => <option key={s.id} value={s.id}>{s.name} ({s.department} / {s.position})</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase">2. 증명서 종류 선택</label>
            <div className="grid grid-cols-2 gap-2">
              {['재직증명서', '경력증명서', '퇴직증명서', '원천징수영수증'].map(t => (
                <button 
                  key={t} 
                  onClick={() => setCertType(t)}
                  className={`p-4 rounded-2xl text-xs font-black border-2 transition-all ${certType === t ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-gray-50 text-gray-400 hover:border-gray-100'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={handleIssue}
            className="w-full py-5 bg-black text-white rounded-[2rem] font-black text-sm shadow-2xl hover:scale-[0.98] transition-all"
          >
            증명서 즉시 발급 (직인 포함)
          </button>
        </div>

        {/* 발급 미리보기 */}
        <div className="bg-gray-50 rounded-[2.5rem] p-10 border border-gray-100 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 text-[9px] font-black rounded-full">PREVIEW</div>
          {selectedStaff ? (
            <div className="w-full bg-white shadow-lg p-8 space-y-6 text-center border border-gray-200 aspect-[1/1.414]">
              <h4 className="text-2xl font-black underline decoration-double underline-offset-8">{certType}</h4>
              <div className="text-left space-y-4 pt-10 text-xs font-bold text-gray-700">
                <p>성 명 : {selectedStaff.name}</p>
                <p>소 속 : {selectedStaff.company}</p>
                <p>직 위 : {selectedStaff.position}</p>
                <p>재직기간 : 2023.01.01 ~ 현재</p>
                <div className="pt-20 text-center space-y-2">
                  <p>위와 같이 재직 중임을 증명함.</p>
                  <p className="pt-4">{new Date().toLocaleDateString()}</p>
                  <p className="text-lg font-black mt-8">박철홍정형외과 대표 (인)</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-2">
              <p className="text-3xl">📄</p>
              <p className="text-xs font-black text-gray-300">대상을 선택하면 미리보기가 활성화됩니다.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
