'use client';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function 구성원관리({ 직원목록 = [], 부서목록 = [], 선택사업체, 새로고침, 창상태, 창닫기 }: any) {
  const [신규직원, 신규직원설정] = useState({
    성명: '',           // 아이디로 자동 기입됨
    주민번호: '',       // [추가] 행정 필수 항목
    전화번호: '',
    주소: '',
    면허자격: '',
    사업체: '박철홍정형외과', 
    팀: '원무팀',
    직함: '',
    입사일: '',
    급여정보: '',
    급여통장: ''
  });

  // 사업체별 소속 팀 리스트 (관리부 제외)
  const 팀목록가져오기 = (회사: string) => {
    if (회사 === 'SY INC.') return ['벤티', '경영지원', '관리팀', '영업부', '마케팅'];
    return ['진료부', '진료팀', '병동팀', '수술팀', '외래팀', '검사팀', '원무팀', '총무팀', 'MSO'];
  };

  const 정보저장 = async () => {
    if (!신규직원.성명 || !신규직원.주민번호 || !신규직원.입사일) {
      return alert('성함, 주민번호, 입사일은 필수 입력 사항입니다.');
    }
    
    const 대상부서 = 부서목록.find((d: any) => d.name === 신규직원.팀);
    
    // [병원장님 지침] 아이디=성명, 비밀번호는 첫 로그인 시 자동기입
    const { error } = await supabase.from('staff').insert([{
      name: 신규직원.성명,
      login_id: 신규직원.성명, 
      resident_number: 신규직원.주민번호, // [추가] 주민번호 저장
      phone: 신규직원.전화번호,
      address: 신규직원.주소,
      license: 신규직원.면허자격,
      company: 신규직원.사업체, // [추가] 소속 회사
      department_id: 대상부서?.id, // [추가] 소속 부서/팀
      position: 신규직원.직함,
      join_date: 신규직원.입사일,
      salary_info: 신규직원.급여정보,
      bank_account: 신규직원.급여통장,
      status: '재직', // 신규는 무조건 재직
      password: null
    }]);

    if (!error) { 창닫기(); 새로고침(); }
  };

  // 퇴사자 제외 필터링 명단
  const 필터목록 = 직원목록.filter((s: any) => 
    (선택사업체 === '전체' ? true : s.company === 선택사업체) && s.status !== '퇴사'
  );

  return (
    <div className="flex flex-col h-full relative animate-in fade-in duration-500">
      <header className="p-8 border-b border-gray-50 bg-white shrink-0">
        <h2 className="text-xl font-black text-gray-800 tracking-tighter italic">
          실시간 구성원 현황 <span className="text-sm text-blue-600">[{선택사업체}]</span>
        </h2>
        {/* [지침] 중복되는 검정색 버튼은 삭제했습니다. */}
      </header>

      <div className="p-8 overflow-y-auto custom-scrollbar">
        <table className="w-full text-left border-collapse border border-gray-100 bg-white">
          <thead className="bg-gray-50 text-[10px] font-black text-gray-400 border-b border-gray-100 uppercase">
            <tr><th className="p-4">성명(아이디)</th><th className="p-4">소속</th><th className="p-4">팀</th><th className="p-4">직함</th><th className="p-4">상태</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-50 text-xs font-bold">
            {필터목록.map((직원: any) => (
              <tr key={직원.id} className="hover:bg-gray-25 transition-colors">
                <td className="p-4 font-black">{직원.name}</td>
                <td className="p-4 text-gray-400">{직원.company}</td>
                <td className="p-4 text-gray-400">{직원.departments?.name}</td>
                <td className="p-4 text-blue-600">{직원.position}</td>
                <td className="p-4"><span className="px-2 py-0.5 bg-green-50 text-green-600 text-[9px] font-black border border-green-100 uppercase">재직중</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* [수정] 주민번호 및 소속 선택이 포함된 등록 창 */}
      {창상태 && (
        <div className="absolute inset-0 bg-gray-900/10 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-gray-900 w-full max-w-2xl p-10 shadow-2xl space-y-6 animate-in zoom-in-95">
            <h3 className="text-2xl font-black text-gray-800 tracking-tighter italic border-b-4 border-gray-900 pb-2">신규 직원 정보 기입</h3>
            
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-gray-400">성명 (아이디 자동기입)</label>
                <input type="text" value={신규직원.성명} onChange={e => 신규직원설정({...신규직원, 성명: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-gray-900 font-black text-xs" />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-gray-400">주민등록번호</label>
                <input type="text" value={신규직원.주민번호} onChange={e => 신규직원설정({...신규직원, 주민번호: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-gray-900 font-black text-xs" placeholder="000000-0000000" />
              </div>

              {/* [추가] 소속 회사 및 부서 선택 */}
              <div className="space-y-1">
                <label className="text-[9px] font-black text-blue-600 font-bold">사업체 선택</label>
                <select value={신규직원.사업체} onChange={e => 신규직원설정({...신규직원, 사업체: e.target.value, 팀: 팀목록가져오기(e.target.value)[0]})} className="w-full p-3 bg-blue-50/30 border border-blue-100 outline-none font-black text-xs">
                  <option value="박철홍정형외과">박철홍정형외과</option>
                  <option value="SY INC.">SY INC.</option>
                  <option value="수연의원">수연의원</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-blue-600 font-bold">소속 부서/팀</label>
                <select value={신규직원.팀} onChange={e => 신규직원설정({...신규직원, 팀: e.target.value})} className="w-full p-3 bg-blue-50/30 border border-blue-100 outline-none font-black text-xs">
                  {팀목록가져오기(신규직원.사업체).map(팀 => <option key={팀} value={팀}>{팀}</option>)}
                </select>
              </div>

              <div className="space-y-1"><label className="text-[9px] font-black text-gray-400">전화번호</label><input type="text" value={신규직원.전화번호} onChange={e => 신규직원설정({...신규직원, 전화번호: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              <div className="space-y-1"><label className="text-[9px] font-black text-gray-400">입사일자</label><input type="date" value={신규직원.입사일} onChange={e => 신규직원설정({...신규직원, 입사일: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              <div className="space-y-1 col-span-2"><label className="text-[9px] font-black text-gray-400">주소</label><input type="text" value={신규직원.주소} onChange={e => 신규직원설정({...신규직원, 주소: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              <div className="space-y-1"><label className="text-[9px] font-black text-gray-400">면허/자격</label><input type="text" value={신규직원.면허자격} onChange={e => 신규직원설정({...신규직원, 면허자격: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              <div className="space-y-1"><label className="text-[9px] font-black text-gray-400">직함</label><input type="text" value={신규직원.직함} onChange={e => 신규직원설정({...신규직원, 직함: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              
              <div className="space-y-1 border-t pt-4"><label className="text-[9px] font-black text-gray-400">급여정보</label><input type="text" value={신규직원.급여정보} onChange={e => 신규직원설정({...신규직원, 급여정보: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
              <div className="space-y-1 border-t pt-4"><label className="text-[9px] font-black text-gray-400">급여통장</label><input type="text" value={신규직원.급여통장} onChange={e => 신규직원설정({...신규직원, 급여통장: e.target.value})} className="w-full p-3 bg-gray-50 border border-gray-200 font-black text-xs" /></div>
            </div>

            <div className="flex gap-2 pt-6">
              <button onClick={창닫기} className="flex-1 py-4 text-[10px] font-black text-gray-400 hover:bg-gray-50 transition-all">닫기</button>
              <button onClick={정보저장} className="flex-[2] py-4 bg-gray-900 text-white text-[10px] font-black hover:bg-black transition-all shadow-xl">정보 저장 완료</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}