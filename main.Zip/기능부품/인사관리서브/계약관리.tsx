'use client';
import { useState } from 'react';
import ContractList from './계약문서/계약서명단';
import ContractPreview from './계약문서/계약서미리보기';

export default function ContractMain({ staffs, selectedCo }: any) {
  const [selectedContractId, setSelectedContractId] = useState(1);

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500 bg-gray-50/20">
      <header className="p-8 border-b border-gray-100 bg-white flex justify-between items-center shrink-0">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tighter">
            전자 계약 발송 및 관리 <span className="text-sm text-blue-600 ml-2">[{selectedCo}]</span>
          </h2>
          <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase tracking-widest">관리자 메뉴에서 설정된 양식으로 계약을 진행합니다.</p>
        </div>
        <button className="px-5 py-2.5 bg-[#2563EB] text-white text-[11px] font-black shadow-xl hover:bg-blue-700 transition-all">+ 새 계약서 초안 생성</button>
      </header>

      <div className="flex-1 p-8 overflow-y-auto grid grid-cols-1 xl:grid-cols-2 gap-8">
        <ContractList selectedCo={selectedCo} staffs={staffs} onSelect={setSelectedContractId} />
        {/* [연동] 여기서 보여지는 양식과 직인은 관리자 메뉴의 설정을 불러옵니다. */}
        <ContractPreview contractId={selectedContractId} />
      </div>
    </div>
  );
}