'use client';

// [디자인] 모든 영어를 한국어로 통일하고 각진 테두리(Square)를 적용한 표준 레이아웃
export default function PayrollTable({ staffs = [], checkedIds = [], setCheckedIds, onSelect }: any) {
  const isAllChecked = staffs.length > 0 && checkedIds.length === staffs.length;

  const toggleAll = () => {
    if (isAllChecked) setCheckedIds([]);
    else setCheckedIds(staffs.map((s: any) => s.id));
  };

  const toggleOne = (id: number) => {
    if (checkedIds.includes(id)) setCheckedIds(checkedIds.filter((i: number) => i !== id));
    else setCheckedIds([...checkedIds, id]);
  };

  return (
    <div className="bg-white border border-gray-100 rounded-none overflow-hidden shadow-sm animate-in fade-in">
      <table className="w-full text-left border-collapse">
        <thead className="bg-gray-50 text-[10px] font-black text-gray-400 border-b border-gray-100 uppercase">
          <tr>
            <th className="p-4 w-12 text-center">
              <input type="checkbox" checked={isAllChecked} onChange={toggleAll} className="w-4 h-4 accent-blue-600 rounded-none" />
            </th>
            <th className="p-4">성명</th>
            <th className="p-4">부서</th>
            <th className="p-4 text-right">기본급</th>
            <th className="p-4 text-right">총 지급액</th>
            <th className="p-4 text-center">상태</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {staffs.map((s: any) => {
            // [방어 코드] 데이터가 없을 경우를 대비해 0으로 초기화합니다.
            const base = s?.base || 0;
            const position = s?.position || 0;
            const meal = s?.meal || 0;
            const total = base + position + meal;

            return (
              <tr 
                key={s.id} 
                onClick={() => onSelect(s.id)}
                className={`hover:bg-gray-25 cursor-pointer transition-colors ${checkedIds.includes(s.id) ? 'bg-blue-50/30' : ''}`}
              >
                <td className="p-4 text-center" onClick={(e) => e.stopPropagation()}>
                  <input type="checkbox" checked={checkedIds.includes(s.id)} onChange={() => toggleOne(s.id)} className="w-4 h-4 accent-blue-600 rounded-none" />
                </td>
                <td className="p-4 text-xs font-black text-gray-700">{s.name || '미입력'}</td>
                <td className="p-4 text-[10px] font-bold text-gray-400">{s.dept || '-'}</td>
                {/* [해결] toLocaleString 호출 전에 값이 있는지 확실히 보장합니다. */}
                <td className="p-4 text-right text-xs font-bold text-gray-500">{(base).toLocaleString()}원</td>
                <td className="p-4 text-right text-xs font-black text-blue-600">{(total).toLocaleString()}원</td>
                <td className="p-4 text-center">
                  <span className="px-2 py-0.5 bg-green-50 text-green-600 text-[9px] font-black border border-green-100">계산 완료</span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}