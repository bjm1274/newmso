'use client';
import { useState, useEffect } from 'react';

export default function SalaryDetail({ staff }: any) {
  // [개선] 로컬 스토리지 또는 DB에서 실제 근태 기록을 가져와 연장 근무 계산
  const [realOvertime, setRealOvertime] = useState(staff?.overtime || 0);
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const records = JSON.parse(localStorage.getItem('attendance_records') || '[]');
      const staffRecords = records.filter((r: any) => r.staff_id === staff?.id);
      const totalOvertime = staffRecords.reduce((acc: number, cur: any) => {
        const start = new Date(cur.check_in).getTime();
        const end = new Date(cur.check_out).getTime();
        const hours = (end - start) / (1000 * 60 * 60);
        return acc + Math.max(0, hours - 8); // 8시간 초과분만 합산
      }, 0);
      if (totalOvertime > 0) setRealOvertime(totalOvertime);
    }
  }, [staff]);

  const base = staff?.base || 0;
  const overtime = realOvertime; // 근태 연동 시간 (예: 4.5h)
  const meal = staff?.meal || 200000;

  // 법정 수당 계산
  const hourlyRate = Math.floor(base / 209);
  const overtimePay = Math.floor(hourlyRate * overtime * 1.5);
  
  const taxable = base + (staff?.position_allowance || 0) + overtimePay;
  
  // 6대 법정 공제 항목
  const pension = Math.floor(taxable * 0.045);
  const health = Math.floor(taxable * 0.03545);
  const longTerm = Math.floor(health * 0.1295);
  const employment = Math.floor(taxable * 0.009);
  const incomeTax = Math.floor(taxable * 0.03); 
  const localTax = Math.floor(incomeTax * 0.1);
  
  const totalDeductions = pension + health + longTerm + employment + incomeTax + localTax;
  const netPay = (taxable + meal) - totalDeductions;

  return (
    <div className="bg-white border border-gray-100 p-8 shadow-sm rounded-none border-t-4 border-t-blue-600">
      <div className="flex justify-between items-end mb-8 border-b border-gray-50 pb-6">
        <h3 className="text-xl font-black text-gray-800">{staff?.name} <span className="text-xs text-gray-300 ml-2">{staff?.dept}</span></h3>
        <div className="text-right">
          <p className="text-[10px] font-black text-blue-500 uppercase">근태 연동 실시간 정산 금액</p>
          <p className="text-3xl font-black text-blue-600 tracking-tighter">{(netPay || 0).toLocaleString()}원</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-10">
        <div className="space-y-4">
          <h4 className="text-[11px] font-black text-gray-400 uppercase flex items-center gap-2">지급 항목</h4>
          <div className="space-y-2.5">
            <div className="flex justify-between text-xs font-bold border-b border-gray-50 pb-2"><span>기본급</span><span>{(base).toLocaleString()}원</span></div>
            {/* [연동 결과] 근태 시간이 반영된 가산 수당 */}
            <div className="flex justify-between text-xs font-black text-red-500 border-b border-gray-50 pb-2">
                <span>연장수당 ({overtime.toFixed(1)}시간)</span>
                <span>+{overtimePay.toLocaleString()}원</span>
            </div>
            <div className="flex justify-between text-xs font-black text-blue-500 border-b border-gray-50 pb-2"><span>비과세 식대</span><span>{(meal).toLocaleString()}원</span></div>
          </div>
        </div>
        
        <div className="space-y-4">
          <h4 className="text-[11px] font-black text-red-400 uppercase flex items-center gap-2">공제 항목 (6대)</h4>
          <div className="space-y-2 text-[11px] font-bold text-gray-500">
            <div className="flex justify-between"><span>국민연금</span><span>-{pension.toLocaleString()}원</span></div>
            <div className="flex justify-between"><span>건강보험</span><span>-{health.toLocaleString()}원</span></div>
            <div className="flex justify-between"><span>노인장기요양</span><span>-{longTerm.toLocaleString()}원</span></div>
            <div className="flex justify-between"><span>고용보험</span><span>-{employment.toLocaleString()}원</span></div>
            <div className="flex justify-between text-gray-800 pt-2 border-t"><span>소득세/지방세</span><span>-{(incomeTax + localTax).toLocaleString()}원</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
