'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

// [게시판용] 누구나 볼 수 있는 월간 근무표
export default function MonthlyRoster() {
  const [currentMonth, setCurrentMonth] = useState(new Date().toISOString().slice(0, 7));
  const [rosterData, setRosterData] = useState<any[]>([]);

  // 데이터 로드: 직원 정보와 할당된 근무형태(schedule)를 가져옴
  useEffect(() => {
    const loadRoster = async () => {
      // 직원과 연결된 근무표 정보를 join해서 가져옴
      const { data: staffs } = await supabase
        .from('staff')
        .select('name, position, work_schedules(name, start_time, end_time)')
        .order('name');
      
      setRosterData(staffs || []);
    };
    loadRoster();
  }, [currentMonth]);

  return (
    <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-black text-gray-800">🗓️ {currentMonth} 병원 근무표</h2>
        <input type="month" value={currentMonth} onChange={e=>setCurrentMonth(e.target.value)} className="bg-gray-50 p-2 rounded-xl font-bold" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rosterData.map((staff, idx) => (
          <div key={idx} className="border p-4 rounded-2xl flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center font-bold text-gray-500">
                {staff.name[0]}
              </div>
              <div>
                <p className="font-bold text-gray-800">{staff.name}</p>
                <p className="text-xs text-gray-400">{staff.position}</p>
              </div>
            </div>
            
            {/* 할당된 근무 형태 표시 */}
            <div className="text-right">
               {staff.work_schedules ? (
                 <>
                   <p className="text-sm font-black text-blue-600">{staff.work_schedules.name}</p>
                   <p className="text-xs text-gray-400 font-mono">
                     {staff.work_schedules.start_time.slice(0,5)} ~ {staff.work_schedules.end_time.slice(0,5)}
                   </p>
                 </>
               ) : (
                 <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-400">미지정</span>
               )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}