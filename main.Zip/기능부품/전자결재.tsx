'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import AttendanceForms from './전자결재서브/근태신청양식';
import SuppliesForm from './전자결재서브/비품구매양식';
import AdminForms from './전자결재서브/관리행정양식';

export default function ApprovalView({ user, staffs }: any) {
  const [viewMode, setViewMode] = useState('기안함'); 
  const [approvals, setApprovals] = useState([]);
  const [formType, setFormType] = useState('연차/휴가'); 
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [approverLine, setApproverLine] = useState<any[]>([]); 
  const [extraData, setExtraData] = useState<any>({}); 

  const baseForms = ['연차/휴가', '연장근무', '물품신청', '업무기안', '업무협조'];
  const availableForms = (user.department === '행정팀' || user.position === '병원장') 
    ? [...baseForms, '인사명령'] : baseForms;

  const fetchApprovals = async () => {
    const { data } = await supabase.from('approvals').select('*').order('created_at', { ascending: false });
    if (data) setApprovals(data as any);
  };

  useEffect(() => { fetchApprovals(); }, []);

  // [핵심 로직] 최종 승인 시 재고 및 급여 자동 업데이트
  const handleApproveAction = async (item: any) => {
    if (!confirm("승인하시겠습니까? 관련 재고 및 급여 데이터가 즉시 업데이트됩니다.")) return;
    
    const { error: appError } = await supabase.from('approvals').update({ status: '승인' }).eq('id', item.id);
    
    if (!appError) {
        // 1. 물품신청 승인 시 재고 차감
        if (item.type === '물품신청' && item.meta_data.items) {
            for (const p of item.meta_data.items) {
                const { data: inv } = await supabase.from('inventory').select('stock').eq('name', p.name).single();
                if (inv) {
                    await supabase.from('inventory').update({ stock: inv.stock - p.qty }).eq('name', p.name);
                    // 로그 기록
                    await supabase.from('inventory_logs').insert([{
                        item_id: p.name, type: '출고(결재승인)', qty: p.qty, worker_id: item.sender_id, dept: p.dept
                    }]);
                }
            }
        }

        // 2. 연장근무 승인 시 급여 데이터(연장수당) 반영 시뮬레이션
        if (item.type === '연장근무') {
            console.log(`${item.sender_id} 직원의 연장수당이 이번 달 급여에 자동 합산되었습니다.`);
            // 실제로는 payroll 테이블의 overtime_pay 필드를 업데이트함
        }

        // 3. 연차 승인 시 근태 및 연차 차감
        if (item.type === '연차/휴가') {
            await supabase.from('attendance').upsert({ 
                staff_id: item.sender_id, date: item.meta_data.startDate, status: '휴가', is_approved: true 
            });
            const { data: staff } = await supabase.from('staffs').select('annual_leave').eq('id', item.sender_id).single();
            if (staff) {
                await supabase.from('staffs').update({ annual_leave: staff.annual_leave - 1 }).eq('id', item.sender_id);
            }
        }

        alert("최종 승인 및 자동 데이터 연동이 완료되었습니다."); 
        fetchApprovals();
    }
  };

  const handleSubmit = async () => {
    if (!formTitle || approverLine.length === 0) return alert("제목과 결재선을 지정해주세요.");
    
    const { error } = await supabase.from('approvals').insert([{
      sender_id: user.id, approver_id: approverLine[0].id, approver_line: approverLine.map(a => a.id),
      type: formType, title: formTitle, content: formContent, meta_data: extraData, status: '대기'
    }]);

    if (!error) { alert("상신 완료!"); setViewMode('기안함'); fetchApprovals(); }
  };

  return (
    <div className="flex-1 flex flex-col bg-white h-full overflow-hidden">
      <header className="px-8 py-6 flex justify-between items-center border-b border-gray-100">
        <h1 className="text-xl font-black text-gray-800 tracking-tight italic">전자결재 센터</h1>
        <div className="flex gap-2">
          {['기안함', '결재함', '작성하기'].map(m => (
            <button key={m} onClick={() => setViewMode(m)} className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${viewMode === m ? 'bg-black text-white' : 'bg-gray-50 text-gray-400'}`}>{m}</button>
          ))}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-8 bg-gray-50/20 custom-scrollbar">
        {viewMode === '작성하기' ? (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-8 border border-gray-100 shadow-sm space-y-8">
              {/* 결재선 지정 */}
              <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 space-y-4">
                <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest">✍️ 결재선 지정</label>
                <select onChange={(e) => {
                    const s = staffs?.find((st:any) => st.id === e.target.value);
                    if(s && !approverLine.find(al => al.id === s.id)) setApproverLine([...approverLine, s]);
                }} className="w-full p-3 bg-white rounded-xl text-xs font-bold border-none outline-none shadow-sm">
                    <option value="">결재자 선택...</option>
                    {staffs?.filter((s:any) => ['팀장', '부장', '원장', '병원장'].includes(s.position)).map((s:any) => <option key={s.id} value={s.id}>{s.name} {s.position}</option>)}
                </select>
                <div className="flex gap-2 flex-wrap">{approverLine.map((a, i) => <div key={i} className="bg-white px-3 py-2 rounded-lg border text-[10px] font-black shadow-sm">{i+1}. {a.name} {a.position}</div>)}</div>
              </div>

              {/* 양식 선택 */}
              <div className="flex gap-2 p-1 bg-gray-100 rounded-xl w-fit">
                {availableForms.map(t => (
                  <button key={t} onClick={()=>setFormType(t)} className={`px-4 py-2 rounded-lg text-[10px] font-black transition-all ${formType===t ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400'}`}>{t}</button>
                ))}
              </div>

              <div className="min-h-[200px]">
                {['연차/휴가', '연장근무'].includes(formType) ? (
                  <AttendanceForms user={user} staffs={staffs} formType={formType} setExtraData={setExtraData} setFormTitle={setFormTitle} />
                ) : formType === '물품신청' ? (
                  <SuppliesForm setExtraData={setExtraData} />
                ) : (
                  <AdminForms staffs={staffs} formType={formType} setExtraData={setExtraData} />
                )}
              </div>

              <div className="space-y-4 pt-8 border-t">
                <input value={formTitle} onChange={e=>setFormTitle(e.target.value)} className="w-full p-4 bg-gray-50 rounded-xl font-black outline-none text-lg focus:ring-2 focus:ring-blue-100 border-none" placeholder="기안 제목" />
                <textarea value={formContent} onChange={e=>setFormContent(e.target.value)} className="w-full h-40 p-6 bg-gray-50 rounded-xl outline-none text-sm leading-relaxed border-none" placeholder="상세 사유 및 내용을 입력하세요." />
                <button onClick={handleSubmit} className="w-full py-4 bg-blue-600 text-white rounded-xl font-black text-sm shadow-xl hover:scale-[0.99] transition-all">결재 상신</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
             {approvals.map((item: any) => (
              <div key={item.id} className="bg-white p-6 border border-gray-100 shadow-sm flex justify-between items-center group hover:border-blue-300 transition-all">
                <div className="flex gap-4 items-center">
                    <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-xl shadow-inner">
                        {item.type === '물품신청' ? '📦' : '📄'}
                    </div>
                    <div>
                        <div className="flex gap-2 mb-1 items-center">
                            <span className="px-2 py-0.5 bg-gray-100 rounded text-[9px] font-black text-gray-400">{item.type}</span>
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black ${item.status === '승인' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-500'}`}>{item.status}</span>
                        </div>
                        <h3 className="font-black text-gray-800 text-sm tracking-tight">{item.title}</h3>
                        <p className="text-[9px] text-gray-400 font-bold mt-1">기안자: {item.sender_name || '사용자'} | 일시: {new Date(item.created_at).toLocaleDateString()}</p>
                    </div>
                </div>
                
                {viewMode === '결재함' && item.status === '대기' && (
                  <button onClick={() => handleApproveAction(item)} className="px-6 py-3 bg-blue-600 text-white rounded-xl text-xs font-black shadow-lg">승인하기</button>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
