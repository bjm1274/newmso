'use client';
import { supabase } from '@/lib/supabase';
import { useState } from 'react';

export default function StatusPanel({ user, tasks, surgeries, mris, attStatus, onRefresh }: any) {
  const [loading, setLoading] = useState(false);

  // [안전장치] 데이터가 아직 안 왔거나(undefined), 없으면(null) 빈 리스트([])로 처리합니다.
  const 수술목록 = surgeries || [];
  const MRI목록 = mris || [];

  // [기능 유지] 병원장님이 작성하신 근태 처리 로직 100% 보존
  const handleAttendance = async (type: 'in' | 'out') => {
    setLoading(true);
    const now = new Date().toISOString();
    const today = now.split('T')[0];

    try {
      if (type === 'in') {
        await supabase.from('attendance').insert([{ staff_id: user?.id, check_in: now }]);
      } else {
        await supabase.from('attendance').update({ check_out: now }).eq('staff_id', user?.id).gte('check_in', `${today}T00:00:00`);
      }
      
      if (type === 'out') {
        const attendanceData = JSON.parse(localStorage.getItem('attendance_records') || '[]');
        attendanceData.push({ staff_id: user?.id, date: today, check_in: now, check_out: now });
        localStorage.setItem('attendance_records', JSON.stringify(attendanceData));
      }
      if (onRefresh) await onRefresh(); 
    } catch (e) {
      console.error("근태 오류", e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <aside className="w-80 bg-white border-l border-gray-50 p-8 flex flex-col shadow-sm overflow-y-auto font-sans">
      {/* 1. 실시간 근태 관리 버튼 */}
      <div className="mb-10 space-y-4">
        <p className="px-2 text-[10px] font-black text-gray-400 uppercase italic tracking-widest">실시간 근태 현황</p>
        <div className="grid grid-cols-2 gap-2">
          <button disabled={attStatus !== 'none' || loading} onClick={() => handleAttendance('in')}
            className={`py-5 rounded-3xl font-black text-xs transition-all ${attStatus === 'none' ? 'bg-[#6B4F3D] text-white shadow-lg hover:bg-[#5a4233]' : 'bg-gray-100 text-gray-400'}`}>
            {loading && attStatus === 'none' ? '처리중...' : (attStatus === 'none' ? '출근하기' : '출근완료')}
          </button>
          <button disabled={attStatus !== 'checked_in' || loading} onClick={() => handleAttendance('out')}
            className={`py-5 rounded-3xl font-black text-xs transition-all ${attStatus === 'checked_in' ? 'bg-orange-500 text-white shadow-lg hover:bg-orange-600' : 'bg-gray-100 text-gray-400'}`}>
            {loading && attStatus === 'checked_in' ? '처리중...' : (attStatus === 'checked_out' ? '퇴근완료' : '퇴근하기')}
          </button>
        </div>
      </div>

      <div className="space-y-10">
        {/* 2. 오늘의 수술 (에러 수정 완료) */}
        <div className="space-y-4">
          <p className="px-2 text-[10px] font-black text-gray-400 uppercase italic">오늘의 수술</p>
          <div className="bg-gray-50 rounded-[2rem] p-6 space-y-4 shadow-inner min-h-[100px]">
            {수술목록.length === 0 ? (
              <p className="text-[10px] font-bold text-gray-300 text-center py-2">예정된 수술이 없습니다.</p>
            ) : (
              수술목록.map((s: any, i: number) => (
                <div key={i} className="flex flex-col border-b border-gray-200/50 pb-2 last:border-0 last:pb-0">
                  <span className="text-[10px] font-black text-orange-600">
                    {s.surgery_time ? s.surgery_time.slice(0, 5) : '시간미정'}
                  </span>
                  <span className="text-[11px] font-black text-gray-800 mt-1">
                    {s.patient_name} ({s.surgery_name})
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* 3. 오늘의 MRI 촬영 (에러 수정 완료) */}
        <div className="space-y-4">
          <p className="px-2 text-[10px] font-black text-gray-400 uppercase italic">오늘의 MRI 촬영</p>
          <div className="bg-gray-50 rounded-[2rem] p-6 space-y-4 shadow-inner min-h-[100px]">
             {MRI목록.length === 0 ? (
              <p className="text-[10px] font-bold text-gray-300 text-center py-2">예약된 촬영이 없습니다.</p>
            ) : (
              MRI목록.map((m: any, i: number) => (
                <div key={i} className={`p-4 rounded-2xl border transition-all ${m.is_fasting ? 'border-blue-200 bg-blue-50/50' : 'bg-white border-gray-100'}`}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] font-black text-blue-600">
                      {m.mri_time ? m.mri_time.slice(0, 5) : '미정'}
                    </span>
                    {m.is_fasting && <span className="text-[9px] font-bold text-white bg-red-400 px-1.5 py-0.5 rounded-md">금식</span>}
                  </div>
                  <p className="text-[11px] font-black text-gray-700">{m.patient_name} 환자</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}