'use client';
import { useState, useMemo } from 'react';

export default function OrgChart({ staffs = [], selectedCo, setSelectedCo }: any) {
  const [selectedMember, setSelectedMember] = useState<any>(null); // 클릭한 직원 저장
  const [searchQuery, setSearchQuery] = useState(''); // 검색어 저장
  
  const companies = ['전체', '박철홍정형외과', 'SY INC.', '수연의원'];

  // [핵심] 빠진 것 없는 부서 및 팀 위계 로직
  const viewData = useMemo(() => {
    const filtered = staffs.filter((s: any) => 
      s.name.includes(searchQuery) || s.position?.includes(searchQuery)
    );

    if (selectedCo === '전체') {
      return companies.filter(c => c !== '전체').map(co => ({
        companyName: co, members: filtered.filter((s: any) => s.company === co)
      }));
    }

    const coStaffs = filtered.filter((s: any) => s.company === selectedCo);
    const top = coStaffs.filter((s: any) => s.role === 'admin');

    // [구조] 병원장님 요청하신 진료/총무/간호 3대 기둥 (관리부 제외)
    const hospitalStructure = [
      { name: '진료부', teams: ['진료부', '진료팀'] },
      { name: '총무부', teams: ['원무팀', '총무팀', 'MSO'] },
      { name: '간호부', teams: ['병동팀', '수술팀', '외래팀', '검사팀'] }
    ];

    const syStructure = [
      { name: '운영본부', teams: ['벤티', '경영지원', '관리팀'] },
      { name: '사업본부', teams: ['영업부', '마케팅'] }
    ];

    return { 
      top, 
      departments: selectedCo === 'SY INC.' ? syStructure : hospitalStructure, 
      allStaff: coStaffs 
    };
  }, [staffs, selectedCo, searchQuery]);

  return (
    <div className="flex-1 flex bg-white h-full overflow-hidden animate-in fade-in duration-500 relative">
      {/* 좌측: 사업자 필터 (SY INC. 고정) */}
      <aside className="w-64 border-r border-gray-100 flex flex-col bg-[#FDFDFD] shrink-0">
        <div className="p-8 border-b border-gray-50"><h2 className="text-xl font-black text-gray-800 tracking-tighter italic">조직 정보 현황</h2></div>
        <nav className="p-4 space-y-1">
          {companies.map(co => (
            <button key={co} onClick={() => setSelectedCo(co)}
              className={`w-full text-left px-4 py-3 text-xs font-black border-l-4 transition-all ${selectedCo === co ? 'text-blue-600 bg-blue-50 border-blue-600' : 'text-gray-400 border-transparent hover:bg-gray-50'}`}>{co}</button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* 상단: 명칭 및 검색바 */}
        <header className="px-10 py-8 border-b border-gray-50 bg-white flex justify-between items-center shrink-0">
          <h1 className="text-3xl font-black text-[#1D3557] tracking-tighter">{selectedCo}</h1>
          <input type="text" placeholder="직원 검색..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
            className="p-3 bg-gray-50 border border-gray-200 text-xs font-bold outline-none focus:border-blue-600 w-64 shadow-inner" />
        </header>

        <div className="flex-1 overflow-y-auto p-12 custom-scrollbar bg-[#FBFBFB]">
          {selectedCo === '전체' ? (
            <div className="space-y-12">
              {(viewData as any[]).map(group => (
                <div key={group.companyName} className="space-y-4">
                  <div className="flex items-center gap-3 border-l-4 border-gray-800 pl-4 py-1"><h2 className="font-black text-lg text-gray-800">{group.companyName}</h2></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">{group.members.map((s: any) => <StaffCard key={s.id} staff={s} onClick={() => setSelectedMember(s)} />)}</div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center">
              {/* 위계: 병원장/대표이사 */}
              <div className="mb-20 text-center">
                <div className="text-[10px] font-black text-red-600 mb-4 bg-red-50 px-4 py-1.5 border border-red-200 inline-block uppercase">{selectedCo === 'SY INC.' ? '대표이사' : '병원장'}</div>
                <div className="flex justify-center gap-6">{(viewData as any).top.map((s: any) => <StaffCard key={s.id} staff={s} highlight="admin" onClick={() => setSelectedMember(s)} />)}</div>
              </div>

              {/* 하단: 부서 및 팀별 자동 정렬 구역 */}
              <div className={`grid ${selectedCo === 'SY INC.' ? 'grid-cols-2' : 'grid-cols-3'} gap-12 w-full max-w-[1500px]`}>
                {(viewData as any).departments.map((dept: any) => (
                  <div key={dept.name} className="flex flex-col space-y-8">
                    <div className="text-[12px] font-black text-white bg-[#1D3557] px-8 py-4 border border-[#1D3557] w-full text-center uppercase shadow-md">{dept.name}</div>
                    <div className="space-y-10">
                      {dept.teams.map((team: string) => {
                        const members = (viewData as any).allStaff.filter((s: any) => s.departments?.name === team);
                        return (
                          <div key={team} className="bg-white border-2 border-gray-100 p-6 shadow-sm relative pt-10">
                            <div className="absolute top-0 left-0 bg-gray-800 text-white text-[9px] px-3 py-1 font-black uppercase">{team}</div>
                            <div className="grid grid-cols-1 gap-2">
                              {members.length > 0 ? members.map((s: any) => <StaffCard key={s.id} staff={s} onClick={() => setSelectedMember(s)} />) : <div className="py-4 text-center text-[10px] text-gray-300 font-bold border border-dashed border-gray-100">소속 인원 없음</div>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* [메뉴] 카드 클릭 시 채팅/정보보기/즐겨찾기 기능 */}
        {selectedMember && (
          <div className="absolute inset-0 bg-gray-900/10 backdrop-blur-[2px] z-50 flex items-center justify-center" onClick={() => setSelectedMember(null)}>
            <div className="bg-white border-2 border-gray-900 p-8 w-80 shadow-2xl space-y-6 animate-in zoom-in-95" onClick={e => e.stopPropagation()}>
              <div className="flex items-center gap-4 border-b pb-6">
                <div className="w-16 h-16 bg-gray-50 border border-gray-100 flex items-center justify-center shrink-0 overflow-hidden">
                  {selectedMember.photo_url ? <img src={selectedMember.photo_url} className="w-full h-full object-cover" /> : <span className="text-2xl font-serif text-gray-200">印</span>}
                </div>
                <div><h3 className="font-black text-lg text-gray-800">{selectedMember.name} {selectedMember.position}</h3><p className="text-[10px] text-blue-600 font-bold uppercase">{selectedMember.departments?.name}</p></div>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button onClick={() => alert(`${selectedMember.name}님과 채팅 연결`)} className="w-full py-3 bg-blue-600 text-white text-xs font-black hover:bg-blue-700">채팅하기</button>
                <button className="w-full py-3 bg-white border border-gray-200 text-gray-800 text-xs font-black hover:bg-gray-50">즐겨찾기 추가</button>
                <button className="w-full py-3 bg-white border border-gray-200 text-gray-800 text-xs font-black hover:bg-gray-50">상세 정보보기</button>
                <button onClick={() => setSelectedMember(null)} className="w-full py-3 text-[10px] text-gray-400 font-bold hover:text-gray-900 mt-2">창 닫기</button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

// [내부 부품] 각진 스타일의 직원 카드
function StaffCard({ staff, highlight, onClick }: any) {
  const border = highlight === 'admin' ? 'border-red-500 border-2' : 'border-gray-100 hover:border-gray-800';
  return (
    <div onClick={onClick} className={`bg-white border p-4 flex items-center gap-4 transition-all group cursor-pointer shadow-sm ${border}`}>
      <div className="w-10 h-10 bg-gray-50 border border-gray-50 flex items-center justify-center grayscale group-hover:grayscale-0 shrink-0 overflow-hidden">
        {staff.photo_url ? <img src={staff.photo_url} className="w-full h-full object-cover" /> : <span className="text-xl font-serif text-gray-200">印</span>}
      </div>
      <div className="min-w-0 flex-1 text-left">
        <div className="flex items-center gap-2"><span className="font-black text-gray-800 text-xs truncate">{staff.name}</span><span className="text-[8px] font-bold text-gray-400 border border-gray-100 px-1">{staff.position || '직원'}</span></div>
        <p className="text-[9px] text-gray-400 font-bold mt-1 truncate uppercase">{staff.departments?.name || '미배정'}</p>
      </div>
    </div>
  );
}