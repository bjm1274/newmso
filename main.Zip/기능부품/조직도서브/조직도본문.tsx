'use client';
// [해결] 같은 org 폴더로 이동한 OrgChart 파일을 불러옵니다.
import OrgChart from './조직도그림'; 

// [경로 확인] 나머지 파일들은 한 단계 위(../) components 폴더에 있습니다.
import ChatView from '../메신저';
import BoardView from '../게시판';
import TaskView from '../할일';
import ApprovalView from '../전자결재';
import HRView from '../인사관리';
import InventoryView from '../재고관리';
import AdminView from '../관리자전용';

export default function MainContent({ user, mainMenu, data, subView, setSubView, selectedCo, setSelectedCo, onRefresh }: any) {
  return (
    <div className="flex-1 flex overflow-hidden relative bg-[#FDFDFD]">
      {/* 1. 조직 정보 현황 (통합된 파일 연결) */}
      {mainMenu === '조직도' && (
        <OrgChart 
          user={user} 
          staffs={data.staffs} 
          depts={data.depts} 
          selectedCo={selectedCo} 
          setSelectedCo={setSelectedCo} 
          onRefresh={onRefresh} 
        />
      )}
      
      {/* 2. 기타 메뉴 (채팅, 게시판 등) 분기 처리 */}
      {mainMenu === '채팅' && (
        <div className="absolute inset-0 bg-white z-20">
          <ChatView user={user} onRefresh={onRefresh} />
        </div>
      )}

      {mainMenu === '게시판' && (
        <BoardView user={user} posts={data.posts.filter((p:any) => p.board_type === subView)} 
          subView={subView} setSubView={setSubView} surgeries={data.surgeries} mris={data.mris} onRefresh={onRefresh} />
      )}

      {mainMenu === '할일' && <TaskView user={user} tasks={data.tasks} subView={subView} setSubView={setSubView} onRefresh={onRefresh} />}
      {mainMenu === '전자결재' && <ApprovalView user={user} staffs={data.staffs} subView={subView} setSubView={setSubView} />}
      {mainMenu === '인사관리' && <HRView user={user} staffs={data.staffs} depts={data.depts} selectedCo={selectedCo} onRefresh={onRefresh} />}
      {mainMenu === '재고관리' && <InventoryView user={user} depts={data.depts} onRefresh={onRefresh} />}
      {mainMenu === '관리자' && <AdminView user={user} staffs={data.staffs} depts={data.depts} onRefresh={onRefresh} />}
    </div>
  );
}