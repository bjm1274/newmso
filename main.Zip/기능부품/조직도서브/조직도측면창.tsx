'use client';

export default function Sidebar({ user, mainMenu, onMenuChange }: any) {
  const menus = [
    { id: '조직도', icon: '👤', label: '조직도' },
    { id: '채팅', icon: '✉️', label: '채팅' },
    { id: '게시판', icon: '📋', label: '게시판' },
    { id: '할일', icon: '✅', label: '할일' },
    { id: '전자결재', icon: '✍️', label: '전자결재' },
    { id: '인사관리', icon: '👥', label: '인사관리' },
    { id: '재고관리', icon: '📦', label: '재고관리' }
  ];

  return (
    <aside className="w-20 bg-[#F8F9FA] border-r border-gray-100 flex flex-col items-center py-8 space-y-4 z-30 shadow-sm">
      <div className="w-14 h-14 flex items-center justify-center mb-6 border border-gray-100 bg-white">
        <img src="/logo.png" alt="로고" className="w-full h-full object-contain p-2" />
      </div>
      
      {menus.map(m => (
        <button key={m.id} onClick={() => onMenuChange(m.id)} 
          className={`w-14 h-14 flex items-center justify-center transition-all rounded-none border ${
            mainMenu === m.id ? 'bg-blue-600 text-white border-blue-600 shadow-inner' : 'text-gray-300 border-transparent hover:bg-gray-50'
          }`}
          title={m.label}
        >
          <span className="text-xl">{m.icon}</span>
        </button>
      ))}

      {user.role === 'admin' && (
        <button onClick={() => onMenuChange('관리자')} 
          className={`w-14 h-14 mt-auto flex items-center justify-center rounded-none transition-all ${
            mainMenu === '관리자' ? 'bg-red-600 text-white shadow-lg' : 'text-gray-400 bg-gray-50 hover:bg-gray-100'
          }`}
          title="관리자 센터"
        >
          <span className="text-xl">⚙️</span>
        </button>
      )}
    </aside>
  );
}