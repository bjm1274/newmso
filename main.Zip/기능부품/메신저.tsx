'use client';
import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/lib/supabase';

const NOTICE_ROOM_ID = '00000000-0000-0000-0000-000000000000';

export default function ChatView({ user, onRefresh }: any) {
  const [messages, setMessages] = useState<any[]>([]);
  const [latestNotice, setLatestNotice] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [inputMsg, setInputMsg] = useState('');
  const [activeActionMsg, setActiveActionMsg] = useState<any>(null);
  const [replyTo, setReplyTo] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const msgRefs = useRef<any>({}); 

  const fetchData = async () => {
    const { data: msgs } = await supabase.from('messages').select('*, staff(name, photo_url)').eq('room_id', NOTICE_ROOM_ID).order('created_at', { ascending: true });
    if (msgs) setMessages(msgs);
    const { data: notice } = await supabase.from('posts').select('*').eq('board_type', '공지사항').order('created_at', { ascending: false }).limit(1).single();
    if (notice) setLatestNotice(notice);
  };

  useEffect(() => {
    fetchData();
    const channel = supabase.channel(`chat-v2`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => fetchData()).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'posts' }, () => fetchData()).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length]);

  const handleSendMessage = async (fileUrl?: string) => {
    if (!inputMsg.trim() && !fileUrl) return;
    const tempId = crypto.randomUUID();
    setMessages(prev => [...prev, { id: tempId, sender_id: user.id, content: inputMsg, file_url: fileUrl, staff: { name: user.name } }]);
    const { error } = await supabase.from('messages').insert([{ room_id: NOTICE_ROOM_ID, sender_id: user.id, content: inputMsg, file_url: fileUrl, reply_to_id: replyTo?.id }]);
    if (error) fetchData();
    setInputMsg(''); setReplyTo(null);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const path = `chat/${Date.now()}_${file.name}`;
    const { data } = await supabase.storage.from('pchos-files').upload(path, file);
    if (data) handleSendMessage(supabase.storage.from('pchos-files').getPublicUrl(path).data.publicUrl);
  };

  const handleAction = async (type: 'task' | 'notice') => {
    if (!activeActionMsg) return;
    if (type === 'task') {
      const { error } = await supabase.from('tasks').insert([{ assignee_id: user.id, title: `[채팅] ${activeActionMsg.content}`, status: 'pending' }]);
      if (!error) { alert("할일 등록 완료"); if(onRefresh) onRefresh(); }
    } else {
      const { error } = await supabase.from('posts').insert([{ board_type: '공지사항', sender_id: user.id, title: '채팅 공지', content: activeActionMsg.content }]);
      if (!error) fetchData();
    }
    setActiveActionMsg(null);
  };

  return (
    <div className="flex flex-1 overflow-hidden relative font-sans h-full">
      <aside className="w-72 border-r bg-white p-4 hidden md:flex flex-col">
         <input className="w-full p-4 bg-gray-50 rounded-2xl text-xs font-bold mb-4" placeholder="검색..." value={searchTerm} onChange={e=>setSearchTerm(e.target.value)} />
         <div className="p-4 bg-blue-600 text-white rounded-2xl text-xs font-black">📢 전직원 공지방</div>
      </aside>
      <main className="flex-1 flex flex-col bg-[#FDFDFD] h-full relative">
        {latestNotice && (
          <div className="w-full bg-white border-b p-4 px-8 z-20 flex items-center justify-between shadow-sm shrink-0">
            <span className="text-sm font-bold truncate">📢 {latestNotice.content}</span>
          </div>
        )}
        <div className="flex-1 overflow-y-auto p-8 space-y-4 custom-scrollbar">
          {messages.filter(m => (m.content||'').includes(searchTerm)).map((msg) => (
            <div key={msg.id} ref={el => msgRefs.current[msg.id] = el} className={`flex flex-col ${msg.sender_id === user.id ? 'items-end' : 'items-start'}`}>
              <span className="text-[10px] text-gray-400 px-2">{msg.staff?.name}</span>
              <div onClick={() => setActiveActionMsg(msg)} className={`p-4 rounded-2xl text-sm shadow-sm cursor-pointer ${msg.sender_id === user.id ? 'bg-blue-600 text-white' : 'bg-white border'}`}>
                {msg.content}
                {msg.file_url && <a href={msg.file_url} target="_blank" className="block mt-2 text-[10px] underline">📎 파일 보기</a>}
              </div>
            </div>
          ))}
          <div ref={scrollRef} />
        </div>
        <div className="p-6 bg-white border-t shrink-0">
           {replyTo && <div className="mb-2 text-xs text-blue-500">@{replyTo.staff?.name}에게 답글 중... <button onClick={()=>setReplyTo(null)}>x</button></div>}
           <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-2xl">
             <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />
             <button onClick={()=>fileInputRef.current?.click()} className="p-2 text-gray-400">📎</button>
             <input className="flex-1 bg-transparent p-2 outline-none text-sm" value={inputMsg} onChange={e=>setInputMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&handleSendMessage()} />
             <button onClick={()=>handleSendMessage()} className="bg-blue-600 text-white w-10 h-10 rounded-full">↑</button>
           </div>
        </div>
        {activeActionMsg && (
          <div className="absolute inset-0 bg-black/20 flex items-center justify-center z-30" onClick={()=>setActiveActionMsg(null)}>
            <div className="bg-white p-6 rounded-3xl space-y-2 w-60">
              <button onClick={()=>{setReplyTo(activeActionMsg); setActiveActionMsg(null)}} className="w-full p-3 text-left hover:bg-gray-50 rounded-xl text-sm font-bold text-blue-600">↩️ 답글</button>
              <button onClick={()=>handleAction('task')} className="w-full p-3 text-left hover:bg-gray-50 rounded-xl text-sm font-bold">✅ 할일 등록</button>
              <button onClick={()=>handleAction('notice')} className="w-full p-3 text-left hover:bg-gray-50 rounded-xl text-sm font-bold text-orange-500">📢 공지 등록</button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}