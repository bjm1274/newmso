'use client';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function TaskView({ user, tasks = [], subView, setSubView, onRefresh }: any) {
  const [newTask, setNewTask] = useState('');

  // 1. 할 일 추가 로직 (DB에 'tasks' 테이블이 있어야 작동합니다)
  const handleAddTask = async () => {
    if (!newTask.trim() || !user?.id) return;
    
    const { error } = await supabase.from('tasks').insert([{
      assignee_id: user.id,
      title: newTask,
      status: 'pending'
    }]);

    if (!error) {
      setNewTask('');
      if (onRefresh) onRefresh();
    } else {
      console.error('업무 추가 실패:', error.message);
    }
  };

  // 2. 상태 변경 (완료 처리)
  const toggleStatus = async (task: any) => {
    const newStatus = task.status === 'pending' ? 'completed' : 'pending';
    const { error } = await supabase.from('tasks').update({ status: newStatus }).eq('id', task.id);
    if (!error && onRefresh) onRefresh();
  };

  // 3. [에러 방지 핵심] 필터링 로직 수정
  // tasks가 undefined인 경우를 대비해 기본값 빈 배열([])을 보장합니다.
  const filteredTasks = (tasks || []).filter((t: any) => {
    if (subView === '완료') return t.status === 'completed';
    if (subView === '진행중') return t.status === 'pending';
    return true; // 전체
  });

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] h-full relative font-sans">
      {/* 상단 헤더 영역 */}
      <header className="px-10 py-6 flex justify-between items-center bg-white border-b border-gray-50 shrink-0">
        <h1 className="text-xl font-black text-gray-800 italic">업무 리스트</h1>
        <div className="flex gap-2">
          {['전체', '진행중', '완료'].map(menu => (
            <button 
              key={menu} 
              onClick={() => setSubView && setSubView(menu)} 
              className={`px-4 py-1.5 rounded-full text-[10px] font-black transition-all ${subView === menu ? 'bg-black text-white' : 'bg-gray-50 text-gray-400'}`}
            >
              {menu}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-10 custom-scrollbar space-y-6">
        {/* 업무 입력창: 병원장님 스타일의 직관적인 UI */}
        <div className="bg-white p-4 rounded-[1.5rem] shadow-sm border border-gray-100 flex items-center gap-4">
          <input 
            value={newTask} 
            onChange={(e) => setNewTask(e.target.value)} 
            onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
            className="flex-1 bg-transparent p-2 outline-none text-sm font-bold" 
            placeholder="+ 추가할 업무를 입력하고 Enter를 누르세요" 
          />
          <button 
            onClick={handleAddTask} 
            className="w-10 h-10 bg-blue-600 text-white rounded-full font-black shadow-md hover:scale-105 active:scale-95 transition-all"
          >
            +
          </button>
        </div>

        {/* 업무 리스트: 에러 없이 렌더링 */}
        <div className="space-y-3">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-20 text-gray-300 text-[10px] font-bold uppercase tracking-widest">
              No Tasks Found
            </div>
          ) : (
            filteredTasks.map((t: any) => (
              <div 
                key={t.id} 
                className={`p-5 rounded-[1.5rem] border flex items-center justify-between transition-all ${t.status === 'completed' ? 'bg-gray-50/50 border-gray-100 opacity-50' : 'bg-white border-gray-100 shadow-sm hover:border-blue-200'}`}
              >
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => toggleStatus(t)} 
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${t.status === 'completed' ? 'bg-green-500 border-green-500' : 'border-gray-300'}`}
                  >
                    {t.status === 'completed' && <span className="text-white text-[10px]">✓</span>}
                  </button>
                  <span className={`text-sm font-black ${t.status === 'completed' ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                    {t.title}
                  </span>
                </div>
                <span className="text-[10px] font-bold text-gray-300">
                  {t.created_at ? new Date(t.created_at).toLocaleDateString() : '방금 전'}
                </span>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}