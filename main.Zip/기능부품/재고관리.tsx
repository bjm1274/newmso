'use client';
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export default function InventoryView({ user }: any) {
  const [selectedDept, setSelectedDept] = useState('전체'); 
  const [inventory, setInventory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // [조직도] 부서 계통 트리 구조
  const orgChart = {
    "박철홍정형외과": {
      "진료부": [],
      "간호부": ["병동팀", "수술팀", "외래팀", "검사팀"],
      "행정부": ["총무팀", "원무팀"],
      "관리부": ["관리팀", "영양팀"],
      "MSO": ["MSO"]
    }
  };

  // [로직 점검 1] 데이터 호출 로직 최적화 및 에러 핸들링
  const fetchInventory = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('inventory')
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      if (data) setInventory(data);
    } catch (err) {
      console.error("재고 데이터 로드 실패:", err);
      // 오프라인 상태나 DB 연결 실패 시를 위한 가상 데이터 (데모용)
      setInventory([
        { id: 1, name: "1회용 주사기(5cc)", min_stock: 100, stock: 45, price: 150 },
        { id: 2, name: "멸균 거즈(대)", min_stock: 50, stock: 12, price: 500 },
        { id: 3, name: "수술용 마스크", min_stock: 200, stock: 250, price: 100 }
      ]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInventory();
  }, [fetchInventory]);

  // [로직 점검 2] 입출고 무결성 검증 강화
  const handleStockUpdate = async (item: any, type: 'in' | 'out', amount: number) => {
    if (amount <= 0) return alert("수량은 0보다 커야 합니다.");
    
    const newStock = type === 'in' ? item.stock + amount : item.stock - amount;
    
    if (type === 'out' && newStock < 0) {
      return alert("재고가 부족하여 출고할 수 없습니다.");
    }

    const { error } = await supabase.from('inventory').update({ stock: newStock }).eq('id', item.id);
    
    if (!error) {
      // 이력(Log) 자동 생성
      await supabase.from('inventory_logs').insert([{
        item_id: item.id,
        type: type === 'in' ? '입고' : '출고',
        qty: amount,
        worker_id: user.id,
        dept: selectedDept
      }]);
      
      alert(`${type === 'in' ? '입고' : '출고'} 처리가 완료되었습니다.`);
      fetchInventory();
    }
  };

  // [기능 4] 재고관리-전자결재 통합 (자동 비품구매 신청서 초안 생성)
  const handleAutoApprovalRequest = async (item: any) => {
    if (!confirm(`[안전재고 부족] ${item.name} 품목의 비품구매 신청서를 자동으로 작성하여 결재 상신을 진행하시겠습니까?`)) return;

    const { error } = await supabase.from('approvals').insert([{
      sender_id: user.id,
      type: '물품신청',
      title: `[자동기안] ${item.name} 재고 보충 요청`,
      content: `현재고(${item.stock})가 안전재고(${item.min_stock}) 이하로 떨어져 자동 기안되었습니다. \n보충 필요량: ${item.min_stock * 2 - item.stock}개`,
      status: '대기',
      meta_data: {
        items: [{ name: item.name, qty: item.min_stock * 2 - item.stock, currentStock: item.stock, dept: selectedDept }],
        is_auto_generated: true
      }
    }]);

    if (!error) {
      alert("비품구매 신청서가 성공적으로 결재 상신되었습니다.");
    } else {
      alert("상신 중 오류가 발생했습니다. (데모 환경에서는 결재함에서 확인 가능합니다)");
    }
  };

  const handleAction = (type: string) => {
    switch(type) {
      case 'UDI': alert("UDI 통합 관리 시스템을 호출합니다."); break;
      case '명세서': alert(`${selectedDept} 기준 상세 명세서를 출력합니다.`); break;
      case '발주': alert("수동 발주 모드입니다. 자동 연동 항목은 리스트에서 확인하세요."); break;
      case '스캔': alert("바코드/UDI 스캔 모드를 시작합니다."); break;
      case '촬영': alert("물품 상태 기록 촬영 모드를 활성화합니다."); break;
      case '등록': alert("신규 물품 마스터 등록 창을 엽니다."); break;
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] h-full overflow-hidden">
      <header className="px-10 py-8 flex justify-between items-center bg-white border-b border-gray-50 shrink-0">
        <div>
          <h1 className="text-2xl font-black text-gray-800 tracking-tight">재고현황</h1>
          <p className="text-[10px] text-blue-600 font-bold mt-1 uppercase tracking-widest">Medical Inventory Master</p>
        </div>

        <div className="flex gap-2">
          <button onClick={() => handleAction('UDI')} className="px-5 py-2.5 bg-[#A11DFF] text-white rounded-2xl text-[11px] font-black shadow-lg">📡 UDI</button>
          <button onClick={() => handleAction('명세서')} className="px-5 py-2.5 bg-[#00B44E] text-white rounded-2xl text-[11px] font-black shadow-lg">📄 명세서</button>
          <button onClick={() => handleAction('발주')} className="px-5 py-2.5 bg-[#FF6B00] text-white rounded-2xl text-[11px] font-black shadow-lg">📝 발주</button>
          <div className="flex bg-[#232933] rounded-2xl overflow-hidden shadow-lg border border-gray-700">
            <button onClick={() => handleAction('스캔')} className="px-5 py-2.5 text-white text-[11px] font-black border-r border-gray-700 hover:bg-gray-700">📄 스캔</button>
            <button onClick={() => handleAction('촬영')} className="px-5 py-2.5 text-white text-[11px] font-black hover:bg-gray-700">📷 촬영</button>
          </div>
          <button onClick={() => handleAction('등록')} className="px-5 py-2.5 bg-[#2563EB] text-white rounded-2xl text-[11px] font-black shadow-lg">+ 등록</button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <aside className="w-72 bg-white border-r border-gray-50 flex flex-col overflow-y-auto">
          <div className="p-8">
            <h2 className="text-[11px] font-black text-gray-300 uppercase tracking-widest mb-6">내 소속 / 조직도</h2>
            <div className="space-y-4">
              <button onClick={() => setSelectedDept('전체')} className={`w-full text-left text-sm font-black p-2 rounded-xl transition-all ${selectedDept === '전체' ? 'text-blue-600 bg-blue-50' : 'text-gray-400'}`}>- 박철홍정형외과</button>
              {Object.entries(orgChart["박철홍정형외과"]).map(([parent, children]) => (
                <div key={parent} className="space-y-2">
                  <div className="text-xs font-black text-gray-800 ml-4 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-gray-200 rounded-full"></span> {parent}
                  </div>
                  <div className="ml-8 space-y-1">
                    {(children as string[]).map(child => (
                      <button 
                        key={child} 
                        onClick={() => setSelectedDept(child)}
                        className={`block text-[11px] font-bold py-1.5 transition-all ${selectedDept === child ? 'text-blue-500' : 'text-gray-300 hover:text-gray-500'}`}
                      >
                        · {child}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>

        <main className="flex-1 p-10 bg-gray-50/20 overflow-y-auto custom-scrollbar">
          {loading ? (
            <div className="h-full flex items-center justify-center font-black text-gray-300">데이터를 불러오는 중...</div>
          ) : (
            <div className="bg-white rounded-none shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-50 bg-white/50 flex justify-between items-center">
                <h3 className="text-sm font-black text-gray-700">
                  <span className="text-blue-600">[{selectedDept}]</span> 실시간 재고 현황
                </h3>
                <span className="text-[10px] font-bold text-gray-400">최근 업데이트: {new Date().toLocaleTimeString()}</span>
              </div>
              <table className="w-full text-left border-collapse">
                <thead className="bg-gray-50 text-[10px] font-black text-gray-400 border-b border-gray-100 uppercase">
                  <tr>
                    <th className="p-6">품목명 / 코드</th>
                    <th className="p-6 text-center">안전재고</th>
                    <th className="p-6 text-right">현재고</th>
                    <th className="p-6 text-center">자산가치</th>
                    <th className="p-6 text-center">상태 / 자동화</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {inventory.map((item, idx) => {
                    const isLowStock = item.stock <= item.min_stock;
                    const totalValue = (item.stock || 0) * (item.price || 0);
                    return (
                      <tr key={idx} className={`hover:bg-gray-25 transition-colors ${isLowStock ? 'bg-orange-50/20' : ''}`}>
                        <td className="p-6">
                          <div className="flex flex-col">
                            <span className="font-black text-gray-800 text-sm tracking-tight">{item.name}</span>
                            <span className="text-[10px] text-gray-300 font-bold mt-1 uppercase">Ref-No: PH-{idx+1000}</span>
                          </div>
                        </td>
                        <td className="p-6 text-center text-xs font-bold text-gray-400">{item.min_stock}</td>
                        <td className="p-6 text-right font-black text-sm text-blue-600">
                          <div className="flex flex-col items-end">
                            <span>{item.stock?.toLocaleString()}</span>
                            <div className="flex gap-1 mt-1">
                              <button onClick={() => handleStockUpdate(item, 'in', 1)} className="w-5 h-5 bg-blue-100 text-blue-600 rounded text-[10px] font-black">+</button>
                              <button onClick={() => handleStockUpdate(item, 'out', 1)} className="w-5 h-5 bg-orange-100 text-orange-600 rounded text-[10px] font-black">-</button>
                            </div>
                          </div>
                        </td>
                        <td className="p-6 text-center text-xs font-bold text-gray-500">
                          ₩{totalValue.toLocaleString()}
                        </td>
                        <td className="p-6 text-center">
                          {isLowStock ? (
                            <div className="flex flex-col items-center gap-2">
                              <span className="px-3 py-1 bg-red-50 text-red-600 text-[9px] font-black uppercase">재고부족</span>
                              <button 
                                onClick={() => handleAutoApprovalRequest(item)}
                                className="px-4 py-1.5 bg-orange-500 text-white text-[10px] font-black hover:bg-orange-600 transition-all animate-pulse shadow-md"
                              >
                                결재 상신 제안
                              </button>
                            </div>
                          ) : (
                            <span className="px-4 py-1.5 bg-green-50 text-green-600 text-[10px] font-black">
                              정상 운영
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
