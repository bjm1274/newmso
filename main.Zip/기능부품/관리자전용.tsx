'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import StaffManager from './관리자전용서브/직원관리도구';
import ContractManager from './관리자전용서브/계약관리도구';
import PopupManager from './관리자전용서브/팝업창관리자';
import DataReseter from './관리자전용서브/데이터초기화';
import BusinessDashboard from './관리자전용서브/경영대시보드';

export default function AdminView({ user, staffs = [], depts = [], onRefresh }: any) {
  const [activeTab, setActiveTab] = useState('경영대시보드');
  const [inventory, setInventory] = useState([]);

  useEffect(() => {
    const fetchInventory = async () => {
      const { data } = await supabase.from('inventory').select('*');
      if (data) setInventory(data);
    };
    fetchInventory();
  }, []);

  // [권한 체크] admin 역할 확인 (시뮬레이션 환경에서는 통과 가능하도록 설정)
  // if (user?.role !== 'admin') return <div className="p-20 text-center font-black">접근 권한이 없습니다.</div>;

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] h-full relative animate-in fade-in duration-500">
      <header className="px-10 py-8 flex justify-between items-center bg-white border-b border-gray-100 shrink-0 shadow-sm">
        <div>
          <h1 className="text-2xl font-black text-gray-800 tracking-tighter">관리자 센터</h1>
          <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase">통합 시스템 관리 및 설정</p>
        </div>
        <div className="flex gap-1 bg-gray-100 p-1 border border-gray-200">
          {[
            { id: '경영대시보드', label: '📊 경영 대시보드' },
            { id: '직원권한관리', label: '직원 권한 관리' },
            { id: '전자계약설정', label: '전자계약 설정' },
            { id: '팝업관리', label: '팝업 관리' },
            { id: '데이터초기화', label: '시스템 초기화' }
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-2.5 text-[10px] font-black transition-all ${activeTab === tab.id ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400'}`}>
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-10 custom-scrollbar">
        {activeTab === '경영대시보드' && <BusinessDashboard staffs={staffs} inventory={inventory} />}
        {activeTab === '직원권한관리' && <StaffManager staffs={staffs} onRefresh={onRefresh} />}
        {activeTab === '전자계약설정' && <ContractManager />}
        {activeTab === '팝업관리' && <PopupManager />}
        {activeTab === '데이터초기화' && <DataReseter onRefresh={onRefresh} />}
      </main>
    </div>
  );
}
