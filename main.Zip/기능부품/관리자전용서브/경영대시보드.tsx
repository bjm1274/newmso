'use client';
import { useState, useEffect } from 'react';

export default function BusinessDashboard({ staffs, inventory }: any) {
  const [metrics, setMetrics] = useState<any>({
    totalLaborCost: 0,
    inventoryValue: 0,
    pendingApprovals: 0,
    efficiencyScore: 0
  });

  useEffect(() => {
    // [BI 로직] 인사, 재고, 결재 데이터를 통합하여 핵심 경영 지표 산출
    const laborCost = staffs.length * 3500000; // 평균 급여 시뮬레이션
    const invValue = inventory.reduce((acc: number, item: any) => acc + (item.stock * (item.price || 1000)), 0);
    const score = 85 + Math.random() * 10;

    setMetrics({
      totalLaborCost: laborCost,
      inventoryValue: invValue,
      pendingApprovals: 12,
      efficiencyScore: score.toFixed(1)
    });
  }, [staffs, inventory]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* KPI 카드 1: 인건비 */}
        <div className="bg-white p-8 border border-gray-100 shadow-sm flex flex-col justify-between">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">예상 월 인건비</p>
          <div className="mt-4">
            <h4 className="text-2xl font-black text-gray-800">₩{(metrics.totalLaborCost / 10000).toLocaleString()}만</h4>
            <p className="text-[10px] text-red-500 font-bold mt-1">▲ 전월 대비 2.4%</p>
          </div>
        </div>

        {/* KPI 카드 2: 자산가치 */}
        <div className="bg-white p-8 border border-gray-100 shadow-sm flex flex-col justify-between">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">보유 자산 가치</p>
          <div className="mt-4">
            <h4 className="text-2xl font-black text-blue-600">₩{(metrics.inventoryValue / 10000).toLocaleString()}만</h4>
            <p className="text-[10px] text-blue-400 font-bold mt-1">● 적정 재고 수준 유지 중</p>
          </div>
        </div>

        {/* KPI 카드 3: 결재 병목 */}
        <div className="bg-white p-8 border border-gray-100 shadow-sm flex flex-col justify-between">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">미결재 문서</p>
          <div className="mt-4 flex items-baseline gap-2">
            <h4 className="text-3xl font-black text-orange-500">{metrics.pendingApprovals}</h4>
            <span className="text-xs font-bold text-gray-400">건</span>
          </div>
        </div>

        {/* KPI 카드 4: 운영 효율성 */}
        <div className="bg-[#232933] p-8 shadow-xl flex flex-col justify-between">
          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">운영 효율성 점수</p>
          <div className="mt-4">
            <h4 className="text-3xl font-black text-white">{metrics.efficiencyScore}<span className="text-sm ml-1 text-gray-400">pt</span></h4>
            <div className="w-full h-1 bg-white/10 mt-2">
              <div className="h-full bg-green-400" style={{ width: `${metrics.efficiencyScore}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* 부서별 비용 분석 (시뮬레이션 그래프) */}
        <div className="bg-white border border-gray-100 p-8">
          <h3 className="text-xs font-black text-gray-800 uppercase mb-6 tracking-tighter">Department Cost Analysis</h3>
          <div className="space-y-4">
            {['간호부', '진료부', '행정부', '관리부'].map(dept => (
              <div key={dept} className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold">
                  <span className="text-gray-600">{dept}</span>
                  <span className="text-gray-400">₩{Math.floor(Math.random() * 500 + 1000)}만</span>
                </div>
                <div className="w-full h-2 bg-gray-50 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500" style={{ width: `${Math.random() * 60 + 30}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 재고 소모 트렌드 */}
        <div className="bg-white border border-gray-100 p-8">
          <h3 className="text-xs font-black text-gray-800 uppercase mb-6 tracking-tighter">Inventory Consumption Trend</h3>
          <div className="h-40 flex items-end justify-between gap-2 px-4">
            {[40, 65, 45, 90, 55, 70, 85].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full bg-gray-100 relative group">
                  <div 
                    className="w-full bg-blue-600/20 group-hover:bg-blue-600 transition-all cursor-pointer" 
                    style={{ height: `${h}%` }} 
                  />
                </div>
                <span className="text-[8px] font-black text-gray-300">{i+1}월</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
