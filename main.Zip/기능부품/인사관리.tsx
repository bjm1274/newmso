'use client';
import { useState } from 'react';
import 구성원관리 from './인사관리서브/구성원현황'; 
import WorkforcePrediction from './인사관리서브/인력예측';
import CertificateGenerator from './인사관리서브/증명서발급';
// ... 다른 하위 메뉴 임포트

export default function 인사관리({ user, staffs, depts, onRefresh }: any) {
  const [현재메뉴, 메뉴설정] = useState('구성원');
  const [선택사업체, 사업체설정] = useState('전체');
  const [등록창상태, 창상태설정] = useState(false); 

  const 사업체목록 = ["전체", "박철홍정형외과", "SY INC.", "수연의원"];

  // [권한 보안] 행정팀/관리자 외 접근 차단 (서버사이드 로직 권장되나 클라이언트에서도 2차 차단)
  if (user?.department !== '행정팀' && user?.role !== 'admin') {
    return <div className="h-full flex items-center justify-center font-black text-red-500">행정팀 권한이 필요한 메뉴입니다.</div>;
  }

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] h-full relative">
      <header className="px-10 py-8 border-b border-gray-50 flex justify-between items-center bg-white shrink-0 shadow-sm">
        <div>
          <h1 className="text-2xl font-black text-gray-800 tracking-tight italic">인사 정보 제어 (행정팀)</h1>
          <p className="text-xs text-gray-400 font-bold mt-1">박철홍정형외과 통합 인사/증명서 엔진</p>
        </div>
        
        <div className="flex gap-4 items-center">
          <button onClick={() => 창상태설정(true)} className="bg-[#2563EB] text-white px-8 py-3 text-xs font-black shadow-md hover:bg-blue-700 transition-all">신규 직원 등록</button>
          
          <div className="flex gap-1 bg-gray-100 p-1 border border-gray-200">
            {['구성원', '근태', '급여', '예측', '증명서'].map(이름 => (
              <button key={이름} onClick={() => 메뉴설정(이름)} className={`px-6 py-2.5 text-xs font-black transition-all ${현재메뉴 === 이름 ? 'bg-white shadow-md text-blue-600' : 'text-gray-400'}`}>{이름}</button>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        <aside className="w-64 border-r border-gray-100 bg-white flex flex-col shrink-0">
          <div className="p-8">
            <p className="text-[10px] font-black text-gray-400 uppercase mb-4 italic">사업자 필터</p>
            <div className="flex flex-col gap-1">
              {사업체목록.map(회사 => (
                <button key={회사} onClick={() => 사업체설정(회사)} className={`w-full text-left px-4 py-3 text-xs font-black border-l-4 transition-all ${선택사업체 === 회사 ? 'bg-blue-50 border-blue-600 text-blue-600' : 'border-transparent text-gray-400'}`}>{회사}</button>
              ))}
            </div>
          </div>
        </aside>

        <section className="flex-1 overflow-y-auto">
          {현재메뉴 === '구성원' && (
            <구성원관리 
              직원목록={staffs} 부서목록={depts} 선택사업체={선택사업체} 새로고침={onRefresh}
              창상태={등록창상태} 창닫기={() => 창상태설정(false)} 
            />
          )}
          {현재메뉴 === '예측' && <div className="p-10"><WorkforcePrediction staffs={staffs} /></div>}
          {현재메뉴 === '증명서' && <div className="p-10"><CertificateGenerator staffs={staffs} /></div>}
          {/* 급여/근태 등은 기존 컴포넌트 연결 */}
        </section>
      </main>
    </div>
  );
}
