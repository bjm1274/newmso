'use client';
import { useEffect, useLayoutEffect, useState, useRef, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { getProfilePhotoUrl, normalizeProfileUser } from '@/lib/profile-photo';
import SmartDatePicker from './공통/SmartDatePicker';

const NOTICE_ROOM_ID = '00000000-0000-0000-0000-000000000000';
const NOTICE_ROOM_NAME = '공지메시지';
const CAN_WRITE_NOTICE_POSITIONS = ['대표', '부장', '팀장', '실장', '병원장', '이사', '본부장', '총무부장', '진료부장', '간호부장'];
const CHAT_ROOM_KEY = 'erp_chat_last_room';
const CHAT_FOCUS_KEY = 'erp_chat_focus_keyword';
const CHAT_ROOM_PREFS_KEY = 'erp_chat_room_prefs';
const CHAT_PINNED_KEY = 'erp_chat_pinned_messages';
const CHAT_BOOKMARK_KEY = 'erp_chat_bookmarks';
const MESSAGE_READ_WRITES_ENABLED = true;

function sortChatRoomsWithNoticeFirst(rooms: any[]): any[] {
  const notice = rooms.find((r: any) => r.id === NOTICE_ROOM_ID);
  const others = rooms.filter((r: any) => r.id !== NOTICE_ROOM_ID).sort((a: any, b: any) => {
    const at = new Date(a.last_message_at || a.created_at || 0).getTime();
    const bt = new Date(b.last_message_at || b.created_at || 0).getTime();
    return bt - at;
  });
  return notice ? [notice, ...others] : others;
}

function isImageUrl(url: string): boolean {
  const ext = url.split('.').pop()?.toLowerCase();
  return /^(jpg|jpeg|png|gif|webp|bmp|svg)$/.test(ext || '');
}

function isVideoUrl(url: string): boolean {
  const ext = url.split('.').pop()?.toLowerCase();
  return /^(mp4|webm|mov|m4v|avi|mkv)$/.test(ext || '');
}

function normalizeMemberIds(members: any): string[] {
  return Array.isArray(members) ? members.map((id: any) => String(id)) : [];
}

function getDirectRoomMembersKey(room: any): string | null {
  if (room?.type !== 'direct') return null;
  const members = normalizeMemberIds(room?.members);
  if (members.length !== 2) return null;
  return [...members].sort().join('::');
}

type RoomPreference = {
  pinned?: boolean;
  hidden?: boolean;
};

type PresenceInfo = {
  userId: string;
  name: string;
  roomId: string | null;
  onlineAt: string;
};

type MessageRetryPayload = {
  roomId: string;
  content: string;
  fileUrl: string | null;
  fileSizeBytes: number | null;
  fileKind: 'image' | 'video' | 'file' | null;
  replyToId: string | null;
};

type DeliveryState = {
  status: 'sending' | 'failed' | 'sent';
  retryPayload?: MessageRetryPayload;
  error?: string | null;
};

function getRoomPrefsStorageKey(userId: string | null | undefined): string {
  return `${CHAT_ROOM_PREFS_KEY}:${userId || 'guest'}`;
}

function isUuidLike(value: string | null | undefined): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ''));
}

function getPinnedStorageKey(roomId: string | null | undefined): string {
  return `${CHAT_PINNED_KEY}:${roomId || 'none'}`;
}

function getBookmarkStorageKey(userId: string | null | undefined): string {
  return `${CHAT_BOOKMARK_KEY}:${userId || 'guest'}`;
}

function readStoredStringArray(storageKey: string): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(storageKey);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map((value) => String(value)) : [];
  } catch {
    return [];
  }
}

function writeStoredStringArray(storageKey: string, values: string[]) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(storageKey, JSON.stringify(Array.from(new Set(values.map((value) => String(value))))));
  } catch {
    // ignore
  }
}

function writeStoredPinnedIds(roomId: string | null | undefined, messageIds: string[]) {
  writeStoredStringArray(getPinnedStorageKey(roomId), messageIds.slice(0, 1));
}

function readStoredBookmarks(userId: string | null | undefined): string[] {
  return readStoredStringArray(getBookmarkStorageKey(userId));
}

function writeStoredBookmarks(userId: string | null | undefined, messageIds: string[]) {
  writeStoredStringArray(getBookmarkStorageKey(userId), messageIds);
}

function getKoreanTodayString() {
  const now = new Date();
  const koreaNow = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  return koreaNow.toISOString().split('T')[0];
}

function getRoomDisplayName(room: any, staffs: any[], currentUserId: string | null | undefined): string {
  if (!room) return '채팅방';
  if (room.id === NOTICE_ROOM_ID) return NOTICE_ROOM_NAME;
  if (room.type === 'direct') {
    const members = normalizeMemberIds(room.members);
    const otherStaff = staffs.find(
      (staff: any) =>
        members.includes(String(staff.id)) &&
        String(staff.id) !== String(currentUserId)
    );
    if (otherStaff?.name) return otherStaff.name;
  }
  return room.name || '채팅방';
}

function getRoomPreviewText(room: any): string {
  return room?.last_message_preview || room?.last_message || '대화가 없습니다.';
}

function sortRoomsForSidebar(rooms: any[], prefs: Record<string, RoomPreference>): any[] {
  const notice = rooms.find((room: any) => room.id === NOTICE_ROOM_ID);
  const rest = rooms
    .filter((room: any) => room.id !== NOTICE_ROOM_ID)
    .sort((a: any, b: any) => {
      const at = new Date(a.last_message_at || a.created_at || 0).getTime();
      const bt = new Date(b.last_message_at || b.created_at || 0).getTime();
      return bt - at;
    });
  const pinned = rest.filter((room: any) => prefs[room.id]?.pinned);
  const regular = rest.filter((room: any) => !prefs[room.id]?.pinned);
  return notice ? [notice, ...pinned, ...regular] : [...pinned, ...regular];
}

export default function ChatView({ user, onRefresh, staffs = [], initialOpenChatRoomId, initialOpenMessageId, onConsumeOpenChatRoomId }: any) {
  const [messages, setMessages] = useState<any[]>([]);
  const pendingScrollMsgIdRef = useRef<string | null>(null);
  const pendingBottomAlignRoomIdRef = useRef<string | null>(null);
  const [omniSearch, setOmniSearch] = useState('');
  const [chatSearch, setChatSearch] = useState('');
  const [inputMsg, setInputMsg] = useState('');
  const [activeActionMsg, setActiveActionMsg] = useState<any>(null);
  const [replyTo, setReplyTo] = useState<any>(null);
  const [deliveryStates, setDeliveryStates] = useState<Record<string, DeliveryState>>({});
  const [showScrollToLatest, setShowScrollToLatest] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const messageListRef = useRef<HTMLDivElement>(null);
  const composerRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const msgRefs = useRef<any>({});

  const scrollToMessage = (messageId: string) => {
    const el = msgRefs.current[messageId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const origClass = el.className;
      el.classList.add('bg-[var(--toss-blue-light)]', 'rounded-xl', 'transition-colors', 'duration-500');
      setTimeout(() => {
        el.className = origClass;
      }, 2000);
    }
  };

  const renderMessageContent = (content: string) => {
    if (!content) return null;
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = content.split(urlRegex);
    return parts.map((part, i) => {
      if (part.match(urlRegex)) {
        return (
          <a
            key={i}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-500 underline hover:text-blue-600 break-words"
            onClick={(e) => e.stopPropagation()}
          >
            {part}
          </a>
        );
      }
      return <span key={i} className="break-words whitespace-pre-wrap">{part}</span>;
    });
  };

  const lastReadAtRef = useRef<string | null>(null);
  const isFocusedRef = useRef(true);

  const [viewMode, setViewMode] = useState<'chat' | 'org'>('chat');
  const [chatRooms, setChatRooms] = useState<any[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [readCounts, setReadCounts] = useState<Record<string, number>>({});
  const [roomUnreadCounts, setRoomUnreadCounts] = useState<Record<string, number>>({});
  const [showSettings, setShowSettings] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);

  const [roomNotifyOn, setRoomNotifyOn] = useState(true);
  const [editingRoomName, setEditingRoomName] = useState(false);
  const [roomNameDraft, setRoomNameDraft] = useState('');
  const [roomPrefs, setRoomPrefs] = useState<Record<string, RoomPreference>>({});
  const [showHiddenRooms, setShowHiddenRooms] = useState(false);
  const [presenceMap, setPresenceMap] = useState<Record<string, PresenceInfo>>({});
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({});

  const [showGlobalSearch, setShowGlobalSearch] = useState(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchResults, setGlobalSearchResults] = useState<any[]>([]);
  const [globalSearchLoading, setGlobalSearchLoading] = useState(false);


  const chatRoomsRef = useRef<any[]>([]);
  const deliveryStatesRef = useRef<Record<string, DeliveryState>>({});
  const presenceChannelRef = useRef<any>(null);
  const typingChannelRef = useRef<any>(null);
  const typingClearRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingPeersTimeoutRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const syncChannelRef = useRef<BroadcastChannel | null>(null);
  const readWriteInFlightRef = useRef<Set<string>>(new Set());
  const isNearBottomRef = useRef(true);
  const selectedRoomIdRef = useRef<string | null>(null);
  const fetchDataRef = useRef<(() => Promise<void>) | null>(null);

  const [mentionQuery, setMentionQuery] = useState('');
  const [showMentionList, setShowMentionList] = useState(false);

  const [unreadModalMsg, setUnreadModalMsg] = useState<any | null>(null);
  const [unreadUsers, setUnreadUsers] = useState<any[]>([]);
  const [unreadLoading, setUnreadLoading] = useState(false);
  const [chatDirectoryStaffs, setChatDirectoryStaffs] = useState<any[]>([]);
  const [persistedPinnedMessages, setPersistedPinnedMessages] = useState<any[]>([]);

  const permissions = user?.permissions || {};
  const isMso = user?.company === 'SY INC.' || permissions.mso === true || user?.role === 'admin';
  const canWriteNotice = isMso || Boolean(user?.position && CAN_WRITE_NOTICE_POSITIONS.includes(user.position));
  const allKnownStaffs = useMemo(() => {
    const merged = new Map<string, any>();
    [...chatDirectoryStaffs, ...(Array.isArray(staffs) ? staffs : [])].forEach((staff: any) => {
      if (!staff?.id) return;
      const staffId = String(staff.id);
      const previous = merged.get(staffId) || {};
      merged.set(staffId, normalizeProfileUser({ ...previous, ...staff }));
    });
    return Array.from(merged.values());
  }, [chatDirectoryStaffs, staffs]);
  const findKnownStaffById = useCallback(
    (staffId: string | null | undefined) =>
      allKnownStaffs.find((staff: any) => String(staff.id) === String(staffId)) || null,
    [allKnownStaffs]
  );
  const resolveStaffProfile = useCallback(
    (staffId: string | null | undefined, fallbackName?: string | null) => {
      const knownStaff = findKnownStaffById(staffId);
      if (knownStaff) {
        return {
          ...knownStaff,
          photo_url: getProfilePhotoUrl(knownStaff),
        };
      }
      if (String(staffId) === String(user?.id) && user?.name) {
        return {
          id: user.id,
          name: user.name,
          company: user.company || '',
          department: user.department || '',
          position: user.position || '',
          photo_url: getProfilePhotoUrl(user),
        };
      }
      const safeName = String(fallbackName || '').trim();
      if (!safeName) return null;
      return {
        id: staffId,
        name: safeName,
        company: '',
        department: '',
        position: '',
        photo_url: null,
      };
    },
    [findKnownStaffById, user?.avatar_url, user?.company, user?.department, user?.id, user?.name, user?.position]
  );
  const resolveRoomMemberProfile = useCallback(
    (room: any, memberId: string) => {
      const knownStaff = resolveStaffProfile(memberId);
      if (knownStaff) return knownStaff;
      if (room?.type === 'direct' && String(memberId) !== String(user?.id)) {
        return {
          id: memberId,
          name: room?.name || '이름 없음',
          company: '',
          department: '',
          position: '',
          photo_url: null,
        };
      }
      return {
        id: memberId,
        name: '이름 없음',
        company: '',
        department: '',
        position: '',
        photo_url: null,
      };
    },
    [resolveStaffProfile, user?.id]
  );
  const currentStaffProfile = useMemo(() => {
    if (!Array.isArray(allKnownStaffs) || allKnownStaffs.length === 0) return null;
    const sessionUserId = String(user?.id || '').trim();
    if (sessionUserId) {
      const exactMatch = allKnownStaffs.find((staff: any) => String(staff.id) === sessionUserId);
      if (exactMatch) return exactMatch;
    }
    const sessionUserName = String(user?.name || '').trim();
    if (sessionUserName) {
      return allKnownStaffs.find((staff: any) => String(staff.name || '').trim() === sessionUserName) || null;
    }
    return null;
  }, [allKnownStaffs, user?.id, user?.name]);

  useEffect(() => {
    let active = true;
    const loadChatDirectory = async () => {
      try {
        const { data, error } = await supabase
          .from('staff_members')
          .select('id, name, company, department, position, presence_status, last_seen_at, status, permissions');
        if (error) throw error;
        if (active) {
          setChatDirectoryStaffs(Array.isArray(data) ? data.map((staff: any) => normalizeProfileUser(staff)) : []);
        }
      } catch (error) {
        console.error('채팅 직원 디렉터리 로드 실패:', error);
        if (active) {
          setChatDirectoryStaffs([]);
        }
      }
    };
    void loadChatDirectory();
    return () => {
      active = false;
    };
  }, []);
  const effectiveTodoUserId = useMemo(() => {
    if (isUuidLike(user?.id)) {
      return String(user.id);
    }
    if (currentStaffProfile?.id) {
      return String(currentStaffProfile.id);
    }
    return String(user?.id || '').trim();
  }, [currentStaffProfile?.id, user?.id]);
  const effectiveChatUserId = useMemo(() => {
    const currentStaffId = String(currentStaffProfile?.id || '').trim();
    if (currentStaffId) {
      return currentStaffId;
    }
    return String(user?.id || '').trim();
  }, [currentStaffProfile?.id, user?.id]);

  const repairDirectRooms = useCallback(async (rooms: any[]) => {
    const sourceRooms = Array.isArray(rooms) ? rooms : [];
    const orphanRooms = sourceRooms.filter((room: any) =>
      room?.type === 'direct' && (!Array.isArray(room.members) || room.members.length === 0)
    );
    if (orphanRooms.length === 0) {
      return sourceRooms;
    }

    try {
      const orphanRoomIds = orphanRooms
        .map((room: any) => String(room?.id || '').trim())
        .filter(Boolean);
      if (orphanRoomIds.length === 0) {
        return sourceRooms;
      }

      const { data: roomMessages, error } = await supabase
        .from('messages')
        .select('room_id, sender_id, created_at')
        .in('room_id', orphanRoomIds)
        .not('sender_id', 'is', null)
        .order('created_at', { ascending: false });
      if (error) throw error;

      const senderIdsByRoom = new Map<string, Set<string>>();
      (roomMessages || []).forEach((message: any) => {
        const roomId = String(message?.room_id || '').trim();
        const senderId = String(message?.sender_id || '').trim();
        if (!roomId || !senderId || senderId === 'null' || senderId === 'undefined') return;
        const senders = senderIdsByRoom.get(roomId) || new Set<string>();
        senders.add(senderId);
        senderIdsByRoom.set(roomId, senders);
      });

      const repairedRooms = [...sourceRooms];
      for (const room of orphanRooms) {
        const roomId = String(room?.id || '').trim();
        const inferredMembers = Array.from(senderIdsByRoom.get(roomId) || []);
        if (inferredMembers.length !== 2) continue;

        const { error: updateError } = await supabase
          .from('chat_rooms')
          .update({ members: inferredMembers })
          .eq('id', roomId);
        if (updateError) throw updateError;

        const roomIndex = repairedRooms.findIndex((candidate: any) => String(candidate?.id) === roomId);
        if (roomIndex >= 0) {
          repairedRooms[roomIndex] = {
            ...repairedRooms[roomIndex],
            members: inferredMembers,
          };
        }
      }

      return repairedRooms;
    } catch (error) {
      console.error('repairDirectRooms failed', error);
      return sourceRooms;
    }
  }, []);

  const setRoom = (roomId: string | null) => {
    pendingBottomAlignRoomIdRef.current = roomId;
    isNearBottomRef.current = true;
    setShowScrollToLatest(false);
    setSelectedRoomId(roomId);
    if (typeof window === 'undefined') return;
    try {
      if (roomId) {
        window.localStorage.setItem(CHAT_ROOM_KEY, roomId);
      } else {
        window.localStorage.removeItem(CHAT_ROOM_KEY);
      }
    } catch {
    }
  };

  const updateRoomPreference = useCallback((roomId: string, patch: RoomPreference) => {
    setRoomPrefs((prev) => {
      const next = {
        ...prev,
        [roomId]: {
          ...(prev[roomId] || {}),
          ...patch,
        },
      };
      if (typeof window !== 'undefined') {
        try {
          window.localStorage.setItem(getRoomPrefsStorageKey(user?.id), JSON.stringify(next));
        } catch {
          // ignore
        }
      }
      return next;
    });
  }, [user?.id]);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    const listEl = messageListRef.current;
    if (listEl) {
      if (behavior === 'auto') {
        listEl.scrollTop = listEl.scrollHeight;
      } else {
        listEl.scrollTo({ top: listEl.scrollHeight, behavior });
      }
    } else {
      scrollRef.current?.scrollIntoView({ behavior, block: 'end' });
    }
    requestAnimationFrame(() => {
      composerRef.current?.scrollIntoView({
        behavior,
        block: 'end',
        inline: 'nearest',
      });
    });
    isNearBottomRef.current = true;
    setShowScrollToLatest(false);
  }, []);

  const persistMessageReads = useCallback(async (messageIds: string[]) => {
    if (!user?.id || messageIds.length === 0) return;
    if (!MESSAGE_READ_WRITES_ENABLED) return;

    const uniqueMessageIds = Array.from(new Set(messageIds.map((id) => String(id))));
    const candidateIds = uniqueMessageIds.filter((id) => !readWriteInFlightRef.current.has(id));
    if (candidateIds.length === 0) return;
    candidateIds.forEach((id) => readWriteInFlightRef.current.add(id));

    try {
      const readAt = new Date().toISOString();
      await supabase.from('message_reads').upsert(
        candidateIds.map((id) => ({
          user_id: user.id,
          message_id: id,
          read_at: readAt,
        })),
        { onConflict: 'user_id,message_id' }
      );
    } finally {
      candidateIds.forEach((id) => readWriteInFlightRef.current.delete(id));
    }
  }, [user?.id]);

  const updateScrollPositionState = useCallback(() => {
    const listEl = messageListRef.current;
    if (!listEl) return;
    const nearBottom = listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight < 96;
    isNearBottomRef.current = nearBottom;
    setShowScrollToLatest(!nearBottom && Boolean(selectedRoomId));
  }, [selectedRoomId]);

  const broadcastChatSync = useCallback((action: string, roomId?: string | null) => {
    if (!syncChannelRef.current) return;
    try {
      syncChannelRef.current.postMessage({
        action,
        roomId: roomId || selectedRoomId || null,
        at: Date.now(),
      });
    } catch {
      // ignore
    }
  }, [selectedRoomId]);

  const triggerChatPush = useCallback(async (roomId: string, messageId: string) => {
    try {
      const response = await fetch('/api/notifications/chat-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, messageId }),
      });

      if (!response.ok) {
        const payload = await response.json().catch(() => null);
        throw new Error(payload?.error || `push trigger failed (${response.status})`);
      }
    } catch (error) {
      console.error('chat push trigger failed', error);
    }
  }, []);

  const emitTypingState = useCallback((isTyping: boolean) => {
    if (!typingChannelRef.current || !selectedRoomId || !user?.id) return;
    typingChannelRef.current.send({
      type: 'broadcast',
      event: 'typing',
      payload: {
        roomId: selectedRoomId,
        userId: String(user.id),
        name: user.name || 'Unknown',
        isTyping,
      },
    });
  }, [selectedRoomId, user?.id, user?.name]);

  const handleComposerChange = useCallback((value: string, caret: number) => {
    setInputMsg(value);
    const upToCaret = value.slice(0, caret);
    const match = upToCaret.match(/@([^\s@]{0,20})$/);
    if (match) {
      setMentionQuery(match[1] || '');
      setShowMentionList(true);
    } else {
      setShowMentionList(false);
      setMentionQuery('');
    }

    if (typingClearRef.current) {
      clearTimeout(typingClearRef.current);
      typingClearRef.current = null;
    }

    if (value.trim()) {
      emitTypingState(true);
      typingClearRef.current = setTimeout(() => {
        emitTypingState(false);
        typingClearRef.current = null;
      }, 1800);
    } else {
      emitTypingState(false);
    }
  }, [emitTypingState]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const raw = window.localStorage.getItem(getRoomPrefsStorageKey(user?.id));
      setRoomPrefs(raw ? JSON.parse(raw) : {});
    } catch {
      setRoomPrefs({});
    }
  }, [user?.id]);

  useEffect(() => {
    deliveryStatesRef.current = deliveryStates;
  }, [deliveryStates]);

  useEffect(() => {
    const composerEl = composerRef.current;
    if (!composerEl) return;
    composerEl.style.height = '0px';
    composerEl.style.height = `${Math.min(120, composerEl.scrollHeight)}px`;
  }, [inputMsg]);

  const [polls, setPolls] = useState<any[]>([]);
  const [pollVotes, setPollVotes] = useState<any>({});
  const [reactions, setReactions] = useState<any>({});
  const [pinnedIds, setPinnedIds] = useState<string[]>([]);
  const [showPollModal, setShowPollModal] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
const [pollOptions, setPollOptions] = useState<string[]>(['찬성', '반대']);
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());
  const [showMediaPanel, setShowMediaPanel] = useState(false);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video' | 'file'>('all');

  const [showForwardModal, setShowForwardModal] = useState(false);
  const [forwardSourceMsg, setForwardSourceMsg] = useState<any>(null);

  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [addMemberSearch, setAddMemberSearch] = useState('');
  const [addMemberSelectingIds, setAddMemberSelectingIds] = useState<string[]>([]);

  const [threadRoot, setThreadRoot] = useState<any | null>(null);

  const [slashCommand, setSlashCommand] = useState<'annual_leave' | 'purchase' | null>(null);
  const [showSlashModal, setShowSlashModal] = useState(false);
  const [slashForm, setSlashForm] = useState<any>({
    startDate: '',
    endDate: '',
    reason: '',
    itemName: '',
    quantity: 1,
  });

  const updateUnreadForRooms = useCallback(
    async (rooms: any[]) => {
      if (!user?.id || !rooms?.length) return;
      try {
        // 내가 멤버인 방만 카운트 (NOTICE_ROOM_ID 포함)
        const myRooms = rooms.filter((r: any) => {
          if (r.id === NOTICE_ROOM_ID) return true;
          if (Array.isArray(r.members)) {
            return r.members.some((id: any) => String(id) === effectiveChatUserId);
          }
          return false;
        });
        if (!myRooms.length) return;
        const roomIds = myRooms.map((r: any) => r.id);
        const { data: cursors } = await supabase
          .from('room_read_cursors')
          .select('room_id, last_read_at')
          .eq('user_id', user.id)
          .in('room_id', roomIds);

        const cursorMap: Record<string, string | null> = {};
        (cursors || []).forEach((c: any) => {
          cursorMap[c.room_id] = c.last_read_at;
        });

        const counts: Record<string, number> = {};
        for (const roomId of roomIds) {
          const last = cursorMap[roomId];
          let query = supabase
            .from('messages')
            .select('id', { count: 'exact', head: true })
            .eq('room_id', roomId)
            .neq('sender_id', effectiveChatUserId)
            .eq('is_deleted', false);
          if (last) query = query.gt('created_at', last);
          const { count } = await query;
          counts[roomId] = count || 0;
        }
        setRoomUnreadCounts(counts);
      } catch (e) {
        console.error('채팅방별 안읽은 메시지 계산 실패:', e);
      }
    },
    [effectiveChatUserId, user?.id]
  );

  const syncChatRoomsState = useCallback(async (rooms: any[]) => {
    const repairedRooms = await repairDirectRooms(rooms);
    const list = sortChatRoomsWithNoticeFirst(repairedRooms || []);
    setChatRooms(list);
    await updateUnreadForRooms(list);
    return list;
  }, [repairDirectRooms, updateUnreadForRooms]);

  useEffect(() => {
    chatRoomsRef.current = chatRooms;
  }, [chatRooms]);

  useEffect(() => {
    selectedRoomIdRef.current = selectedRoomId;
  }, [selectedRoomId]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const saved = window.localStorage.getItem(CHAT_ROOM_KEY);
      if (saved && saved !== 'null' && saved !== 'undefined') {
        pendingBottomAlignRoomIdRef.current = saved;
        isNearBottomRef.current = true;
        setShowScrollToLatest(false);
        setSelectedRoomId(saved);
      } else {
        pendingBottomAlignRoomIdRef.current = NOTICE_ROOM_ID;
        isNearBottomRef.current = true;
        setShowScrollToLatest(false);
        setSelectedRoomId(NOTICE_ROOM_ID);
      }
    } catch {
      pendingBottomAlignRoomIdRef.current = NOTICE_ROOM_ID;
      isNearBottomRef.current = true;
      setShowScrollToLatest(false);
      setSelectedRoomId(NOTICE_ROOM_ID);
    }
  }, []);

  useEffect(() => {
    if (initialOpenChatRoomId) {
      setRoom(initialOpenChatRoomId);
      if (initialOpenMessageId) {
        pendingScrollMsgIdRef.current = initialOpenMessageId;
      }
      onConsumeOpenChatRoomId?.();
    }
  }, [initialOpenChatRoomId, initialOpenMessageId]);

  useEffect(() => {
    const targetMsgId = pendingScrollMsgIdRef.current;
    if (targetMsgId && messages.length > 0) {
      if (messages.some(m => m.id === targetMsgId)) {
        setTimeout(() => {
          scrollToMessage(targetMsgId);
          pendingScrollMsgIdRef.current = null;
        }, 500);
      }
    }
  }, [messages]);

  const fetchData = useCallback(async () => {
    if (!selectedRoomId) return;
    const { data: roomRows } = await supabase.from('chat_rooms').select('*');
    const repairedRooms = await repairDirectRooms(roomRows || []);
    const selectedRoomRecord =
      repairedRooms.find((room: any) => String(room.id) === String(selectedRoomId)) || null;
    const selectedRoomKey = getDirectRoomMembersKey(selectedRoomRecord);
    const canonicalDirectRoom = selectedRoomKey
      ? repairedRooms
          .filter((room: any) => getDirectRoomMembersKey(room) === selectedRoomKey)
          .sort((a: any, b: any) =>
            new Date(b.last_message_at || b.created_at || 0).getTime() -
            new Date(a.last_message_at || a.created_at || 0).getTime()
          )[0]
      : null;
    if (canonicalDirectRoom?.id && String(canonicalDirectRoom.id) !== String(selectedRoomId)) {
      setRoom(String(canonicalDirectRoom.id));
    }
    const roomIdsToLoad = Array.from(
      new Set(
        selectedRoomKey
          ? repairedRooms
              .filter((room: any) => getDirectRoomMembersKey(room) === selectedRoomKey)
              .map((room: any) => String(room.id))
          : [String(selectedRoomId)]
      )
    );

    const query = supabase
      .from('messages')
      .select('*')
      .in('room_id', roomIdsToLoad)
      .order('created_at', { ascending: true });
    const { data: msgs } = await query;
    if (msgs) {
      const enrichedMessages = msgs.map((msg: any) => {
        const matchedStaff = resolveStaffProfile(msg.sender_id);
        return {
          ...msg,
          staff: msg.staff || matchedStaff,
        };
      });
      setMessages((prev) => {
        const localOnly = prev.filter((msg: any) => {
          const id = String(msg.id || '');
          return id.startsWith('temp-') && deliveryStatesRef.current[id]?.status !== 'sent';
        });
        return [...enrichedMessages, ...localOnly].sort(
          (a: any, b: any) =>
            new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime()
        );
      });
    }

    const list = await syncChatRoomsState(repairedRooms);

    if (msgs?.length) {
      const ids = msgs.map((m: any) => String(m.id));
      const { data: reads } = await supabase.from('message_reads').select('message_id').in('message_id', ids);
      const counts: Record<string, number> = {};
      reads?.forEach((r: any) => { counts[r.message_id] = (counts[r.message_id] || 0) + 1; });
      setReadCounts(counts);
      if (effectiveTodoUserId) {
        try {
          const { data: bookmarks, error: bookmarkError } = await supabase
            .from('message_bookmarks')
            .select('message_id')
            .eq('user_id', effectiveTodoUserId)
            .in('message_id', ids);
          if (bookmarkError) throw bookmarkError;
          const nextBookmarkIds = (bookmarks || []).map((bookmark: any) => String(bookmark.message_id));
          setBookmarkedIds(new Set(nextBookmarkIds));
          writeStoredBookmarks(effectiveTodoUserId, nextBookmarkIds);
        } catch {
          setBookmarkedIds(new Set(readStoredBookmarks(effectiveTodoUserId).filter((bookmarkId) => ids.includes(bookmarkId))));
        }
      }
    } else {
      setReadCounts({});
      setBookmarkedIds(new Set(readStoredBookmarks(effectiveTodoUserId)));
    }

    try {
      const { data: pinned, error: pinnedError } = await supabase
        .from('pinned_messages')
        .select('message_id')
        .eq('room_id', selectedRoomId);
      if (pinnedError) throw pinnedError;
      const nextPinnedIds = (pinned || []).map((item: any) => String(item.message_id)).slice(-1);
      setPinnedIds(nextPinnedIds);
      writeStoredPinnedIds(selectedRoomId, nextPinnedIds);
      if (nextPinnedIds.length > 0) {
        const pinnedLookup = new Map<string, any>();
        (msgs || []).forEach((msg: any) => {
          const messageId = String(msg.id);
          if (!nextPinnedIds.includes(messageId)) return;
          pinnedLookup.set(messageId, {
            ...msg,
            staff: msg.staff || resolveStaffProfile(msg.sender_id),
          });
        });
        const missingPinnedIds = nextPinnedIds.filter((messageId) => !pinnedLookup.has(messageId));
        if (missingPinnedIds.length > 0) {
          const { data: pinnedRows, error: pinnedRowsError } = await supabase
            .from('messages')
            .select('*')
            .in('id', missingPinnedIds);
          if (pinnedRowsError) throw pinnedRowsError;
          (pinnedRows || []).forEach((msg: any) => {
            pinnedLookup.set(String(msg.id), {
              ...msg,
              staff: resolveStaffProfile(msg.sender_id),
            });
          });
        }
        setPersistedPinnedMessages(
          nextPinnedIds
            .map((messageId) => pinnedLookup.get(messageId))
            .filter(Boolean)
        );
      } else {
        setPersistedPinnedMessages([]);
      }
    } catch (error) {
      console.error('공지 메시지 불러오기 실패:', error);
      setPersistedPinnedMessages([]);
    }

    try {
      const { data: reacts } = await supabase.from('message_reactions').select('message_id, emoji');
      const reactMap: Record<string, Record<string, number>> = {};
      reacts?.forEach((r: any) => {
        if (!reactMap[r.message_id]) reactMap[r.message_id] = {};
        reactMap[r.message_id][r.emoji] = (reactMap[r.message_id][r.emoji] || 0) + 1;
      });
      setReactions(reactMap);

      const { data: dbPolls } = await supabase.from('polls').select('*').eq('room_id', selectedRoomId);
      if (dbPolls?.length) {
        setPolls(dbPolls);
      } else {
        setPolls([]);
      }
      const { data: votes } = await supabase.from('poll_votes').select('poll_id, option_index');
      const vMap: any = {};
      votes?.forEach((v: any) => {
        if (!vMap[v.poll_id]) vMap[v.poll_id] = {};
        vMap[v.poll_id][v.option_index] = (vMap[v.poll_id][v.option_index] || 0) + 1;
      });
      setPollVotes(vMap);
    } catch (error) {
      console.error('반응/투표 데이터 불러오기 실패:', error);
    }

    if (selectedRoomId && msgs?.length) {
      const unreadMsgIds = msgs
        .filter((m: any) => String(m.sender_id) !== effectiveChatUserId)
        .filter((m: any) => {
          return true;
        })
        .map((m: any) => m.id);

      if (unreadMsgIds.length > 0) {
        try {
          await persistMessageReads(unreadMsgIds);
          broadcastChatSync('message-read', selectedRoomId);

          // table notification_settings might not exist
          try {
            await supabase.from('room_read_cursors').upsert({
              user_id: user.id,
              room_id: selectedRoomId,
              last_read_at: new Date().toISOString()
            }, { onConflict: 'user_id,room_id' });
          } catch (e) {
            console.warn('room_read_cursors upsert skip');
          }

          setReadCounts(prev => {
            const next = { ...prev };
            unreadMsgIds.forEach(id => {
              if (!next[id]) next[id] = 0;
            });
            return next;
          });

          setRoomUnreadCounts(prev => ({ ...prev, [selectedRoomId]: 0 }));
        } catch (e) {
          console.error('자동 읽음 처리 실패:', e);
        }
      }
    }
  }, [selectedRoomId, user?.id, effectiveChatUserId, effectiveTodoUserId, repairDirectRooms, syncChatRoomsState, persistMessageReads, broadcastChatSync, resolveStaffProfile]);

  const roomNotifyRef = useRef(true);
  useEffect(() => { roomNotifyRef.current = roomNotifyOn; }, [roomNotifyOn]);

  // fetchDataRef를 항상 최신 fetchData로 동기화
  useEffect(() => { fetchDataRef.current = fetchData; }, [fetchData]);

  useEffect(() => {
    const loadRooms = async () => {
      const { data: noticeRoom } = await supabase
        .from('chat_rooms')
        .select('id')
        .eq('id', NOTICE_ROOM_ID)
        .maybeSingle();

      if (!noticeRoom) {
        await supabase.from('chat_rooms').insert([
          { id: NOTICE_ROOM_ID, name: NOTICE_ROOM_NAME, type: 'notice', members: [] },
        ]);
      } else {
        await supabase
          .from('chat_rooms')
          .update({ name: NOTICE_ROOM_NAME, type: 'notice' })
          .eq('id', NOTICE_ROOM_ID);
      }
      const { data: rooms } = await supabase.from('chat_rooms').select('*');
      await syncChatRoomsState(rooms || []);
    };
    loadRooms();
    // selectedRoomId는 의도적으로 제외 — 채팅방 목록은 마운트 시 1회만 로드
  }, [syncChatRoomsState]);

  useEffect(() => {
    const channel = supabase.channel('chat-rooms-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_rooms' }, () => {
        supabase.from('chat_rooms').select('*').then(async ({ data: rooms }) => {
          if (!rooms) return;
          await syncChatRoomsState(rooms);
        });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [syncChatRoomsState]);

  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase.channel('chat-presence-hub', {
      config: { presence: { key: String(user.id) } },
    });

    const syncPresence = () => {
      const next: Record<string, PresenceInfo> = {};
      const state = channel.presenceState();
      Object.values(state).forEach((entries: any) => {
        if (!Array.isArray(entries) || entries.length === 0) return;
        const latest = entries[entries.length - 1];
        if (!latest?.userId) return;
        next[String(latest.userId)] = {
          userId: String(latest.userId),
          name: latest.name || 'Unknown',
          roomId: latest.roomId || null,
          onlineAt: latest.onlineAt || new Date().toISOString(),
        };
      });
      setPresenceMap(next);
    };

    channel
      .on('presence', { event: 'sync' }, syncPresence)
      .subscribe(async (status: string) => {
        if (status !== 'SUBSCRIBED') return;
        presenceChannelRef.current = channel;
        await channel.track({
          userId: String(user.id),
          name: user.name || 'Unknown',
          roomId: selectedRoomId || null,
          onlineAt: new Date().toISOString(),
        });
      });

    return () => {
      if (presenceChannelRef.current === channel) {
        presenceChannelRef.current = null;
      }
      supabase.removeChannel(channel);
    };
  }, [user?.id, user?.name]);

  useEffect(() => {
    if (!presenceChannelRef.current || !user?.id) return;
    presenceChannelRef.current.track({
      userId: String(user.id),
      name: user.name || 'Unknown',
      roomId: selectedRoomId || null,
      onlineAt: new Date().toISOString(),
    });
  }, [selectedRoomId, user?.id, user?.name]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const key = window.localStorage.getItem(CHAT_FOCUS_KEY);
      if (key) {
        setOmniSearch(key);
        window.localStorage.removeItem(CHAT_FOCUS_KEY);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase
      .channel('chat-global-messages')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        async (payload: any) => {
          const msg: any = payload.new;
          if (!msg || String(msg.sender_id) === effectiveChatUserId) return;
          if (chatRoomsRef.current.length) {
            await updateUnreadForRooms(chatRoomsRef.current);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // selectedRoomId는 의도적으로 제외 — 전역 메시지 채널은 user 기준으로만 구독
  }, [user?.id, updateUnreadForRooms]);

  useEffect(() => {
    if (!selectedRoomId) return;
    fetchData();
    const channel = supabase.channel(`chat-realtime-${selectedRoomId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${selectedRoomId}` }, (payload: any) => {
        const row = payload.new;
        if (!row?.id) return;
        setMessages((prev) => {
          if (prev.some((m: any) => m.id === row.id)) return prev;
          const newMsg = {
            ...row,
            staff: resolveStaffProfile(row.sender_id, row.sender_name) || { name: '이름 없음', photo_url: null },
          };
          return [...prev, newMsg];
        });
        setChatRooms((prev) =>
          sortChatRoomsWithNoticeFirst(
            prev.map((room: any) =>
              room.id === row.room_id
                ? {
                    ...room,
                    last_message: row.content || (row.file_url ? '첨부파일' : room.last_message),
                    last_message_preview: row.content || (row.file_url ? '첨부파일' : room.last_message_preview),
                    last_message_at: row.created_at || new Date().toISOString(),
                  }
                : room
            )
          )
        );
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `room_id=eq.${selectedRoomId}` }, () => fetchData())
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages', filter: `room_id=eq.${selectedRoomId}` }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_rooms' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reads' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_bookmarks', filter: `user_id=eq.${user?.id}` }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'pinned_messages' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'polls' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'poll_votes' }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedRoomId, fetchData, user?.id, resolveStaffProfile]);

  useEffect(() => {
    if (!selectedRoomId) {
      setTypingUsers({});
      if (typingChannelRef.current) {
        supabase.removeChannel(typingChannelRef.current);
        typingChannelRef.current = null;
      }
      return;
    }

    const channel = supabase.channel(`chat-typing-${selectedRoomId}`);
    typingChannelRef.current = channel;

    channel
      .on('broadcast', { event: 'typing' }, ({ payload }: any) => {
        if (!payload || payload.roomId !== selectedRoomId || payload.userId === String(user?.id)) return;

        const peerId = String(payload.userId);
        if (typingPeersTimeoutRef.current[peerId]) {
          clearTimeout(typingPeersTimeoutRef.current[peerId]);
          delete typingPeersTimeoutRef.current[peerId];
        }

        if (!payload.isTyping) {
          setTypingUsers((prev) => {
            const next = { ...prev };
            delete next[peerId];
            return next;
          });
          return;
        }

        setTypingUsers((prev) => ({
          ...prev,
          [peerId]: payload.name || 'Unknown',
        }));

        typingPeersTimeoutRef.current[peerId] = setTimeout(() => {
          setTypingUsers((prev) => {
            const next = { ...prev };
            delete next[peerId];
            return next;
          });
          delete typingPeersTimeoutRef.current[peerId];
        }, 2500);
      })
      .subscribe((status: string) => {
        if (status === 'SUBSCRIBED') {
          emitTypingState(false);
        }
      });

    return () => {
      if (typingClearRef.current) {
        clearTimeout(typingClearRef.current);
        typingClearRef.current = null;
      }
      Object.values(typingPeersTimeoutRef.current).forEach((timer) => clearTimeout(timer));
      typingPeersTimeoutRef.current = {};
      setTypingUsers({});
      if (typingChannelRef.current === channel) {
        typingChannelRef.current = null;
      }
      supabase.removeChannel(channel);
    };
  }, [selectedRoomId, user?.id, emitTypingState]);

  useEffect(() => {
    const onFocus = () => { isFocusedRef.current = true; };
    const onBlur = () => { isFocusedRef.current = false; };
    window.addEventListener('focus', onFocus);
    window.addEventListener('blur', onBlur);
    return () => { window.removeEventListener('focus', onFocus); window.removeEventListener('blur', onBlur); };
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') return;
    const channel = new BroadcastChannel('erp-chat-sync');
    syncChannelRef.current = channel;
    channel.onmessage = (event) => {
      const payload = event.data;
      if (!payload?.roomId) return;
      // ref를 통해 항상 최신 selectedRoomId와 fetchData를 참조 (채널 재생성 없이)
      if (payload.roomId === selectedRoomIdRef.current) {
        fetchDataRef.current?.();
      } else if (chatRoomsRef.current.length > 0) {
        updateUnreadForRooms(chatRoomsRef.current);
      }
    };
    return () => {
      if (syncChannelRef.current === channel) {
        syncChannelRef.current = null;
      }
      channel.close();
    };
    // 마운트 시 1회만 실행 — selectedRoomId·fetchData는 ref로 최신값 참조
  }, [updateUnreadForRooms]);

  useEffect(() => {
    if (!user?.id) return;
    const refreshRealtimeFallback = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
      if (selectedRoomId) {
        fetchData();
      } else if (chatRoomsRef.current.length > 0) {
        updateUnreadForRooms(chatRoomsRef.current);
      }
    };

    const interval = setInterval(refreshRealtimeFallback, 15000);
    window.addEventListener('focus', refreshRealtimeFallback);
    document.addEventListener('visibilitychange', refreshRealtimeFallback);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', refreshRealtimeFallback);
      document.removeEventListener('visibilitychange', refreshRealtimeFallback);
    };
  }, [selectedRoomId, user?.id, fetchData, updateUnreadForRooms]);

  useEffect(() => {
    if (!selectedRoomId || messages.length === 0) return;
    const lastMessage = messages[messages.length - 1];
    const shouldStick =
      isNearBottomRef.current ||
      String(lastMessage?.sender_id) === String(user?.id) ||
      String(lastMessage?.id || '').startsWith('temp-');
    if (shouldStick) {
      requestAnimationFrame(() => scrollToBottom(String(lastMessage?.sender_id) === String(user?.id) ? 'smooth' : 'auto'));
    } else {
      setShowScrollToLatest(true);
    }
  }, [messages, selectedRoomId, scrollToBottom, user?.id]);

  useEffect(() => {
    if (!selectedRoomId) return;
    requestAnimationFrame(() => scrollToBottom('auto'));
  }, [selectedRoomId, scrollToBottom]);

  useLayoutEffect(() => {
    if (!selectedRoomId) {
      pendingBottomAlignRoomIdRef.current = null;
      return;
    }
    if (pendingBottomAlignRoomIdRef.current !== selectedRoomId) return;

    let cancelled = false;
    let firstFrame = 0;
    let secondFrame = 0;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    const alignToLatest = () => {
      firstFrame = requestAnimationFrame(() => {
        secondFrame = requestAnimationFrame(() => {
          if (cancelled || pendingBottomAlignRoomIdRef.current !== selectedRoomId) return;
          scrollToBottom('auto');
          const listEl = messageListRef.current;
          if (!listEl) {
            pendingBottomAlignRoomIdRef.current = null;
            return;
          }
          const distanceFromBottom = listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight;
          if (distanceFromBottom < 24) {
            pendingBottomAlignRoomIdRef.current = null;
          }
        });
      });
    };

    alignToLatest();
    retryTimer = setTimeout(alignToLatest, 120);

    return () => {
      cancelled = true;
      cancelAnimationFrame(firstFrame);
      cancelAnimationFrame(secondFrame);
      if (retryTimer) {
        clearTimeout(retryTimer);
      }
    };
  }, [selectedRoomId, messages.length, polls.length, pinnedIds.length, persistedPinnedMessages.length, scrollToBottom]);

  const pinnedMessages = useMemo(
    () => messages.filter((m) => pinnedIds.includes(String(m.id))),
    [messages, pinnedIds]
  );

  const noticeMessages = useMemo(
    () => (persistedPinnedMessages.length > 0 ? persistedPinnedMessages : pinnedMessages),
    [persistedPinnedMessages, pinnedMessages]
  );

  const currentNoticeMessage = useMemo(
    () => noticeMessages[noticeMessages.length - 1] || null,
    [noticeMessages]
  );


  const roomMembers = useMemo(() => {
    if (!selectedRoomId) return [];
    if (selectedRoomId === NOTICE_ROOM_ID) return allKnownStaffs;
    const room = chatRooms.find((r: any) => r.id === selectedRoomId);
    if (!room || !Array.isArray(room.members) || !room.members.length) return [];
    return room.members.map((id: any) => resolveRoomMemberProfile(room, String(id)));
  }, [allKnownStaffs, chatRooms, resolveRoomMemberProfile, selectedRoomId]);

  const selectedRoom = useMemo(
    () => chatRooms.find((r: any) => r.id === selectedRoomId) || null,
    [chatRooms, selectedRoomId]
  );

  const selectedRoomLabel = useMemo(
    () => getRoomDisplayName(selectedRoom, allKnownStaffs, effectiveChatUserId),
    [selectedRoom, allKnownStaffs, effectiveChatUserId]
  );

  const addableMembers = useMemo(() => {
    if (!selectedRoom) return [];
    const currentMemberIds = new Set(
      Array.isArray(selectedRoom.members)
        ? selectedRoom.members.map((id: any) => String(id))
        : []
    );
    return staffs
      .filter((s: any) => !currentMemberIds.has(String(s.id)))
      .filter((s: any) => {
        if (!addMemberSearch.trim()) return true;
        const key = addMemberSearch.trim();
        return (
          s.name?.includes(key) ||
          s.department?.includes(key) ||
          s.position?.includes(key)
        );
      });
  }, [selectedRoom, staffs, addMemberSearch]);

  const visibleRooms = useMemo(
    () => {
      const dedupedRooms = new Map<string, any>();
      chatRooms.forEach((room: any) => {
        if (room.id === NOTICE_ROOM_ID) return true;
        if (Array.isArray(room.members)) {
          const isMember = room.members.some((id: any) => String(id) === effectiveChatUserId);
          if (!isMember) return;
          const roomKey = getDirectRoomMembersKey(room) || `room:${room.id}`;
          const previousRoom = dedupedRooms.get(roomKey);
          const previousTime = new Date(previousRoom?.last_message_at || previousRoom?.created_at || 0).getTime();
          const currentTime = new Date(room?.last_message_at || room?.created_at || 0).getTime();
          if (!previousRoom || currentTime >= previousTime) {
            dedupedRooms.set(roomKey, room);
          }
        }
      });
      if (!dedupedRooms.has(`room:${NOTICE_ROOM_ID}`)) {
        const noticeRoom = chatRooms.find((room: any) => room.id === NOTICE_ROOM_ID);
        if (noticeRoom) {
          dedupedRooms.set(`room:${NOTICE_ROOM_ID}`, noticeRoom);
        }
      }
      return Array.from(dedupedRooms.values());
    },
    [chatRooms, effectiveChatUserId]
  );

  const sidebarRooms = useMemo(() => {
    const keyword = omniSearch.trim().toLowerCase();
    const filtered = visibleRooms.filter((room: any) => {
      const label = getRoomDisplayName(room, allKnownStaffs, effectiveChatUserId).toLowerCase();
      const isHidden = roomPrefs[room.id]?.hidden === true;
      if (isHidden && !showHiddenRooms) return false;
      if (!keyword) return true;
      return label.includes(keyword);
    });
    return sortRoomsForSidebar(filtered, roomPrefs);
  }, [visibleRooms, omniSearch, roomPrefs, showHiddenRooms, allKnownStaffs, effectiveChatUserId]);

  const typingNoticeText = useMemo(() => {
    const names = Object.values(typingUsers).filter(Boolean);
    if (!names.length) return '';
    if (names.length === 1) return `${names[0]}님이 입력 중`;
    return `${names[0]} 외 ${names.length - 1}명이 입력 중`;
  }, [typingUsers]);

  const selectedPeer = useMemo(() => {
    if (!selectedRoom || selectedRoom.type !== 'direct') return null;
    return roomMembers.find((member: any) => String(member.id) !== effectiveChatUserId) || null;
  }, [selectedRoom, roomMembers, effectiveChatUserId]);

  const selectedPeerPresence = selectedPeer ? presenceMap[String(selectedPeer.id)] : null;

  const threadMessages = useMemo(() => {
    if (!threadRoot) return [];
    const rootId = threadRoot.id;
    return messages
      .filter(
        (m: any) =>
          m.id === rootId ||
          m.reply_to_id === rootId
      )
      .sort(
        (a: any, b: any) =>
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      );
  }, [threadRoot, messages]);

  const [readUsers, setReadUsers] = useState<any[]>([]);
  const loadReadStatusForMessage = useCallback(
    async (msg: any) => {
      if (!msg?.id || !selectedRoom) return;
      setUnreadLoading(true);
      setUnreadUsers([]);
      setReadUsers([]);
      setUnreadModalMsg(msg);
      try {
        const { data: reads } = await supabase
          .from('message_reads')
          .select('user_id')
          .eq('message_id', msg.id);
        const readUserIds = new Set((reads || []).map((r: any) => String(r.user_id)));

        const roomMemberIds = selectedRoom.id === NOTICE_ROOM_ID
          ? allKnownStaffs.map((s: any) => String(s.id))
          : Array.isArray(selectedRoom.members)
            ? selectedRoom.members.map((id: string) => String(id))
            : [];

        const allRoomStaffs = allKnownStaffs.filter((s: any) => roomMemberIds.includes(String(s.id)));

        const readers: any[] = [];
        const nonReaders: any[] = [];

        allRoomStaffs.forEach((s: any) => {
          if (String(s.id) === String(msg.sender_id)) return;
          if (readUserIds.has(String(s.id))) {
            readers.push(s);
          } else {
            nonReaders.push(s);
          }
        });

        const sorter = (a: any, b: any) => (a.department || '').localeCompare(b.department || '') || (a.name || '').localeCompare(b.name || '');
        setReadUsers(readers.sort(sorter));
        setUnreadUsers(nonReaders.sort(sorter));
      } catch (e) {
        console.error('loadReadStatusForMessage error', e);
        alert('읽음 현황을 불러오지 못했습니다.');
      } finally {
        setUnreadLoading(false);
      }
    },
    [selectedRoom, allKnownStaffs]
  );

  const handleLeaveRoom = async () => {
    if (!selectedRoom) return;
    if (selectedRoom.id === NOTICE_ROOM_ID && !isMso) {
      alert('공지 메시지 방은 관리자 확인 없이 직원 임의로 나갈 수 없습니다.');
      return;
    }
    if (!confirm('이 채팅방에서 나가시겠습니까? 나간 뒤에는 다시 초대를 받아야 입장할 수 있습니다.')) return;

    try {
      const currentMembers: any[] = Array.isArray(selectedRoom.members)
        ? selectedRoom.members
        : [];
      const newMembers = currentMembers.filter(
        (id: any) => String(id) !== String(user?.id)
      );

      await supabase
        .from('chat_rooms')
        .update({ members: newMembers })
        .eq('id', selectedRoom.id);

      const leftRoomId = selectedRoom.id;
      // 방 목록에서 즉시 제거 (실시간 재로드로 덮어쓰이기 전에)
      setChatRooms((prev) => prev.filter((room: any) => room.id !== leftRoomId));
      setRoomUnreadCounts((prev) => {
        const next = { ...prev };
        delete next[leftRoomId];
        return next;
      });
      setRoom(null);
      setMessages([]);
      alert('채팅방에서 나갔습니다.');
    } catch {
      alert('채팅방 나가기 중 오류가 발생했습니다.');
    }
  };


  const MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024;
  const handleSendMessage = useCallback(async (
    fileUrl?: string,
    fileSizeBytes?: number,
    fileKind?: 'image' | 'video' | 'file',
    retryMessageId?: string
  ) => {
    const retryPayload = retryMessageId
      ? deliveryStatesRef.current[retryMessageId]?.retryPayload || null
      : null;
    const trimmed = inputMsg.trim();
    const roomId = retryPayload?.roomId || selectedRoomId;
    const content = retryPayload ? retryPayload.content : trimmed;
    const resolvedFileUrl = retryPayload?.fileUrl ?? fileUrl ?? null;
    const resolvedFileSizeBytes = retryPayload?.fileSizeBytes ?? fileSizeBytes ?? null;
    const resolvedFileKind = retryPayload?.fileKind ?? fileKind ?? null;
    const resolvedReplyToId = retryPayload?.replyToId ?? replyTo?.id ?? null;
    if (!content && !resolvedFileUrl) return;
    if (!roomId) return;

    if (!resolvedFileUrl && content.startsWith('/')) {
      if (content.startsWith('/연차') || content.startsWith('/?곗감')) {
        setSlashCommand('annual_leave');
        setSlashForm({
          startDate: '',
          endDate: '',
          reason: content.startsWith('/연차')
            ? content.replace('/연차', '').trim()
            : content.replace('/?곗감', '').trim(),
          itemName: '',
          quantity: 1,
        });
        setShowSlashModal(true);
        return;
      }
      if (content.startsWith('/발주') || content.startsWith('/諛쒖＜')) {
        setSlashCommand('purchase');
        setSlashForm({
          startDate: '',
          endDate: '',
          reason: '',
          itemName: content.startsWith('/발주')
            ? content.replace('/발주', '').trim()
            : content.replace('/諛쒖＜', '').trim(),
          quantity: 1,
        });
        setShowSlashModal(true);
        return;
      }
    }
    if (roomId === NOTICE_ROOM_ID) {
      if (!canWriteNotice) {
        alert('공지 메시지 방에는 부서장 이상만 작성할 수 있습니다.');
        return;
      }
    }

    const retrySnapshot: MessageRetryPayload = {
      roomId,
      content,
      fileUrl: resolvedFileUrl,
      fileSizeBytes: resolvedFileSizeBytes,
      fileKind: resolvedFileKind,
      replyToId: resolvedReplyToId,
    };

    const optimisticId = retryMessageId || `temp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const optimisticMessage = {
      id: optimisticId,
      room_id: roomId,
      sender_id: user.id,
      content,
      file_url: resolvedFileUrl,
      file_size_bytes: resolvedFileSizeBytes,
      file_kind: resolvedFileKind,
      reply_to_id: resolvedReplyToId,
      created_at: new Date().toISOString(),
      is_deleted: false,
      staff: { name: user.name, photo_url: getProfilePhotoUrl(user) },
    };

    if (retryMessageId) {
      setMessages((prev) =>
        prev.map((message: any) =>
          message.id === retryMessageId
            ? { ...message, created_at: optimisticMessage.created_at }
            : message
        )
      );
    } else {
      setMessages((prev) => [...prev, optimisticMessage]);
    }

    setDeliveryStates((prev) => ({
      ...prev,
      [optimisticId]: {
        status: 'sending',
        retryPayload: retrySnapshot,
        error: null,
      },
    }));
    setInputMsg('');
    setReplyTo(null);
    requestAnimationFrame(() => scrollToBottom('smooth'));

    if (typingClearRef.current) {
      clearTimeout(typingClearRef.current);
      typingClearRef.current = null;
    }
    emitTypingState(false);

    const payload: Record<string, unknown> = {
      room_id: roomId,
      sender_id: user.id,
      content,
      file_url: resolvedFileUrl,
      file_size_bytes: resolvedFileSizeBytes,
      file_kind: resolvedFileKind,
      reply_to_id: resolvedReplyToId,
    };
    const { data: inserted, error } = await supabase.from('messages').insert([payload]).select().single();
    if (!error && inserted) {
      const optimisticMsg = {
        ...inserted,
        staff: { name: user.name, photo_url: getProfilePhotoUrl(user) },
      };
      setMessages((prev) =>
        prev.map((message: any) =>
          message.id === optimisticId ? optimisticMsg : message
        )
      );
      setDeliveryStates((prev) => {
        const next = { ...prev };
        delete next[optimisticId];
        next[String(inserted.id)] = {
          status: 'sent',
          retryPayload: retrySnapshot,
          error: null,
        };
        return next;
      });
      setChatRooms((prev) =>
        sortChatRoomsWithNoticeFirst(
          prev.map((room: any) =>
            room.id === roomId
              ? {
                  ...room,
                  last_message: content || (resolvedFileUrl ? '첨부파일' : room.last_message),
                  last_message_preview: content || (resolvedFileUrl ? '첨부파일' : room.last_message_preview),
                  last_message_at: inserted.created_at || new Date().toISOString(),
                }
              : room
          )
        )
      );
      broadcastChatSync('message-sent', roomId);
      await triggerChatPush(String(inserted.room_id), String(inserted.id));
    } else {
      setDeliveryStates((prev) => ({
        ...prev,
        [optimisticId]: {
          status: 'failed',
          retryPayload: retrySnapshot,
          error: error?.message || '메시지 전송 실패',
        },
      }));
      console.error('message send failed', error);
    }
  }, [selectedRoomId, user?.id, user?.name, user?.avatar_url, replyTo, inputMsg, canWriteNotice, scrollToBottom, broadcastChatSync, emitTypingState, triggerChatPush]);

  const retryFailedMessage = useCallback(async (messageId: string) => {
    await handleSendMessage(undefined, undefined, undefined, messageId);
  }, [handleSendMessage]);

  const [fileUploading, setFileUploading] = useState(false);
  const getFileKind = (mime: string): 'image' | 'video' | 'file' => {
    if (!mime) return 'file';
    if (mime.startsWith('image/')) return 'image';
    if (mime.startsWith('video/')) return 'video';
    return 'file';
  };
  const CHAT_BUCKET = 'pchos-files';
  const [isDragging, setIsDragging] = useState(false);

  const processFileUpload = async (file: File) => {
    if (file.type.startsWith('video/')) {
      alert('동영상 파일은 업로드할 수 없습니다.\n(사진, 문서, 일반 파일만 가능합니다.)');
      return;
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      alert('파일 크기는 20MB 이하여야 합니다.');
      return;
    }
    setFileUploading(true);
    try {
      const ext = file.name.split('.').pop() || 'bin';
      const uuid = crypto.randomUUID();
      const path = `chat/${Date.now()}_${uuid}.${ext}`;
      const { error } = await supabase.storage.from(CHAT_BUCKET).upload(path, file, { upsert: false });
      if (error) throw error;
      const publicUrl = supabase.storage.from(CHAT_BUCKET).getPublicUrl(path).data.publicUrl;
      const fileKind = getFileKind(file.type || '');
      await handleSendMessage(publicUrl, file.size, fileKind);
    } catch (err: any) {
      console.error('파일 업로드 실패:', err);
      const msg = err?.message || String(err);
      const hint = msg.includes('Bucket not found') || msg.includes('not found')
        ? 'Supabase 대시보드에서 Storage > New bucket > 이름 "pchos-files" (Public)을 만든 뒤 다시 시도해 주세요.'
        : msg.includes('policy') || msg.includes('RLS')
          ? 'Storage 버킷 pchos-files의 RLS 정책에서 INSERT를 허용해 주세요.'
          : '버킷 생성 여부와 RLS 정책을 확인해 주세요.';
      alert(`파일 업로드에 실패했습니다.\n\n${hint}`);
    } finally {
      setFileUploading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFileUpload(file);
    e.target.value = '';
  };

  const handleAction = async (type: 'task') => {
    if (!activeActionMsg) return;
    if (type === 'task') {
      if (!effectiveTodoUserId) {
        alert('연결된 직원 계정을 찾지 못했습니다.');
        setActiveActionMsg(null);
        return;
      }
      const content = (activeActionMsg.content || '').trim() || '첨부 파일 확인';
      const { error } = await supabase.from('todos').insert([{
        user_id: effectiveTodoUserId,
        content: `[채팅] ${content}`,
        is_complete: false,
        task_date: getKoreanTodayString(),
      }]);
      if (!error) {
        alert('할 일 등록 완료');
        if (onRefresh) onRefresh();
      } else {
        alert('할 일 등록 중 오류가 발생했습니다.');
      }
    }
    setActiveActionMsg(null);
  };

  const createGroupChat = async () => {
    if (!groupName.trim() || selectedMembers.length === 0) return alert('방 이름과 멤버를 선택해 주세요.');
    const { data: room, error } = await supabase.from('chat_rooms').insert([{
      name: groupName,
      type: 'group',
      created_by: user.id,
      members: [user.id, ...selectedMembers]
    }]).select().single();

    if (!error && room) {
      setGroupName('');
      setSelectedMembers([]);
      setShowGroupModal(false);
      setRoom(room.id);
      fetchData();
      setTimeout(() => fetchData(), 300);
    }
  };

  const groupedStaffs = useMemo(() => {
    const grouped: Record<string, Record<string, any[]>> = {};
    staffs.forEach((s: any) => {
      const company = s.company || '기타';
      const dept = s.department || '미지정';
      if (!grouped[company]) grouped[company] = {};
      if (!grouped[company][dept]) grouped[company][dept] = [];
      grouped[company][dept].push(s);
    });
    return grouped;
  }, [staffs]);

  const openDirectChat = useCallback(async (staff: any) => {
    const otherId = String(staff?.id || '').trim();
    if (!effectiveChatUserId || !otherId) {
      alert('채팅 상대를 찾지 못했습니다.');
      return;
    }

    try {
      const { data: rooms, error } = await supabase
        .from('chat_rooms')
        .select('*')
        .eq('type', 'direct');
      if (error) throw error;

      const repairedRooms = await repairDirectRooms(rooms || []);
      const targetMembers = new Set([effectiveChatUserId, otherId]);
      const foundRoom = repairedRooms
        .filter((room: any) => {
          const members = Array.isArray(room?.members)
            ? room.members.map((memberId: any) => String(memberId))
            : [];
          return members.length === targetMembers.size && [...targetMembers].every((memberId) => members.includes(memberId));
        })
        .sort((a: any, b: any) =>
          new Date(b.last_message_at || b.created_at || 0).getTime() -
          new Date(a.last_message_at || a.created_at || 0).getTime()
        )[0];

      if (foundRoom) {
        setChatRooms((prev) =>
          sortChatRoomsWithNoticeFirst([
            ...prev.filter((room: any) => String(room.id) !== String(foundRoom.id)),
            foundRoom,
          ])
        );
        setRoom(foundRoom.id);
      } else {
        const { data: room, error: insertError } = await supabase
          .from('chat_rooms')
          .insert([{ name: `${staff.name}`, type: 'direct', members: [effectiveChatUserId, otherId] }])
          .select('*')
          .single();
        if (insertError) throw insertError;
        if (room) {
          setChatRooms((prev) =>
            sortChatRoomsWithNoticeFirst([
              ...prev.filter((candidate: any) => String(candidate.id) !== String(room.id)),
              room,
            ])
          );
          setRoom(room.id);
          await fetchData();
        }
      }

      setViewMode('chat');
    } catch (error) {
      console.error('openDirectChat failed', error);
      alert('채팅방을 여는 중 오류가 발생했습니다.');
    }
  }, [effectiveChatUserId, fetchData, repairDirectRooms]);

  const mediaMessages = useMemo(() => {
    return messages.filter((m: any) => m.file_url);
  }, [messages]);

  const filteredMediaMessages = useMemo(() => {
    if (mediaFilter === 'all') return mediaMessages;
    return mediaMessages.filter((m: any) => {
      if (mediaFilter === 'image') return isImageUrl(m.file_url);
      if (mediaFilter === 'video') return isVideoUrl(m.file_url);
      return !isImageUrl(m.file_url) && !isVideoUrl(m.file_url);
    });
  }, [mediaMessages, mediaFilter]);

  const mentionCandidates = useMemo(() => {
    if (!showMentionList) return [];
    const base =
      Array.isArray(roomMembers) && roomMembers.length > 0
        ? roomMembers
        : staffs;
    const q = mentionQuery.trim();
    if (!q) return base.slice(0, 8);
    return base
      .filter((s: any) =>
        (s.name || '').toLowerCase().includes(q.toLowerCase())
      )
      .slice(0, 8);
  }, [showMentionList, mentionQuery, roomMembers, staffs]);

  const handleCreatePoll = async () => {
    if (!pollQuestion.trim()) { alert('질문을 입력해 주세요.'); return; }
    const options = pollOptions.map((o) => o.trim()).filter(Boolean);
    if (options.length < 2) { alert('선택지는 최소 2개 이상 입력해 주세요.'); return; }
    try {
      const { data: poll, error } = await supabase.from('polls').insert([{
        room_id: selectedRoomId, creator_id: user.id, question: pollQuestion, options
      }]).select().single();
      if (!error && poll) {
        setPolls((p: any[]) => [...p, poll]);
        setPollQuestion('');
        setPollOptions(['찬성', '반대']);
        setShowPollModal(false);
      } else throw new Error();
    } catch {
      const id = Date.now().toString();
      setPolls((p: any[]) => [...p, { id, room_id: selectedRoomId, question: pollQuestion, options }]);
      setPollQuestion('');
      setPollOptions(['찬성', '반대']);
      setShowPollModal(false);
    }
  };

  const handleVote = async (pollId: string, optionIndex: number) => {
    try {
      const { error } = await supabase.from('poll_votes').upsert(
        { poll_id: pollId, user_id: user.id, option_index: optionIndex },
        { onConflict: 'poll_id,user_id' }
      );
      if (!error) fetchData();
    } catch (_) { }
    setPollVotes((prev: any) => {
      const ex = prev[pollId] || {};
      return { ...prev, [pollId]: { ...ex, [optionIndex]: (ex[optionIndex] || 0) + 1 } };
    });
  };

  const toggleReaction = async (messageId: string, emoji: string) => {
    try {
      const { data: myReact } = await supabase.from('message_reactions').select('id').eq('message_id', messageId).eq('user_id', user.id).eq('emoji', emoji).maybeSingle();
      if (myReact) {
        await supabase.from('message_reactions').delete().eq('message_id', messageId).eq('user_id', user.id).eq('emoji', emoji);
      } else {
        await supabase.from('message_reactions').insert([{ message_id: messageId, user_id: user.id, emoji }]);
      }
      await fetchData();
    } catch (error) {
      console.error('toggleReaction error', error);
    }
  };

  const togglePin = async (messageId: string) => {
    const normalizedMessageId = String(messageId);
    const isPinned = pinnedIds.includes(normalizedMessageId);
    try {
      if (isPinned) {
        const { error } = await supabase
          .from('pinned_messages')
          .delete()
          .eq('room_id', selectedRoomId)
          .eq('message_id', normalizedMessageId);
        if (error) throw error;
        setPinnedIds([]);
        writeStoredPinnedIds(selectedRoomId, []);
      } else {
        const { error: clearError } = await supabase.from('pinned_messages').delete().eq('room_id', selectedRoomId);
        if (clearError) throw clearError;
        const { error: insertError } = await supabase
          .from('pinned_messages')
          .insert([{ room_id: selectedRoomId, message_id: normalizedMessageId, pinned_by: user.id }]);
        if (insertError) throw insertError;
        setPinnedIds([normalizedMessageId]);
        writeStoredPinnedIds(selectedRoomId, [normalizedMessageId]);
      }
      await fetchData();
    } catch (error) {
      console.error('공지 등록 상태 변경 실패:', error);
      alert(isPinned ? '공지 해제에 실패했습니다.' : '공지 등록에 실패했습니다.');
    }
  };

  const toggleBookmark = async (messageId: string) => {
    const normalizedMessageId = String(messageId);
    const isBookmarked = bookmarkedIds.has(normalizedMessageId);
    const nextBookmarkIds = isBookmarked
      ? Array.from(bookmarkedIds).filter((id) => id !== normalizedMessageId)
      : [...Array.from(bookmarkedIds), normalizedMessageId];
    try {
      if (!effectiveTodoUserId) {
        throw new Error('missing-user');
      }
      if (isBookmarked) {
        const { error } = await supabase
          .from('message_bookmarks')
          .delete()
          .eq('user_id', effectiveTodoUserId)
          .eq('message_id', normalizedMessageId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('message_bookmarks').insert([
          {
            user_id: effectiveTodoUserId,
            message_id: normalizedMessageId,
            room_id: selectedRoomId,
          },
        ]);
        if (error) throw error;
      }
      setBookmarkedIds(new Set(nextBookmarkIds));
      writeStoredBookmarks(effectiveTodoUserId, nextBookmarkIds);
      await fetchData();
    } catch (error) {
      console.error('toggleBookmark error', error);
      setBookmarkedIds(new Set(nextBookmarkIds));
      writeStoredBookmarks(effectiveTodoUserId, nextBookmarkIds);
    }
  };

  const markMessageRead = async (msg: any) => {
    if (String(msg.sender_id) === effectiveChatUserId) return;
    try {
        await persistMessageReads([msg.id]);
        broadcastChatSync('message-read', msg.room_id);
        fetchData();
    } catch (_) { }
  };

  const handleGlobalSearch = async () => {
    if (!globalSearchQuery.trim()) return;
    setGlobalSearchLoading(true);
    try {
      const roomIds = visibleRooms.map(r => r.id);
      if (roomIds.length === 0) {
        setGlobalSearchResults([]);
        return;
      }
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .in('room_id', roomIds)
        .ilike('content', `%${globalSearchQuery}%`)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      const messageRows = Array.isArray(data) ? data : [];
      const relatedRoomIds = Array.from(new Set(messageRows.map((message: any) => String(message.room_id)).filter(Boolean)));
      const { data: roomRows, error: roomError } = await supabase
        .from('chat_rooms')
        .select('id, name, type, members')
        .in('id', relatedRoomIds);
      if (roomError) throw roomError;

      const roomMap = new Map<string, any>();
      (roomRows || []).forEach((room: any) => {
        roomMap.set(String(room.id), room);
      });

      const enrichedRows = messageRows.map((message: any) => ({
        ...message,
        staff: resolveStaffProfile(message.sender_id, message.sender_name),
        chat_rooms: roomMap.get(String(message.room_id)) || null,
      }));

      setGlobalSearchResults(enrichedRows);
    } catch (err) {
      console.error(err);
    } finally {
      setGlobalSearchLoading(false);
    }
  };

  const combinedTimeline = useMemo(() => {
    const msgs = messages.filter((m: any) => !m.is_deleted);
    let filtered = msgs;
    if (chatSearch.trim()) {
      const q = chatSearch.toLowerCase();
      filtered = msgs.filter((m) =>
        (m.content || '').toLowerCase().includes(q) ||
        (m.staff?.name || '').toLowerCase().includes(q)
      );
    }
    const ms = filtered.map(m => ({ ...m, type: 'message' }));
    const ps = polls
      .filter((p: any) => p.room_id === selectedRoomId)
      .map(p => ({ ...p, type: 'poll', created_at: p.created_at || new Date().toISOString() }));

    return [...ms, ...ps].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }, [messages, chatSearch, polls, selectedRoomId]);

  useEffect(() => {
    const load = async () => {
      if (!user?.id || !selectedRoomId) {
        setRoomNotifyOn(true);
        return;
      }
      const { data, error } = await supabase
        .from('room_notification_settings')
        .select('notifications_enabled')
        .eq('user_id', user?.id)
        .eq('room_id', selectedRoomId)
        .maybeSingle();
      if (error) {
        setRoomNotifyOn(true);
        return;
      }
      setRoomNotifyOn(data?.notifications_enabled !== false);
    };
    load();
  }, [selectedRoomId, user?.id]);
  const toggleRoomNotify = async () => {
    if (!user?.id || !selectedRoomId) return;
    setRoomNotifyOn((p) => !p);
    await supabase.from('room_notification_settings').upsert({ user_id: user.id, room_id: selectedRoomId, notifications_enabled: !roomNotifyOn }, { onConflict: 'user_id,room_id' });
  };

  const deleteMessage = async (msg: any) => {
    if (selectedRoom?.id === NOTICE_ROOM_ID && !isMso) {
      alert('공지 채널 메시지는 삭제할 수 없습니다.');
      return;
    }
    if (msg.sender_id !== user.id && !isMso) return;
    if (!confirm('이 메시지를 삭제하시겠습니까?')) return;
    await supabase.from('messages').update({ is_deleted: true }).eq('id', msg.id);
    // 媛먯궗 濡쒓렇 湲곕줉
    try {
      await supabase.from('audit_logs').insert([
        {
          user_id: user.id,
          user_name: user.name,
          action: 'message_delete',
          target_type: 'message',
          target_id: msg.id,
          details: {
            room_id: selectedRoomId,
            content: msg.content,
          },
        },
      ]);
    } catch {
    }
    fetchData();
    setActiveActionMsg(null);
  };
  const [editingMsg, setEditingMsg] = useState<any>(null);
  const [editContent, setEditContent] = useState('');
  const saveEditMessage = async () => {
    if (!editingMsg || editingMsg.sender_id !== user.id) return;
    const before = editingMsg.content;
    await supabase
      .from('messages')
      .update({ content: editContent, edited_at: new Date().toISOString() })
      .eq('id', editingMsg.id);
    // 媛먯궗 濡쒓렇 湲곕줉
    try {
      await supabase.from('audit_logs').insert([
        {
          user_id: user.id,
          user_name: user.name,
          action: 'message_edit',
          target_type: 'message',
          target_id: editingMsg.id,
          details: {
            room_id: selectedRoomId,
            before,
            after: editContent,
          },
        },
      ]);
    } catch {
      // ignore
    }
    fetchData();
    setEditingMsg(null);
    setEditContent('');
  };

  const openMessageActions = useCallback((msg: any) => {
    markMessageRead(msg);
    setActiveActionMsg(msg);
  }, [markMessageRead]);

  const startReplyToMessage = useCallback((msg: any) => {
    setReplyTo(msg);
    setActiveActionMsg(null);
    requestAnimationFrame(() => {
      composerRef.current?.focus();
      composerRef.current?.scrollIntoView({ block: 'nearest' });
    });
  }, []);

  const startEditMessage = useCallback((msg: any) => {
    setEditingMsg(msg);
    setEditContent(msg.content || '');
    setActiveActionMsg(null);
  }, []);

  const startForwardMessage = useCallback((msg: any) => {
    setForwardSourceMsg(msg);
    setShowForwardModal(true);
    setActiveActionMsg(null);
  }, []);

  const openReadStatusPanel = useCallback((msg: any) => {
    void loadReadStatusForMessage(msg);
    setActiveActionMsg(null);
  }, [loadReadStatusForMessage]);

  const openThreadPanel = useCallback((msg: any) => {
    setThreadRoot(msg);
    setActiveActionMsg(null);
  }, []);

  const deleteMessageFromActions = useCallback(async (msg: any) => {
    await deleteMessage(msg);
  }, [deleteMessage]);

  return (
    <div data-testid="chat-view" className="flex flex-1 min-h-0 overflow-hidden relative font-sans h-full bg-[var(--background)] md:h-[100dvh] md:max-h-[100dvh] md:bg-[var(--toss-card)]">
      <aside className={`${selectedRoomId ? 'hidden md:flex' : 'flex'} w-full md:w-80 border-r border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 flex-col shrink-0 z-50 transition-all`}>
        <div className="p-4 md:p-6 space-y-4 flex flex-col min-h-0">
          <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl glass">
            <button
              onClick={() => setViewMode('chat')}
              className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all ${viewMode === 'chat'
                ? 'bg-white dark:bg-zinc-700 text-foreground shadow-premium'
                : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
                }`}
            >
              채팅
            </button>
            <button
              onClick={() => setViewMode('org')}
              className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all ${viewMode === 'org'
                ? 'bg-white dark:bg-zinc-700 text-foreground shadow-premium'
                : 'text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300'
                }`}
            >
              조직도
            </button>
          </div>

          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest leading-none">
              {viewMode === 'chat' ? '최근 대화' : '조직도'}
            </span>
            {viewMode === 'chat' && (
              <button
                onClick={() => setShowGlobalSearch(true)}
                className="text-[12px] text-zinc-400 hover:text-blue-500 transition-colors p-1 flex items-center justify-center shrink-0"
                title="채팅 내용 전체 검색"
              >
                검색
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-6 space-y-2 custom-scrollbar">
          {viewMode === 'chat' ? (
            <>
              <div className="flex items-center justify-between px-1 pb-2">
                <span className="text-[10px] font-medium text-zinc-400">
                  {showHiddenRooms ? '숨김 대화 포함' : '숨김 대화 제외'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowHiddenRooms((prev) => !prev)}
                  className="text-[10px] font-semibold text-blue-500 hover:text-blue-600"
                >
                  {showHiddenRooms ? '숨김방 닫기' : '숨김방 보기'}
                </button>
              </div>
              {sidebarRooms.map(room => {
                  const unread = roomUnreadCounts[room.id] || 0;
                  const isSelected = selectedRoomId === room.id;
                  const isNoticeChannel = room.id === NOTICE_ROOM_ID;
                  const label = getRoomDisplayName(room, allKnownStaffs, effectiveChatUserId);
                  const preview = getRoomPreviewText(room);
                  const members = normalizeMemberIds(room.members);
                  const peer =
                    room.type === 'direct'
                      ? allKnownStaffs.find(
                          (staff: any) =>
                            members.includes(String(staff.id)) &&
                            String(staff.id) !== effectiveChatUserId
                        )
                      : null;
                  const isPeerOnline = peer ? Boolean(presenceMap[String(peer.id)]) : false;
                  const isPinned = roomPrefs[room.id]?.pinned === true;
                  const isHidden = roomPrefs[room.id]?.hidden === true;

                  return (
                    <div
                      key={room.id}
                      onClick={() => setRoom(room.id)}
                      className={`group p-3.5 rounded-xl cursor-pointer transition-all flex items-center justify-between gap-3 border relative overflow-hidden ${isSelected
                        ? 'bg-zinc-800 border-zinc-700 shadow-sm'
                        : 'bg-white dark:bg-zinc-900 border-transparent hover:border-zinc-200 dark:hover:border-zinc-800'
                        }`}
                    >
                      {isSelected && (
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"></div>
                      )}
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div className={`relative w-8 h-8 rounded-lg flex items-center justify-center text-sm ${isNoticeChannel ? 'bg-blue-100 text-blue-600' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500'}`}>
                          {isNoticeChannel ? '📢' : '💬'}
                          {!isNoticeChannel && isPeerOnline && (
                            <span className="absolute -right-0.5 -bottom-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white dark:border-zinc-900" />
                          )}
                        </div>                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-1.5 min-w-0">
                            {unread > 0 && (
                              <span className="shrink-0 min-w-[18px] h-[18px] px-1.5 inline-flex items-center justify-center rounded-full bg-blue-600 text-white text-[9px] font-bold shadow-soft">
                                {unread > 99 ? '99+' : unread}
                              </span>
                            )}
                            <p className={`text-[12px] font-bold truncate ${isSelected ? 'text-white' : 'text-zinc-600 dark:text-zinc-300'}`}>
                              {label}
                            </p>
                            {isPinned && <span className="text-[9px] font-bold text-amber-400">PIN</span>}
                            {isHidden && <span className="text-[9px] font-bold text-zinc-400">HIDE</span>}
                          </div>
                          <p className="text-[10px] text-zinc-400 font-medium truncate">
                            {preview}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {!isNoticeChannel && (
                          <>
                            <button
                              type="button"
                              onClick={(event) => {
                                event.stopPropagation();
                                updateRoomPreference(room.id, { pinned: !isPinned });
                              }}
                              className={`px-1.5 py-1 rounded-md text-[9px] font-bold ${isSelected ? 'text-white/80 hover:bg-white/10' : 'text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                              title={isPinned ? '고정 해제' : '상단 고정'}
                            >
                              {isPinned ? '해제' : '고정'}
                            </button>
                            <button
                              type="button"
                              onClick={(event) => {
                                event.stopPropagation();
                                updateRoomPreference(room.id, { hidden: !isHidden });
                              }}
                              className={`px-1.5 py-1 rounded-md text-[9px] font-bold ${isSelected ? 'text-white/80 hover:bg-white/10' : 'text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                              title={isHidden ? '숨김 해제' : '대화 숨김'}
                            >
                              {isHidden ? '표시' : '숨김'}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
            </>
          ) : (
            <div className="space-y-6">
              {Object.entries(groupedStaffs).map(([company, depts]) => (
                <div key={company} className="space-y-4">
                  <div className="flex items-center gap-2 px-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    <h3 className="text-[11px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">{company}</h3>
                    <div className="flex-1 h-[1px] bg-zinc-100 dark:bg-zinc-800/50"></div>
                  </div>
                  <div className="space-y-5 pl-1">
                    {Object.entries(depts).map(([dept, members]) => (
                      <div key={dept} className="space-y-2">
                        <p className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 ml-1">{dept}</p>
                        <div className="space-y-1">
                          {members.map((s: any) => (
                            <div key={s.id} className="flex items-center gap-3 p-2.5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800/50 rounded-xl hover:border-blue-400/50 dark:hover:border-blue-500/50 cursor-pointer transition-all group">
                              <div className="w-8 h-8 bg-zinc-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center text-xs font-bold text-zinc-400 overflow-hidden shrink-0">
                                {s.photo_url ? <img src={s.photo_url} alt={s.name} className="w-full h-full object-cover" /> : s.name[0]}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <p className="text-xs font-bold text-foreground truncate">{s.name}</p>
                                  <span className="text-[10px] font-medium text-zinc-400">{s.position}</span>
                                </div>
                              </div>
                              <button
                                onClick={() => {
                                  void openDirectChat(s);
                                }}
                                className="px-3 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-all border border-blue-100 dark:border-blue-800/50"
                              >
                                대화
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      <main className={`${!selectedRoomId ? 'hidden md:flex' : 'flex'} flex-1 min-h-0 flex-col overflow-hidden bg-[var(--toss-gray-1)] relative`}>
        {selectedRoomId && selectedRoom && (
          <header className="px-6 py-3.5 flex items-center justify-between border-b border-zinc-200/50 dark:border-zinc-800/50 glass glass-border shrink-0 z-40">
            <div className="flex items-center gap-3 min-w-0">
              <button onClick={() => setRoom(null)} className="md:hidden text-zinc-400">뒤로</button>
              <div className="w-9 h-9 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-lg">
                {selectedRoom.id === NOTICE_ROOM_ID ? '📢' : '💬'}
              </div>
              <div className="min-w-0">
                <h3 className="text-[13px] font-bold text-foreground truncate">
                  {selectedRoomLabel}
                </h3>
                <p className="text-[10px] text-zinc-500 font-medium">
                  {typingNoticeText
                    ? typingNoticeText
                    : selectedPeer
                      ? selectedPeerPresence
                        ? '온라인'
                        : '오프라인'
                      : `${roomMembers.length || 0}명 참여중`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowDrawer(true)}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-foreground"
                title="채팅방 정보 및 참여자 보기"
              >
                <svg
                  aria-hidden="true"
                  viewBox="0 0 20 20"
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                >
                  <path d="M4 5.5H16" />
                  <path d="M4 10H16" />
                  <path d="M4 14.5H16" />
                </svg>
              </button>
            </div>
          </header>
        )}

        {selectedRoomId && noticeMessages.length > 0 && (
          <div className="shrink-0 border-b border-orange-100 bg-orange-50/80 px-4 py-3 md:px-6">
            <div className="flex flex-wrap gap-2">
              {noticeMessages.map((pinnedMessage) => (
                <button
                  key={`pin-${pinnedMessage.id}`}
                  type="button"
                  onClick={() => scrollToMessage(pinnedMessage.id)}
                  className="min-w-0 max-w-full rounded-[14px] border border-orange-200 bg-white px-3 py-2 text-left shadow-sm transition-colors hover:bg-orange-100"
                >
                  <p className="text-[10px] font-bold text-orange-500">공지 메시지</p>
                  <p className="mt-1 max-w-[280px] truncate text-xs font-semibold text-[var(--foreground)]">
                    {pinnedMessage.content || '첨부 파일 메시지'}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        <div
          ref={messageListRef}
          onScroll={updateScrollPositionState}
          className="flex-1 min-h-0 overflow-y-auto p-4 md:p-6 pb-24 md:pb-6 space-y-3 custom-scrollbar"
        >
          {!selectedRoomId ? (
            <div className="h-full flex flex-col items-center justify-center text-[var(--toss-gray-3)]">
              <span className="text-4xl mb-2">💬</span>
              <p className="text-sm font-bold">채팅방을 선택하세요.</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center opacity-20">
              <span className="text-6xl mb-4">💬</span>
              <p className="font-semibold text-sm">대화 내용이 없습니다.</p>
            </div>
          ) : (
            (() => {
              let lastDateLabel = '';
              const totalRecipients = Math.max(
                0,
                roomMembers.filter((member: any) => String(member.id) !== effectiveChatUserId).length
              );
              return combinedTimeline.map((item) => {
                if (item.type === 'poll') {
                  const votes = pollVotes[item.id] || {};
                  const totalVotes = (Object.values(votes) as number[]).reduce((a: number, b: number) => a + b, 0);
                  return (
                    <div key={`poll-${item.id}`} className="max-w-[85%] md:max-w-[70%] bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/50 rounded-2xl p-4 shadow-soft">
                      <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        <span className="text-sm">🗳️</span> 투표
                      </p>
                      <p className="mb-4 text-xs font-bold text-foreground leading-relaxed">{item.question}</p>
                      <div className="space-y-1.5">
                        {item.options.map((opt: string, idx: number) => (
                          <button
                            key={idx}
                            onClick={() => handleVote(item.id, idx)}
                            className="w-full flex justify-between items-center px-4 py-2.5 rounded-xl bg-white dark:bg-zinc-800/50 border border-blue-200/50 dark:border-blue-700/30 hover:border-blue-400 dark:hover:border-blue-500 transition-all text-[11px] font-medium group"
                          >
                            <span className="text-zinc-700 dark:text-zinc-300 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{opt}</span>
                            <span className="text-blue-600 font-bold bg-blue-50 dark:bg-blue-900/50 px-2 py-0.5 rounded-md">
                              {votes[idx] || 0}
                              {totalVotes > 0 && <span className="ml-1 opacity-60 font-medium">({Math.round(((votes[idx] || 0) / totalVotes) * 100)}%)</span>}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                }

                const msg = item;
                const isMine = String(msg.sender_id) === effectiveChatUserId;
                const msgReacts = reactions[msg.id] || {};
                const hasReacts = Object.keys(msgReacts).some(e => (msgReacts[e] || 0) > 0);

                const readersCount = readCounts[msg.id] || 0;
                const unreadRecipients = isMine ? Math.max(0, totalRecipients - readersCount) : 0;
                const deliveryState = deliveryStates[msg.id]?.status || (String(msg.id).startsWith('temp-') ? 'sending' : 'sent');
                const readStatusSummary = !isMine
                  ? null
                  : deliveryState === 'sending'
                    ? '전송중'
                    : deliveryState === 'failed'
                      ? '전송 실패'
                      : totalRecipients > 0 && unreadRecipients > 0
                        ? `${unreadRecipients}`
                        : '전송됨';
                const canOpenReadStatus = Boolean(
                  isMine &&
                  deliveryState === 'sent' &&
                  totalRecipients > 0
                );

                const TOOLBAR_EMOJIS = ['👍', '❤️', '👏', '🎉', '🔥', '✅', '👀', '🙏'];

                const created = new Date(msg.created_at);
                const dateLabel = created.toLocaleDateString('ko-KR', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  weekday: 'short',
                });
                const showDateDivider = dateLabel !== lastDateLabel;
                if (showDateDivider) lastDateLabel = dateLabel;

                const isSystemInvite = typeof msg.content === 'string' && msg.content.startsWith('[초대]');
                const systemText = isSystemInvite ? (msg.content as string).replace(/^\[초대\]\s*/, '') : '';

                return (
                  <div key={msg.id} className="space-y-1">
                    {showDateDivider && (
                      <div className="flex justify-center my-2">
                        <span className="px-3 py-1 rounded-full bg-[var(--toss-gray-1)] text-[11px] font-bold text-[var(--toss-gray-3)]">
                          {dateLabel}
                        </span>
                      </div>
                    )}
                    {isSystemInvite ? (
                      <div className="flex justify-center my-2">
                        <span className="px-3 py-1.5 rounded-full bg-[var(--toss-blue-light)] text-[11px] font-bold text-[var(--toss-blue)]">
                          초대 {systemText}
                        </span>
                      </div>
                    ) : (
                      <div
                        ref={el => { msgRefs.current[msg.id] = el; }}
                        className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                      >
                        {!isMine && (
                          <span className="text-[11px] text-[var(--toss-gray-4)] px-2 mb-1 font-bold">
                            {msg.staff?.name} {msg.staff?.position}
                          </span>
                        )}
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            openMessageActions(msg);
                          }}
                          className={`group relative ${!msg.content ? 'p-0 bg-transparent shadow-none border-none' : 'px-3 py-2 shadow-sm border'} rounded-[12px] text-[13px] md:text-sm cursor-pointer transition-all max-w-[75%] md:max-w-[70%] ${!msg.content ? '' : isMine
                            ? 'bg-emerald-600 text-white border-transparent rounded-tr-none'
                            : 'bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 rounded-tl-none hover:border-emerald-400 text-foreground'
                            }`}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => e.key === 'Enter' && markMessageRead(msg)}
                          aria-label={`${msg.staff?.name || '이름 없음'} 메시지`}
                        >
                          {msg.reply_to_id && (() => {
                            const parent = messages.find((m: any) => m.id === msg.reply_to_id);
                            return parent ? (
                              <div
                                className={`mb-2 p-2 rounded-[10px] text-[11px] border-l-2 cursor-pointer hover:opacity-80 transition-opacity ${isMine ? 'bg-white/10 border-white/30 text-white' : 'bg-[var(--toss-gray-1)] border-[var(--toss-border)] text-[var(--foreground)]'
                                  }`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  scrollToMessage(msg.reply_to_id);
                                }}
                              >
                                <span className="font-bold opacity-80">답글 {parent.staff?.name}: </span>
                                <span className="truncate block mt-0.5">{parent.content || '첨부 파일'}</span>
                              </div>
                            ) : null;
                          })()}
                          <div className={`leading-relaxed ${msg.content ? 'mb-1' : ''}`}>
                            {renderMessageContent(msg.content)}
                          </div>
                          {msg.file_url && (
                            <div className="space-y-1 mt-2" onClick={(e) => e.stopPropagation()}>
                              {isImageUrl(msg.file_url) ? (
                                <div className="relative group inline-block">
                                  <a href={msg.file_url} target="_blank" rel="noopener noreferrer" className="block">
                                    <img
                                      src={msg.file_url}
                                      alt="첨부 이미지"
                                      className={`max-w-[200px] md:max-w-[240px] max-h-[200px] rounded-[12px] object-cover ${msg.content ? 'border border-[var(--toss-border)]' : 'shadow-sm'}`}
                                    />
                                  </a>
                                  <div className="absolute opacity-0 group-hover:opacity-100 transition-opacity inset-0 flex items-center justify-center bg-black/40 rounded-[12px] gap-2 pointer-events-none">
                                    <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); window.open(msg.file_url, '_blank') }} className="pointer-events-auto p-1.5 bg-white/20 hover:bg-white/40 rounded-full text-white" title="미리보기">보기</button>
                                    <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigator.clipboard.writeText(msg.file_url).then(() => alert('공유 링크를 복사했습니다.')) }} className="pointer-events-auto p-1.5 bg-white/20 hover:bg-white/40 rounded-full text-white" title="공유">공유</button>
                                    <a href={msg.file_url} download target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="pointer-events-auto p-1.5 bg-white/20 hover:bg-white/40 rounded-full text-white" title="다운로드">저장</a>
                                  </div>
                                </div>
                              ) : isVideoUrl(msg.file_url) ? (
                                <div className="block">
                                  <video controls className={`max-w-[200px] md:max-w-[240px] max-h-[200px] rounded-[12px] bg-black ${msg.content ? 'border border-[var(--toss-border)]' : 'shadow-sm'}`}>
                                    <source src={msg.file_url} />
                                  </video>
                                </div>
                              ) : (
                                <div className={`p-3 rounded-[12px] border ${isMine ? 'bg-white/10 border-white/20 text-white' : 'bg-[var(--toss-gray-0)] border-[var(--toss-border)] text-[var(--foreground)]'} flex items-start gap-3 shadow-sm min-w-[200px]`}>
                                  <div className="text-3xl">📎</div>
                                  <div className="flex-1 min-w-0 pt-0.5">
                                    <p className={`font-bold text-[12px] truncate mb-1`}>첨부 파일</p>
                                    <div className="flex items-center gap-1.5 mt-2">
                                      <button onClick={() => window.open(msg.file_url, '_blank')} className="text-[10px] font-bold text-[var(--toss-blue)] hover:text-blue-600 px-2 py-1 bg-blue-50 dark:bg-blue-900/30 rounded-md">미리보기</button>
                                      <button onClick={() => { navigator.clipboard.writeText(msg.file_url).then(() => alert('공유 링크를 복사했습니다.')) }} className="text-[10px] font-bold text-zinc-500 hover:text-zinc-600 px-2 py-1 bg-zinc-100 dark:bg-zinc-800 rounded-md">공유</button>
                                  <a href={msg.file_url} download target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 px-2 py-1 bg-emerald-50 dark:bg-emerald-900/30 rounded-md inline-block">다운로드</a>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {hasReacts && (
                            <div className="mt-2 flex items-center gap-2 text-[11px] flex-wrap">
                              <span className="flex gap-1 flex-wrap">
                                {Object.entries(msgReacts).map(([emoji, cnt]) =>
                                ((cnt as number) > 0 ? (
                                  <span
                                    key={emoji}
                                    className={`px-1.5 py-0.5 rounded text-[11px] ${isMine ? 'bg-white/20' : 'bg-[var(--toss-gray-1)]'
                                      }`}
                                  >
                                    {emoji} {cnt as number}
                                  </span>
                                ) : null)
                                )}
                              </span>
                            </div>
                          )}

                          <div
                            className={`absolute bottom-0 ${isMine ? 'right-full mr-2 items-end' : 'left-full ml-2 items-start'
                              } flex flex-col gap-0.5 whitespace-nowrap`}
                          >
                            {readStatusSummary && (
                              canOpenReadStatus ? (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    loadReadStatusForMessage(msg);
                                  }}
                                  className="text-[10px] font-bold text-emerald-500 hover:text-emerald-600 underline underline-offset-2"
                                >
                                  {readStatusSummary}
                                </button>
                              ) : (
                                <span className={`text-[10px] font-bold ${deliveryState === 'failed' ? 'text-red-500' : 'text-emerald-500'}`}>
                                  {readStatusSummary}
                                </span>
                              )
                            )}
                            <span className="text-[8px] font-bold text-[var(--toss-gray-4)]">
                              {created.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                        {isMine && deliveryState === 'failed' && (
                          <div className="mt-1 flex justify-end">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                retryFailedMessage(String(msg.id));
                              }}
                              className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-50 text-red-500 hover:bg-red-100"
                            >
                              재전송
                            </button>
                          </div>
                        )}
                        <div
                          className={`flex items-center gap-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity ${isMine ? 'flex-row-reverse' : ''}`}
                          onClick={e => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() => { startReplyToMessage(msg); }}
                            className="p-1 px-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-[10px] font-bold text-zinc-400 hover:text-blue-500 transition-colors"
                          >
                            답장
                          </button>
                          <button
                            type="button"
                            onClick={() => { openMessageActions(msg); }}
                            className="p-1 px-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-[10px] font-bold text-zinc-400 hover:text-zinc-600 transition-colors"
                          >
                            더보기
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              });
            })()
          )}

          <div ref={scrollRef} />
        </div>

        {showScrollToLatest && selectedRoomId && (
          <div className="absolute right-4 bottom-24 md:bottom-20 z-20">
            <button
              type="button"
              onClick={() => scrollToBottom('smooth')}
              className="px-3 py-2 rounded-full bg-[var(--toss-card)] border border-[var(--toss-border)] shadow-lg text-[11px] font-bold text-[var(--foreground)]"
            >
              최신 메시지
            </button>
          </div>
        )}

        <div
          className={`absolute left-0 right-0 bottom-0 md:relative p-2 md:p-3 bg-[var(--toss-card)] shrink-0 transition-all z-10 ${isDragging ? 'border-t-2 border-[var(--toss-blue)] border-dashed bg-blue-50 dark:bg-blue-900/20' : 'border-t border-[var(--toss-border)]'}`}
          onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); }}
          onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); }}
          onDrop={async (e) => {
            e.preventDefault(); e.stopPropagation(); setIsDragging(false);
            const file = e.dataTransfer.files?.[0];
            if (file) await processFileUpload(file);
          }}
        >
          {replyTo && (
            <div className="mb-3 flex items-center justify-between bg-[var(--toss-blue-light)] p-3 rounded-[16px] border border-[var(--toss-blue-light)] animate-in slide-in-from-bottom-2">
              <p className="text-[11px] font-bold text-[var(--toss-blue)]">@{replyTo.staff?.name}님에게 답글 작성 중...</p>
              <button onClick={() => setReplyTo(null)} className="text-[var(--toss-blue)] hover:text-[var(--toss-blue)] font-semibold">닫기</button>
            </div>
          )}

          {typingNoticeText && (
            <div className="mb-2 px-1 text-[11px] font-medium text-blue-500">
              {typingNoticeText}
            </div>
          )}

          <div className={`flex items-center md:items-end gap-3 p-3 rounded-[16px] border transition-all ${selectedRoomId === NOTICE_ROOM_ID && !canWriteNotice
            ? 'bg-[var(--toss-gray-1)] border-[var(--toss-border)] opacity-80 pointer-events-none'
            : 'bg-[var(--toss-gray-1)] border-[var(--toss-border)] focus-within:bg-[var(--toss-card)] focus-within:ring-4 focus-within:ring-[var(--toss-blue)]'
            }`}>
            <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.hwp" />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={fileUploading}
              title="파일 첨부"
              className="w-8 h-8 flex items-center justify-center text-[var(--toss-gray-3)] hover:text-[var(--toss-blue)] transition-colors disabled:opacity-50"
            >
              {fileUploading ? <span className="animate-pulse text-xs">...</span> : '첨부'}
            </button>
            <div className="relative flex-1">
              <textarea
                ref={composerRef}
                data-testid="chat-message-input"
                rows={1}
                className="block min-h-[24px] w-full min-w-0 resize-none bg-transparent px-2 py-1.5 text-[15px] font-bold leading-5 outline-none md:text-sm"
                placeholder={selectedRoomId === NOTICE_ROOM_ID && !canWriteNotice ? "부서장 이상만 공지 작성 가능" : "메시지를 입력하세요... (@이름 멘션 가능)"}
                value={inputMsg}
                onChange={e => {
                  const value = e.target.value;
                  handleComposerChange(value, e.target.selectionStart ?? value.length);
                }}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
              />
              {showMentionList && mentionCandidates.length > 0 && (
                <div className="absolute left-0 bottom-full mb-1 w-full max-h-48 overflow-y-auto bg-[var(--toss-card)] border border-[var(--toss-border)] rounded-[12px] shadow-lg z-20 text-xs">
                  {mentionCandidates.map((m: any) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        const value = inputMsg;
                        const match = value.match(/@([^\s@]{0,20})$/);
                        if (match) {
                          const replaced = value.replace(/@([^\s@]{0,20})$/, `@${m.name} `);
                          setInputMsg(replaced);
                        }
                        setShowMentionList(false);
                        setMentionQuery('');
                      }}
                      className="w-full px-3 py-2 flex items-center gap-2 hover:bg-[var(--toss-blue-light)] text-left"
                    >
                      <span className="text-[11px] font-semibold text-[var(--foreground)] truncate">{m.name}</span>
                      <span className="text-[11px] text-[var(--toss-gray-3)] truncate">
                        {(m.department || '')}{m.position ? ` 쨌 ${m.position}` : ''}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <button data-testid="chat-send-button" onClick={() => handleSendMessage()} className="bg-[var(--toss-blue)] text-white w-8 h-8 rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center text-sm">전송</button>
          </div>
        </div>

        {showDrawer && (
          <>
            <div className="absolute inset-0 bg-black/10 z-50 animate-in fade-in duration-200" onClick={() => setShowDrawer(false)} aria-hidden="true" />
            <div className="absolute top-0 right-0 bottom-0 w-full md:w-80 bg-white dark:bg-zinc-900 shadow-2xl z-[60] flex flex-col animate-in slide-in-from-right duration-300 border-l border-[var(--toss-border)]">
              <div className="p-4 border-b border-[var(--toss-border)] flex items-center justify-between bg-[var(--toss-card)]">
                <span className="text-sm font-bold">채팅방 정보</span>
              <button onClick={() => setShowDrawer(false)} className="p-2 text-[var(--toss-gray-3)] hover:text-black dark:hover:text-white rounded-full">닫기</button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
                <div className="flex items-center justify-between p-3 bg-zinc-50 dark:bg-zinc-800/50 rounded-2xl">
                  <span className="text-sm font-semibold">알림 설정</span>
                  <button
                    onClick={() => setRoomNotifyOn(!roomNotifyOn)}
                    className={`w-12 h-6 rounded-full transition-colors relative ${roomNotifyOn ? 'bg-emerald-500' : 'bg-zinc-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${roomNotifyOn ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>

                <button onClick={() => { setShowPollModal(true); setShowDrawer(false); }} className="w-full flex items-center justify-between p-3.5 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800/50 hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors group">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">🗳️</span>
                    <span className="text-xs font-bold text-blue-700 dark:text-blue-300">새 투표 만들기</span>
                  </div>
                  <span className="text-[10px] text-blue-400 font-bold group-hover:translate-x-1 transition-transform">열기</span>
                </button>

                <div className="space-y-3">
                  <p className="text-[11px] font-bold text-[var(--toss-gray-3)] uppercase tracking-wider px-1">상단 공지</p>
                  <div className="p-4 bg-orange-50 dark:bg-orange-950/20 rounded-2xl border border-orange-100 dark:border-orange-900/30">
                    <p className="text-xs font-bold text-orange-800 dark:text-orange-300 mb-1">공지</p>
                    <p className="text-xs text-orange-900/70 dark:text-orange-200/50 leading-relaxed whitespace-pre-wrap">
                      {currentNoticeMessage?.content || '등록된 공지가 없습니다.'}
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center px-1">
                <p className="text-[11px] font-bold text-[var(--toss-gray-3)] uppercase tracking-wider">사진 및 동영상</p>
                    <button className="text-[10px] font-bold text-[var(--toss-blue)]">전체보기</button>
                  </div>
                  <div className="grid grid-cols-3 gap-1 rounded-2xl overflow-hidden">
                    {messages.filter(m => m.file_kind === 'image' || m.file_kind === 'video').slice(-6).map((m) => (
                      <div key={m.id} className="aspect-square bg-zinc-100 dark:bg-zinc-800 relative group cursor-pointer">
                        {m.file_kind === 'image' ? (
                          <img src={m.file_url} alt="Attached image" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xl">🎬</div>
                        )}
                      </div>
                    ))}
                    {messages.filter(m => m.file_kind === 'image' || m.file_kind === 'video').length === 0 && (
                      <div className="col-span-3 py-8 text-center bg-zinc-50 dark:bg-zinc-800/30 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-700">
                        <p className="text-[10px] font-bold text-[var(--toss-gray-3)]">주고받은 미디어가 없습니다.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <p className="text-[11px] font-bold text-[var(--toss-gray-3)] uppercase tracking-wider px-1">링크</p>
                  <div className="space-y-2">
                    {messages.filter(m => m.content && m.content.includes('http')).slice(-3).map((m) => {
                      const urlMatch = m.content.match(/https?:\/\/[^\s]+/);
                      const url = urlMatch ? urlMatch[0] : '';
                      return (
                        <a key={m.id} href={url} target="_blank" rel="noreferrer" className="block p-3 bg-zinc-50 dark:bg-zinc-800/50 rounded-xl border border-zinc-100 dark:border-zinc-800 hover:border-emerald-500 transition-colors">
                          <p className="text-[11px] font-bold truncate text-emerald-600 mb-0.5">{url}</p>
                          <p className="text-[10px] text-[var(--toss-gray-4)] truncate">{m.staff?.name} 쨌 {new Date(m.created_at).toLocaleDateString()}</p>
                        </a>
                      );
                    })}
                    {messages.filter(m => m.content && m.content.includes('http')).length === 0 && (
                      <div className="py-4 text-center bg-zinc-50 dark:bg-zinc-800/30 rounded-xl border border-zinc-100 dark:border-zinc-800">
                        <p className="text-[10px] font-bold text-[var(--toss-gray-3)]">공유된 링크가 없습니다.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center px-1">
                    <p className="text-[11px] font-bold text-[var(--toss-gray-3)] uppercase tracking-wider">참여자 ({selectedRoom?.members?.length || 0})</p>
              <button onClick={() => setShowGroupModal(true)} className="w-6 h-6 flex items-center justify-center bg-zinc-100 dark:bg-zinc-800 rounded-full text-zinc-500 hover:text-emerald-500 transition-colors">+</button>
                  </div>
                  <div className="space-y-3">
                    {selectedRoom?.members?.map((memberId: string) => {
                      const s = resolveRoomMemberProfile(selectedRoom, String(memberId));
                      const isOwner = selectedRoom?.created_by === user.id;
                      return (
                        <div key={memberId} className="flex items-center justify-between group">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-[10px] font-bold text-emerald-600">
                              {s?.photo_url ? <img src={s.photo_url} alt={`${s.name}'s profile`} className="w-full h-full rounded-full object-cover" /> : (s?.name?.[0] || '?')}
                            </div>
                            <div>
                              <p className="text-xs font-bold text-foreground">{s?.name || '이름 없음'}</p>
                              <p className="text-[10px] text-[var(--toss-gray-4)] font-medium">{(s?.department || '')} 쨌 {s?.position}</p>
                            </div>
                          </div>
                          {isOwner && memberId !== user.id && (
                            <button className="opacity-0 group-hover:opacity-100 p-1 text-red-500 text-[10px] font-bold hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-all">내보내기</button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-zinc-50 dark:bg-zinc-800/50 border-t border-[var(--toss-border)] flex gap-2">
            <button onClick={() => { setShowDrawer(false); handleLeaveRoom(); }} className="flex-1 py-3 bg-red-50 dark:bg-red-900/20 text-red-600 rounded-xl text-[11px] font-bold hover:bg-red-100 transition-colors">방 나가기</button>
                <button onClick={() => { setEditingRoomName(true); setRoomNameDraft(selectedRoom?.name || ''); }} className="flex-1 py-3 bg-[var(--toss-gray-1)] text-foreground rounded-xl text-[11px] font-bold hover:bg-[var(--toss-gray-2)] transition-colors">이름 수정</button>
              </div>
            </div>
          </>
        )}

        {activeActionMsg && (
          <>
            <div className="absolute inset-0 bg-black/10 z-30 animate-in fade-in duration-200" onClick={() => { setActiveActionMsg(null); setEditingMsg(null); }} aria-hidden="true" />

            <div className="md:hidden absolute left-0 right-0 bottom-0 bg-white dark:bg-zinc-900 rounded-t-[24px] shadow-2xl z-40 flex flex-col animate-in slide-in-from-bottom duration-300 max-h-[85vh] overflow-hidden">
              <div className="w-12 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-full mx-auto my-3 shrink-0" />
              <div className="px-4 pb-8 space-y-4 overflow-y-auto">
                <div className="flex justify-between items-center bg-zinc-100 dark:bg-zinc-800/50 p-2 rounded-[20px] gap-1 px-4">
                  {['👍', '❤️', '👏', '🎉', '🔥', '✅', '👀', '🙏'].map(emoji => (
                    <button key={emoji} onClick={() => { toggleReaction(activeActionMsg.id, emoji); setActiveActionMsg(null); }} className="text-2xl hover:scale-110 transition-transform p-1">{emoji}</button>
                  ))}
                </div>
                <div className="space-y-1">
                  <button onClick={() => { handleAction('task'); setActiveActionMsg(null) }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">✅</span>
                    <span className="text-sm font-bold">할 일 추가</span>
                  </button>
                  <button onClick={() => { if (!activeActionMsg) return; void togglePin(activeActionMsg.id); setActiveActionMsg(null); }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">📢</span>
                    <span className="text-sm font-bold">{pinnedIds.includes(String(activeActionMsg.id)) ? '공지 해제' : '공지 등록'}</span>
                  </button>
                  <button onClick={() => { if (!activeActionMsg) return; void toggleBookmark(activeActionMsg.id); setActiveActionMsg(null); }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">🔖</span>
                    <span className="text-sm font-bold">{bookmarkedIds.has(String(activeActionMsg.id)) ? '북마크 해제' : '북마크 등록'}</span>
                  </button>
                  <button onClick={async () => { await navigator.clipboard?.writeText(activeActionMsg.content || ''); alert('복사했습니다.'); setActiveActionMsg(null); }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">📋</span>
                    <span className="text-sm font-bold">복사</span>
                  </button>
                  {activeActionMsg.sender_id === user.id && (
                    <button onClick={() => { void deleteMessageFromActions(activeActionMsg); }} className="w-full flex items-center gap-4 p-4 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-[12px] transition-colors text-red-500">
                      <span className="text-xl">🗑️</span>
                      <span className="text-sm font-bold">삭제</span>
                    </button>
                  )}
                  <button onClick={() => { startReplyToMessage(activeActionMsg); }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">↩️</span>
                    <span className="text-sm font-bold">답장</span>
                  </button>
                  <button onClick={() => { startForwardMessage(activeActionMsg); }} className="w-full flex items-center gap-4 p-4 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-[12px] transition-colors">
                    <span className="text-xl">📤</span>
                    <span className="text-sm font-bold">전달</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="hidden md:flex absolute top-0 right-0 bottom-0 w-80 bg-[var(--toss-card)] border-l border-[var(--toss-border)] shadow-2xl z-40 flex-col animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-[var(--toss-border)] flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase">메시지 작업</span>
            <button onClick={() => { setActiveActionMsg(null); setEditingMsg(null) }} className="p-2 text-[var(--toss-gray-3)] hover:text-[var(--toss-gray-4)] rounded-[12px] hover:bg-[var(--toss-gray-1)]">닫기</button>
              </div>
              <div className="p-4 space-y-4 overflow-y-auto flex-1">
                <p className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase">빠른 반응</p>
                <div className="flex gap-2 flex-wrap">
                  {['👍', '❤️', '👏', '🔥', '🙏'].map(emoji => (
                    <button key={emoji} onClick={() => { toggleReaction(activeActionMsg.id, emoji); }} className="w-11 h-11 flex items-center justify-center rounded-[12px] bg-[var(--toss-gray-1)] hover:bg-[var(--toss-blue-light)] text-xl transition-colors" title={emoji}>
                      {emoji}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase pt-2">기능</p>
                <div className="space-y-1">
                  <button
                    onClick={() => { startReplyToMessage(activeActionMsg); }}
                    className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors"
                  >
                    답글 달기
                  </button>
                  {activeActionMsg.sender_id === user.id && (
                    <>
                      <button onClick={() => { startEditMessage(activeActionMsg); }} className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors">메시지 수정</button>
                      <button onClick={() => { void deleteMessageFromActions(activeActionMsg); }} className="w-full p-3 text-left hover:bg-red-50 rounded-[12px] text-xs font-semibold text-red-600 transition-colors">메시지 삭제</button>
                    </>
                  )}
                  <button onClick={() => { void togglePin(activeActionMsg.id); setActiveActionMsg(null); }} className={`w-full p-3 text-left rounded-[12px] text-xs font-semibold transition-colors ${pinnedIds.includes(String(activeActionMsg.id)) ? 'hover:bg-[var(--toss-gray-1)] text-[var(--toss-gray-3)]' : 'hover:bg-orange-50 text-orange-500'}`}>{pinnedIds.includes(String(activeActionMsg.id)) ? '공지 해제' : '공지로 등록'}</button>
                  <button onClick={() => { handleAction('task'); setActiveActionMsg(null) }} className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors">할 일로 등록</button>
                  <button
                    onClick={() => { openReadStatusPanel(activeActionMsg); }}
                    className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors"
                  >
                    읽음 확인
                  </button>
                  <button
                    onClick={() => { startForwardMessage(activeActionMsg); }}
                    className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors"
                  >
                    다른 채팅방으로 전달
                  </button>
                  <button onClick={() => { openThreadPanel(activeActionMsg); }} className="w-full p-3 text-left hover:bg-[var(--toss-blue-light)] rounded-[12px] text-xs font-semibold text-[var(--toss-blue)] transition-colors">이 메시지 스레드 보기</button>
                  <button onClick={async () => { try { const base = `[채팅] ${activeActionMsg.staff?.name || '이름 없음'} (${new Date(activeActionMsg.created_at).toLocaleString('ko-KR')})\n${activeActionMsg.content || ''}${activeActionMsg.file_url ? `\n파일: ${activeActionMsg.file_url}` : ''}`; await navigator.clipboard?.writeText(`[전자결재 메모]\n${base}`); alert('전자결재용으로 복사했습니다.'); } catch { alert('복사 실패'); } setActiveActionMsg(null); }} className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors">전자결재용 내용 복사</button>
                  <button onClick={async () => { try { const base = `[채팅] ${activeActionMsg.staff?.name || '이름 없음'} (${new Date(activeActionMsg.created_at).toLocaleString('ko-KR')})\n${activeActionMsg.content || ''}${activeActionMsg.file_url ? `\n파일: ${activeActionMsg.file_url}` : ''}`; await navigator.clipboard?.writeText(`[게시판 메모]\n${base}`); alert('게시판용으로 복사했습니다.'); } catch { alert('복사 실패'); } setActiveActionMsg(null); }} className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors">게시판용 내용 복사</button>
                  <button onClick={() => { void toggleBookmark(activeActionMsg.id); setActiveActionMsg(null); }} className="w-full p-3 text-left hover:bg-[var(--toss-gray-1)] rounded-[12px] text-xs font-semibold transition-colors">{bookmarkedIds.has(String(activeActionMsg.id)) ? '북마크 해제' : '중요 메시지 북마크'}</button>
                </div>
              </div>
            </div>
          </>
        )}

        {editingMsg && (
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-30" onClick={() => { setEditingMsg(null); setEditContent(''); }}>
            <div className="bg-[var(--toss-card)] p-6 rounded-[12px] w-80 shadow-2xl" onClick={e => e.stopPropagation()}>
              <p className="text-xs font-semibold text-[var(--toss-gray-3)] mb-2">메시지 수정</p>
              <input value={editContent} onChange={e => setEditContent(e.target.value)} className="w-full p-3 border rounded-[16px] text-sm mb-4" />
              <div className="flex gap-2">
                <button onClick={() => { setEditingMsg(null); setEditContent(''); }} className="flex-1 py-2 bg-[var(--toss-gray-1)] rounded-[16px] text-xs font-semibold">취소</button>
            <button onClick={saveEditMessage} className="flex-1 py-2 bg-[var(--toss-blue)] text-white rounded-[16px] text-xs font-semibold">저장</button>
              </div>
            </div>
          </div>
        )}

        {showGroupModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center z-[110] p-4" onClick={() => setShowGroupModal(false)}>
            <div className="bg-[var(--toss-card)] w-full max-w-md rounded-[3rem] p-10 shadow-2xl space-y-8" onClick={e => e.stopPropagation()}>
              <h3 className="text-xl font-semibold text-[var(--foreground)] italic">새 그룹 채팅방</h3>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase tracking-widest ml-1">방 이름</label>
                  <input value={groupName} onChange={e => setGroupName(e.target.value)} className="w-full p-4 bg-[var(--input-bg)] rounded-[12px] border-none outline-none font-bold text-sm focus:ring-2 focus:ring-[var(--toss-blue)]" placeholder="예: 운영팀 공지방" />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase tracking-widest ml-1">멤버 선택 ({selectedMembers.length}명)</label>
                  <div className="h-48 overflow-y-auto border border-[var(--toss-border)] rounded-[12px] p-4 space-y-2 custom-scrollbar bg-[var(--toss-gray-1)]/30">
                    {staffs.filter((s: any) => s.id !== user.id).map((s: any) => (
                      <label key={s.id} className="flex items-center gap-3 p-3 bg-[var(--toss-card)] rounded-[16px] border border-[var(--toss-border)] cursor-pointer hover:border-[var(--toss-blue)] transition-all">
                        <input type="checkbox" checked={selectedMembers.includes(s.id)} onChange={e => {
                          if (e.target.checked) setSelectedMembers([...selectedMembers, s.id]);
                          else setSelectedMembers(selectedMembers.filter(id => id !== s.id));
                        }} className="w-4 h-4 rounded border-[var(--toss-border)] text-[var(--toss-blue)] focus:ring-[var(--toss-blue)]" />
                        <span className="text-xs font-bold text-[var(--foreground)]">{s.name} ({s.position})</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setShowGroupModal(false)} className="flex-1 py-4 bg-[var(--toss-gray-1)] text-[var(--toss-gray-3)] rounded-[12px] font-semibold text-xs">취소</button>
                  <button onClick={createGroupChat} className="flex-2 py-4 bg-[var(--toss-blue)] text-white rounded-[12px] font-semibold text-xs shadow-lg shadow-[var(--toss-blue)]">채팅방 생성</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {showPollModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[110] p-4">
          <div className="bg-[var(--toss-card)] w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl border border-[var(--toss-border)]">
              <h3 className="text-lg font-semibold text-[var(--foreground)]">새 투표 만들기</h3>
            <p className="text-[11px] text-[var(--toss-gray-3)] font-bold">
              질문과 선택지를 입력해 주세요. 선택지는 항목별로 따로 입력합니다.
            </p>
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase">질문</label>
                <input
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  className="w-full mt-1 p-3 bg-[var(--input-bg)] border border-[var(--toss-border)] rounded-[16px] text-xs font-bold outline-none focus:border-[var(--toss-blue)]"
                  placeholder="예: 이번 주 회의 시간은 언제가 좋을까요?"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase">선택지</label>
                <div className="mt-1 space-y-2">
                  {pollOptions.map((opt, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input
                        value={opt}
                        onChange={(e) => {
                          const newOpts = [...pollOptions];
                          newOpts[idx] = e.target.value;
                          setPollOptions(newOpts);
                        }}
                        className="flex-1 p-3 bg-[var(--input-bg)] border border-[var(--toss-border)] rounded-[16px] text-xs font-bold outline-none focus:border-[var(--toss-blue)]"
                        placeholder={`선택지 ${idx + 1}`}
                      />
                      {pollOptions.length > 2 && (
                        <button
                          type="button"
                          onClick={() => setPollOptions(pollOptions.filter((_, i) => i !== idx))}
                          className="w-10 h-10 flex items-center justify-center bg-red-50 text-red-500 rounded-xl hover:bg-red-100"
                        >
                          삭제
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setPollOptions([...pollOptions, ''])}
                    className="w-full py-3 border-2 border-dashed border-zinc-200 rounded-xl text-xs font-bold text-zinc-500 hover:text-blue-500 hover:border-blue-300"
                  >
                    + 항목 추가
                  </button>
                </div>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPollModal(false)}
                className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-[var(--toss-gray-3)] hover:bg-[var(--toss-gray-1)]"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleCreatePoll}
                className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold bg-[var(--toss-blue)] text-white hover:bg-[var(--toss-blue)] shadow-md"
              >
                투표 생성
              </button>
            </div>
          </div>
        </div>
      )}

      {showSlashModal && slashCommand && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[110] p-4" onClick={() => setShowSlashModal(false)}>
          <div className="bg-[var(--toss-card)] w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl border border-[var(--toss-border)]" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-[var(--foreground)]">
              {slashCommand === 'annual_leave' ? '연차 요청 초안 만들기' : '발주 요청 초안 만들기'}
            </h3>
            {slashCommand === 'annual_leave' ? (
              <>
                <p className="text-[11px] text-[var(--toss-gray-3)] font-bold">
                  시작일, 종료일, 사유를 입력하면 전자결재용 연차/휴가 초안을 생성합니다.
                </p>
                <div className="space-y-3 text-xs font-bold">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">시작일</label>
                      <input
                        type="date"
                        value={slashForm.startDate}
                        onChange={e => setSlashForm((f: any) => ({ ...f, startDate: e.target.value }))}
                        className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">종료일</label>
                      <input
                        type="date"
                        value={slashForm.endDate}
                        onChange={e => setSlashForm((f: any) => ({ ...f, endDate: e.target.value }))}
                        className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">사유(선택)</label>
                    <input
                      type="text"
                      value={slashForm.reason}
                      onChange={e => setSlashForm((f: any) => ({ ...f, reason: e.target.value }))}
                      placeholder="예: 개인 일정, 병원 방문"
                      className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                    />
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowSlashModal(false)}
                    className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-[var(--toss-gray-3)] hover:bg-[var(--toss-gray-1)]"
                  >
                    취소
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!slashForm.startDate || !slashForm.endDate) {
                        alert('시작일과 종료일을 입력해 주세요.');
                        return;
                      }
                      try {
                        const title = `[채팅]/연차 자동 기안 - ${user.name}`;
                        const contentLines = [
                          `요청자: ${user.name} (${user.department || ''} ${user.position || ''})`,
                          `기간: ${slashForm.startDate} ~ ${slashForm.endDate}`,
                          slashForm.reason ? `사유: ${slashForm.reason}` : '',
                          '',
                          '이 요청서는 채팅 명령어(/연차)로 자동 생성되었습니다.',
                        ].filter(Boolean);
                        await supabase.from('approvals').insert([
                          {
                            sender_id: user.id,
                            sender_name: user.name,
                            sender_company: user.company,
                            type: '연차/휴가',
                            title,
                            content: contentLines.join('\n'),
                            status: '대기',
                          },
                        ]);
                        alert('연차/휴가 전자결재 초안을 생성했습니다. 전자결재 메뉴에서 내용을 확인 후 제출해 주세요.');
                      } catch {
                        alert('연차 초안 생성 중 오류가 발생했습니다.');
                      } finally {
                        setShowSlashModal(false);
                      }
                    }}
                    className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold bg-[var(--toss-blue)] text-white hover:bg-[var(--toss-blue)] shadow-md"
                  >
                    전자결재 초안 생성
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="text-[11px] text-[var(--toss-gray-3)] font-bold">
                  품목명과 수량을 입력하면 비품구매(발주) 결재 초안을 생성합니다.
                </p>
                <div className="space-y-3 text-xs font-bold">
                  <div>
                    <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">품목명</label>
                    <input
                      type="text"
                      value={slashForm.itemName}
                      onChange={e => setSlashForm((f: any) => ({ ...f, itemName: e.target.value }))}
                      placeholder="예: A4 용지, 프린터 토너"
                      className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">수량</label>
                      <input
                        type="number"
                        min={1}
                        value={slashForm.quantity}
                        onChange={e => setSlashForm((f: any) => ({ ...f, quantity: Number(e.target.value) || 1 }))}
                        className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[var(--toss-gray-3)] mb-1">비고(선택)</label>
                      <input
                        type="text"
                        value={slashForm.reason}
                        onChange={e => setSlashForm((f: any) => ({ ...f, reason: e.target.value }))}
                        placeholder="예: 재고 부족, 교체 주기 도래"
                        className="w-full px-3 py-2 border border-[var(--toss-border)] rounded-[16px] text-xs"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowSlashModal(false)}
                    className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-[var(--toss-gray-3)] hover:bg-[var(--toss-gray-1)]"
                  >
                    취소
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!slashForm.itemName || !slashForm.quantity) {
                        alert('품목명과 수량을 입력해 주세요.');
                        return;
                      }
                      try {
                        const title = `[채팅]/발주 자동 기안 - ${slashForm.itemName} x ${slashForm.quantity}`;
                        const contentLines = [
                          `요청자: ${user.name} (${user.department || ''} ${user.position || ''})`,
                          `품목: ${slashForm.itemName}`,
                          `수량: ${slashForm.quantity}`,
                          slashForm.reason ? `비고: ${slashForm.reason}` : '',
                          '',
                          '이 요청서는 채팅 명령어(/발주)로 자동 생성되었습니다.',
                        ].filter(Boolean);
                        await supabase.from('approvals').insert([
                          {
                            sender_id: user.id,
                            sender_name: user.name,
                            sender_company: user.company,
                            type: '비품구매',
                            title,
                            content: contentLines.join('\n'),
                            status: '대기',
                          },
                        ]);
                        alert('비품구매 전자결재 초안을 생성했습니다. 전자결재 메뉴에서 내용을 확인 후 제출해 주세요.');
                      } catch {
                        alert('발주 초안 생성 중 오류가 발생했습니다.');
                      } finally {
                        setShowSlashModal(false);
                      }
                    }}
                    className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold bg-[var(--toss-blue)] text-white hover:bg-[var(--toss-blue)] shadow-md"
                  >
                    전자결재 초안 생성
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {threadRoot && (
        <>
          <div
            className="absolute inset-0 bg-black/10 z-40"
            onClick={() => setThreadRoot(null)}
            aria-hidden="true"
          />
          <aside className="absolute top-0 right-0 bottom-0 w-80 bg-[var(--toss-card)] border-l border-[var(--toss-border)] shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
            <div className="p-4 border-b border-[var(--toss-border)] flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase tracking-widest">
                  스레드
                </p>
                <p className="text-xs font-semibold text-[var(--foreground)] mt-0.5 line-clamp-2">
                  {threadRoot.content || '첨부 파일 메시지'}
                </p>
              </div>
              <button
                onClick={() => setThreadRoot(null)}
                className="p-2 text-[var(--toss-gray-3)] hover:text-[var(--toss-gray-4)] rounded-[12px] hover:bg-[var(--toss-gray-1)]"
              >
                닫기
              </button>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-3">
              {threadMessages.length === 0 ? (
                <p className="text-[11px] text-[var(--toss-gray-3)] font-bold mt-4 text-center">
                  이 메시지에 연결된 대화가 없습니다.
                </p>
              ) : (
                threadMessages.map((m: any) => {
                  const isRoot = m.id === threadRoot.id;
                  const staff = m.staff || resolveStaffProfile(m.sender_id);
                  const createdAt = new Date(m.created_at);
                  return (
                    <div
                      key={m.id}
                      className={`border rounded-[12px] p-3 text-[11px] space-y-1 ${isRoot ? 'bg-[var(--toss-blue-light)] border-[var(--toss-blue)]' : 'bg-[var(--toss-gray-1)] border-[var(--toss-border)]'
                        }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[var(--foreground)] truncate">
                          {staff?.name || '이름 없음'} {staff?.position || ''}
                        </span>
                        <span className="text-[11px] text-[var(--toss-gray-3)]">
                          {createdAt.toLocaleDateString('ko-KR', {
                            month: 'numeric',
                            day: 'numeric',
                          })}{' '}
                          {createdAt.toLocaleTimeString('ko-KR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--foreground)] whitespace-pre-wrap break-words">
                        {m.content || '첨부 파일 메시지'}
                      </p>
                      {m.file_url && (
                        <a
                          href={m.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-2 py-1 mt-1 rounded-[12px] bg-[var(--toss-card)] border border-[var(--toss-border)] text-[11px] font-bold text-[var(--toss-blue)] hover:bg-[var(--toss-blue-light)]"
                        >
                          첨부 파일 열기
                        </a>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </aside>
        </>
      )}

      {unreadModalMsg && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[110] p-4" onClick={() => setUnreadModalMsg(null)}>
          <div className="bg-[var(--toss-card)] w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl border border-[var(--toss-border)]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[11px] font-semibold text-[var(--toss-gray-3)] uppercase tracking-widest">
                  읽음 확인 상세
                </p>
                <p className="text-xs font-semibold text-[var(--foreground)] mt-0.5 line-clamp-1 opacity-60">
                  {unreadModalMsg.content || '첨부 파일 메시지'}
                </p>
              </div>
              <button
                onClick={() => setUnreadModalMsg(null)}
                className="p-2 text-[var(--toss-gray-3)] hover:text-[var(--toss-gray-4)] rounded-[12px] hover:bg-[var(--toss-gray-1)]"
              >
                닫기
              </button>
            </div>

            <div className="border-t border-[var(--toss-border)] pt-3 max-h-[60vh] overflow-y-auto custom-scrollbar space-y-6">
              {unreadLoading ? (
                <div className="py-8 flex justify-center">
                  <div className="w-6 h-6 border-2 border-[var(--toss-border)] border-t-[var(--toss-blue)] rounded-full animate-spin" />
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                      <p className="text-[11px] font-bold text-red-500 uppercase tracking-wider">읽지 않음 ({unreadUsers.length})</p>
                    </div>
                    {unreadUsers.length === 0 ? (
                      <p className="text-[10px] text-zinc-400 font-bold py-2 px-1">모두 읽었습니다.</p>
                    ) : (
                      <div className="grid grid-cols-1 gap-1">
                        {unreadUsers.map((u: any) => (
                          <div key={u.id} className="flex items-center gap-3 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-800/30">
                            <div className="w-7 h-7 rounded-lg bg-zinc-200 dark:bg-zinc-700 flex items-center justify-center text-[10px] font-bold text-zinc-400 overflow-hidden">
                              {u.photo_url ? <img src={u.photo_url} alt={`${u.name}'s profile`} className="w-full h-full object-cover" /> : u.name[0]}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-[11px] font-bold text-foreground truncate">{u.name}</p>
                              <p className="text-[9px] font-bold text-zinc-400 truncate">{(u.department || '')} {u.position}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                      <p className="text-[11px] font-bold text-emerald-500 uppercase tracking-wider">읽음 ({readUsers.length})</p>
                    </div>
                    {readUsers.length === 0 ? (
                      <p className="text-[10px] text-zinc-400 font-bold py-2 px-1">아직 읽은 사람이 없습니다.</p>
                    ) : (
                      <div className="grid grid-cols-1 gap-1">
                        {readUsers.map((u: any) => (
                          <div key={u.id} className="flex items-center gap-3 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-800/30">
                            <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-[10px] font-bold text-emerald-600 overflow-hidden">
                              {u.photo_url ? <img src={u.photo_url} alt={`${u.name}'s profile`} className="w-full h-full object-cover" /> : u.name[0]}
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-[11px] font-bold text-foreground truncate">{u.name}</p>
                              <p className="text-[9px] font-bold text-zinc-400 truncate">{(u.department || '')} {u.position}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showForwardModal && forwardSourceMsg && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[110] p-4" onClick={() => { setShowForwardModal(false); setForwardSourceMsg(null); }}>
          <div className="bg-[var(--toss-card)] w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl border border-[var(--toss-border)]" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-[var(--foreground)]">다른 채팅방으로 전달</h3>
            <p className="text-[11px] text-[var(--toss-gray-3)] font-bold">
              선택한 메시지를 전달할 채팅방을 선택하세요.
            </p>
            <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-2">
              {chatRooms
                .filter((r: any) => r.id !== selectedRoomId)
                .map((room: any) => (
                  <button
                    key={room.id}
                    type="button"
                    onClick={async () => {
                      try {
                        const { data: forwardedMessage, error } = await supabase.from('messages').insert([
                          {
                            room_id: room.id,
                            sender_id: user.id,
                            content:
                              `[전달] ${forwardSourceMsg.staff?.name || '이름 없음'}: ` +
                              (forwardSourceMsg.content || '첨부 파일'),
                            file_url: forwardSourceMsg.file_url || null,
                          },
                        ]).select('id, room_id').single();
                        if (error) throw error;
                        if (forwardedMessage?.id && forwardedMessage?.room_id) {
                          await triggerChatPush(String(forwardedMessage.room_id), String(forwardedMessage.id));
                        }
                        alert(`"${room.name || '채팅방'}"으로 메시지를 전달했습니다.`);
                      } catch {
                        alert('메시지 전달 중 오류가 발생했습니다.');
                      } finally {
                        setShowForwardModal(false);
                        setForwardSourceMsg(null);
                      }
                    }}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-[12px] border border-[var(--toss-border)] hover:bg-[var(--toss-blue-light)] text-left text-xs font-bold text-[var(--foreground)]"
                  >
                    <span className="truncate">
                      {room.id === NOTICE_ROOM_ID ? '공 ' : '채 '}
                      {room.name || '채팅방'}
                    </span>
                    <span className="text-[11px] text-[var(--toss-gray-3)]">
                      {roomUnreadCounts[room.id] ? String(roomUnreadCounts[room.id]) : ''}
                    </span>
                  </button>
                ))}
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => { setShowForwardModal(false); setForwardSourceMsg(null); }}
                className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-[var(--toss-gray-3)] hover:bg-[var(--toss-gray-1)]"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddMemberModal && selectedRoom && (
        <div
          className="fixed inset-0 bg-black/40 flex items-center justify-center z-[110] p-4"
          onClick={() => {
            setShowAddMemberModal(false);
            setAddMemberSelectingIds([]);
          }}
        >
          <div
            className="bg-[var(--toss-card)] w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl border border-[var(--toss-border)]"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-semibold text-[var(--foreground)]">
              참여자 추가
            </h3>
            <p className="text-[11px] text-[var(--toss-gray-3)] font-bold">
              현재 채팅방에 새로 초대할 직원을 선택하세요.
            </p>
            <input
              type="text"
              value={addMemberSearch}
              onChange={(e) => setAddMemberSearch(e.target.value)}
              className="w-full px-3 py-2 rounded-[16px] border border-[var(--toss-border)] text-xs font-bold outline-none focus:ring-2 focus:ring-[var(--toss-blue)]/30"
              placeholder="이름, 부서, 직급으로 검색"
            />
            <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-1">
              {addableMembers.length === 0 ? (
                <p className="text-[11px] text-[var(--toss-gray-3)] font-bold py-4 text-center">
                  추가할 수 있는 직원이 없습니다.
                </p>
              ) : (
                addableMembers.map((s: any) => {
                  const checked = addMemberSelectingIds.includes(s.id);
                  return (
                    <label
                      key={s.id}
                      className="flex items-center gap-3 px-3 py-2 rounded-[16px] border border-[var(--toss-border)] hover:bg-[var(--toss-gray-1)] cursor-pointer text-[11px]"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAddMemberSelectingIds((prev) =>
                              prev.includes(s.id) ? prev : [...prev, s.id]
                            );
                          } else {
                            setAddMemberSelectingIds((prev) =>
                              prev.filter((id) => id !== s.id)
                            );
                          }
                        }}
                        className="w-3 h-3"
                      />
                      <span className="flex-1">
                        <span className="font-semibold text-[var(--foreground)]">
                          {s.name}
                        </span>
                        <span className="ml-1 text-[var(--toss-gray-3)]">
                          {s.position ? ` ${s.position}` : ''}
                          {s.company || s.department
                            ? ` 쨌 ${s.company || s.department}`
                            : ''}
                        </span>
                      </span>
                    </label>
                  );
                })
              )}
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowAddMemberModal(false);
                  setAddMemberSelectingIds([]);
                }}
                className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-[var(--toss-gray-3)] hover:bg-[var(--toss-gray-1)]"
              >
                취소
              </button>
              <button
                type="button"
                disabled={addMemberSelectingIds.length === 0}
                onClick={async () => {
                  if (!selectedRoom) return;
                  try {
                    const currentMembers: any[] = Array.isArray(
                      selectedRoom.members
                    )
                      ? selectedRoom.members
                      : [];
                    const setIds = new Set(
                      currentMembers.map((id: any) => String(id))
                    );
                    addMemberSelectingIds.forEach((id) =>
                      setIds.add(String(id))
                    );
                    const newMembers = Array.from(setIds);

                    await supabase
                      .from('chat_rooms')
                      .update({ members: newMembers })
                      .eq('id', selectedRoom.id);

                    const invitedNames = addMemberSelectingIds
                      .map((id) => resolveStaffProfile(id)?.name || '이름 없음')
                      .join(', ');
                    const inviterName = user?.name || '이름 없음';
                    const systemContent = `[초대] ${inviterName}님이 ${invitedNames}님을 초대했습니다.`;
                    const { data: inviteMessage, error: inviteMessageError } = await supabase.from('messages').insert([{
                      room_id: selectedRoom.id,
                      sender_id: user.id,
                      content: systemContent,
                    }]).select('id, room_id').single();
                    if (inviteMessageError) throw inviteMessageError;
                    if (inviteMessage?.id && inviteMessage?.room_id) {
                      await triggerChatPush(String(inviteMessage.room_id), String(inviteMessage.id));
                    }

                    setChatRooms((prev) =>
                      prev.map((room: any) =>
                        room.id === selectedRoom.id
                          ? { ...room, members: newMembers }
                          : room
                      )
                    );
                    setShowAddMemberModal(false);
                    setAddMemberSelectingIds([]);
                    fetchData();
                    alert('참여자가 추가되었습니다.');
                  } catch (e) {
                    console.error('add members error', e);
                    alert('참여자 추가 중 오류가 발생했습니다.');
                  }
                }}
                className="flex-1 py-3 rounded-[16px] text-[11px] font-semibold text-white bg-[var(--toss-blue)] disabled:bg-[var(--toss-gray-3)] hover:bg-[var(--toss-blue)]"
              >
                추가하기
              </button>
            </div>
          </div>
        </div>
      )}

      {showMediaPanel && (
        <>
          <div className="fixed inset-0 bg-black/5 z-[100] md:z-30 animate-in fade-in" onClick={() => setShowMediaPanel(false)} />
          <aside className="fixed top-0 right-0 bottom-0 w-80 bg-[var(--toss-card)] border-l border-[var(--toss-border)] shadow-2xl z-[101] md:z-40 flex flex-col animate-in slide-in-from-right duration-300">
            <div className="p-4 border-b border-[var(--toss-border)] flex items-center justify-between">
              <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">파일/링크 내역</span>
            <button onClick={() => setShowMediaPanel(false)} className="p-2 text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl">닫기</button>
            </div>

            <div className="flex p-2 gap-1 bg-zinc-50 dark:bg-zinc-900 border-b border-[var(--toss-border)]">
              {(['all', 'image', 'file'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setMediaFilter(f)}
                  className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all ${mediaFilter === f ? 'bg-white dark:bg-zinc-800 text-blue-600 shadow-soft' : 'text-zinc-400 hover:text-zinc-600'}`}
                >
                  {f === 'all' ? '전체' : f === 'image' ? '이미지' : '파일'}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {filteredMediaMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-30 text-zinc-400">
                  <span className="text-4xl mb-2">📭</span>
                  <p className="text-[11px] font-bold">내역이 없습니다.</p>
                </div>
              ) : (
                filteredMediaMessages.map((m: any) => (
                  <div key={m.id} className="p-3 bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800 rounded-xl hover:border-blue-300 transition-all group">
                    {isImageUrl(m.file_url) ? (
                      <img src={m.file_url} alt="Attached media" className="w-full h-24 object-cover rounded-lg mb-2 cursor-pointer" onClick={() => window.open(m.file_url)} />
                    ) : (
                      <div className="w-full h-12 bg-zinc-100 dark:bg-zinc-800 rounded-lg mb-2 flex items-center justify-center text-xl">📄</div>
                    )}
                    <div className="flex flex-col gap-1 min-w-0">
                      <p className="text-[11px] font-bold text-foreground truncate">{m.content || '내용 없음'}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-bold text-zinc-400">{new Date(m.created_at).toLocaleDateString()}</span>
                        <a href={m.file_url} target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold text-blue-600 hover:underline">다운로드</a>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </aside>
        </>
      )}

      {showGlobalSearch && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[200] flex items-start md:items-center justify-center p-4 pt-12 md:p-6 animate-in fade-in" onClick={() => setShowGlobalSearch(false)}>
          <div className="bg-white dark:bg-zinc-900 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] md:max-h-[85vh] border border-zinc-200 dark:border-zinc-800" onClick={e => e.stopPropagation()}>
            <div className="p-4 md:p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
              <span className="text-xl">🔎</span>
              <input
                autoFocus
                value={globalSearchQuery}
                onChange={e => setGlobalSearchQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleGlobalSearch()}
                placeholder="전체 채팅방 내용 검색..."
                className="flex-1 bg-transparent text-foreground text-sm font-bold outline-none placeholder:text-zinc-400"
              />
              <button
                onClick={handleGlobalSearch}
                className="px-4 py-2 bg-[var(--toss-blue)] text-white font-bold text-xs rounded-xl shadow-sm hover:opacity-90 transition-opacity whitespace-nowrap"
              >
                {globalSearchLoading ? '검색중...' : '검색'}
              </button>
              <button onClick={() => setShowGlobalSearch(false)} className="ml-2 text-zinc-400 hover:text-zinc-600 text-lg font-bold">닫기</button>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar bg-zinc-50 dark:bg-zinc-950 p-4 md:p-6">
              {!globalSearchLoading && globalSearchResults.length === 0 && globalSearchQuery.trim() && (
                <div className="h-40 flex flex-col items-center justify-center text-zinc-400">
                  <span className="text-3xl mb-2">무</span>
                  <p className="text-sm font-bold">검색 결과가 없습니다.</p>
                </div>
              )}
              <div className="space-y-3">
                {globalSearchResults.map((msg: any) => {
                  let roomName = msg.chat_rooms?.name || '채팅방';
                  if (msg.chat_rooms?.type === 'direct' && Array.isArray(msg.chat_rooms?.members)) {
                    const otherStaff = allKnownStaffs.find((s: any) => msg.chat_rooms.members.includes(String(s.id)) && String(s.id) !== effectiveChatUserId);
                    if (otherStaff) roomName = otherStaff.name;
                  }
                  return (
                    <div
                      key={msg.id}
                      onClick={() => {
                        setRoom(msg.room_id);
                        setShowGlobalSearch(false);
                      }}
                      className="group p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl cursor-pointer hover:border-[var(--toss-blue)] hover:shadow-md transition-all"
                    >
                      <div className="flex items-center justify-between mb-2 gap-4">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-500 rounded text-[10px] font-bold truncate shrink-0 max-w-[120px]">
                            {roomName}
                          </span>
                          <span className="text-[11px] font-bold text-foreground truncate">{msg.staff?.name || '이름 없음'}</span>
                        </div>
                        <span className="text-[10px] font-bold text-zinc-400 shrink-0">
                          {new Date(msg.created_at).toLocaleDateString()} {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[12px] font-semibold text-zinc-700 dark:text-zinc-300 line-clamp-2 leading-relaxed">
                        {msg.content || (msg.file_url ? '첨부 파일' : '')}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
