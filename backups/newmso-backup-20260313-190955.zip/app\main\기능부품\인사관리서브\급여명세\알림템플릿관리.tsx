'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function NotificationTemplatesPanel({ companyName }: { companyName?: string }) {
  const [list, setList] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('notification_templates').select('*').eq('company_name', companyName || '전체').order('template_type');
      setList(data || []);
    })();
  }, [companyName]);

  if (list.length === 0) {
    return (
      <div className="border border-[var(--toss-border)] p-4 bg-[var(--toss-card)] rounded-[12px] shadow-sm">
        <div className="pb-2 border-b border-[var(--toss-border)] mb-3">
          <h3 className="text-sm font-semibold text-[var(--foreground)]">알림톡/메일 템플릿</h3>
        </div>
        <p className="text-xs text-[var(--toss-gray-3)]">등록된 템플릿이 없습니다. tax_free_settings 마이그레이션 후 notification_templates 테이블이 생성됩니다.</p>
      </div>
    );
  }

  return (
    <div className="border border-[var(--toss-border)] p-4 bg-[var(--toss-card)] rounded-[12px] shadow-sm">
      <div className="pb-2 border-b border-[var(--toss-border)] mb-3">
        <h3 className="text-sm font-semibold text-[var(--foreground)]">알림톡/메일 템플릿</h3>
      </div>
      <div className="space-y-2">
        {list.map((t) => (
          <div key={t.id} className="p-3 bg-[var(--page-bg)] rounded-[12px] border border-[var(--toss-border)]">
            <p className="text-xs font-semibold text-[var(--foreground)]">{t.template_type} - {t.name}</p>
            <p className="text-[11px] text-[var(--toss-gray-4)] mt-1 truncate">{t.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
